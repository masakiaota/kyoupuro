from pathlib import Path
import json,collections,hashlib
r=Path(__file__).resolve().parents[2];o=r/'results/analysis/v407';records=json.loads((o/'diagnostic_run_records.json').read_text());rows=[]
for p in sorted((o/'diagnostic_cases').glob('*.jsonl')):rows.extend(json.loads(s) for s in p.read_text().splitlines())
c=collections.Counter();selections=[];wins=[]
for a in rows:
 c['selected']+=1;c['extracted']+=a['extracted'];c['completed']+=a['ok'];c['extraction_failed']+=not a['extracted']
 if a['extracted']:
  c['first_failed_second_succeeded']+=not a['first_ok'] and a['second_ok'];c['second_failed']+=not a['second_ok'];c['both_failed']+=not a['first_ok'] and not a['second_ok'];c['strict_raw_second']+=a['first_ok'] and a['second_ok'] and a['second_length']<a['first_length']
 c['raw_ties']+=a['raw_tie'];c['equal_identical']+=a['raw_tie'] and not a['distinct'];c['distinct']+=a['distinct'];c['first_current_with_alternate']+=a['distinct'] and a['first_is_current'];c['polished_ties']+=a['distinct'] and a['polished_length']==a['alternate_polished_length'];c['wins']+=a['win']
 if a['win']:c['direct_savings']+=a['polished_length']-a['alternate_polished_length'];wins.append({'case':a['case'],'ordinal':a['ordinal'],'first_raw':a['first_length'],'first_polished':a['polished_length'],'alternate_polished':a['alternate_polished_length']})
 selections.append({k:a[k] for k in ['case','ordinal','ids','order','rng']})
sel=json.dumps(selections,separators=(',',':')).encode();(o/'diagnostic_selection.json').write_bytes(sel)
result={'counts':dict(c),'cases':len(records),'failures':[a for a in records if a['returncode']],'pool_all_four':all(a['pool']==4 for a in rows),'extra_smoothing_ms':sum(a['extra_ms'] for a in rows),'selection_sha256':hashlib.sha256(sel).hexdigest(),'natural_witnesses':wins,'synthetic_insert_fixtures':6,'synthetic_dispatch_fixtures':7,'gate_pass':len(records)==100 and all(a['returncode']==0 for a in records) and len(rows)==3200 and c['wins']>=1 and all(a['pool']==4 for a in rows)}
(o/'diagnostic_result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
