from pathlib import Path
r=Path(__file__).resolve().parents[2];s=(r/'src/bin/v407_polished_two_order.cpp').read_text();p=(r/'adhoc/imports/v401/original.cpp.txt').read_text()
s=s.replace('class TemporalLNS {','class TemporalLNS {\npublic:',1)
s=s.replace('TowerBits* take() { return free_slot[--free_count]; }','TowerBits* take() { if(free_count<=0)throw logic_error("pool exhausted"); return free_slot[--free_count]; }')
a=p.index('    bool insert_two_orders(');b=p.index('\n    // 連続した束',a)
parent=p[a:b].replace('insert_two_orders(','parent_insert_two_orders(',1)
a=s.index('    bool insert_two_orders(');b=s.index('\n    // 連続した束',a)
method=s[a:b]
observed=method.replace('        equal_alternate.clear();','        equal_alternate.clear(); diagnostic_completed[0].clear(); diagnostic_completed[1].clear(); diagnostic_success[0]=diagnostic_success[1]=false;',1).replace('            LOCAL_NOTE(++local_two_order.finished[branch];)','            diagnostic_completed[branch]=tail; diagnostic_success[branch]=true;\n            LOCAL_NOTE(++local_two_order.finished[branch];)',1)
mock=method.replace('insert_two_orders(','mock_insert_two_orders(',1).replace('insert(restored,tail,id,cap,next)','fixture_insert(restored,tail,id,cap,next)')
fields='''    vector<Move> diagnostic_completed[2]; bool diagnostic_success[2]{};
    vector<pair<bool,vector<Move>>> fixture_responses; size_t fixture_at=0;
    bool fixture_insert(const State&,const vector<Move>&,int,int,vector<Move>& out) {
        auto response=fixture_responses.at(fixture_at++);out=response.second;return response.first;
    }
'''
s=s[:a]+fields+observed+'\n'+parent+'\n'+mock+s[b:]
s=s.replace('int main() {','int v407_submission_main() {',1)
outer_start=s.index('            if(equal_alternate.empty()&&same_moves(trial,current))')
outer_end=s.index('            shortcuts+=',outer_start)
outer=s[outer_start:outer_end]
# Execute the exact production dispatch with only its smoother dependency mocked.
outer=outer.replace('same_moves(', 'TemporalLNS::same_moves(')
fixture_dispatch=r'''
void dispatch407(const vector<Move>&plan){
    vector<Move>a(plan.begin(),plan.begin()+4),b=a,c(plan.begin(),plan.begin()+3);b[0].d=(b[0].d+1)%4;
    auto test=[&](bool has_alternate,bool first_current,vector<Move>pa,vector<Move>pb,int throw_call,vector<Move>expected,int expected_calls,int expected_duplicates){
        vector<Move>trial=a,equal_alternate=has_alternate?b:vector<Move>{},current=first_current?a:c;
        bool polished_alternate_selected=false,reached=false;int duplicates=0,calls=0;
        auto smooth_routes=[&](const vector<Move>&input){++calls;if(calls==throw_call)throw runtime_error("fixture smoothing failure");return TemporalLNS::same_moves(input,a)?pa:pb;};
        do {
__OUTER__
            require407(TemporalLNS::same_moves(polished,expected),"dispatch winner/first tie");reached=true;
        }while(false);
        require407(calls==expected_calls&&duplicates==expected_duplicates,"dispatch calls/duplicate");
        require407(reached==(throw_call==0&&expected_duplicates==0),"dispatch failure");
    };
    test(true,false,a,b,0,a,2,0); // Equal polished lengths keep first.
    test(true,true,a,c,0,c,2,0); // First=current still considers alternate.
    test(true,false,c,b,0,c,2,0); // Worse alternate keeps first.
    test(false,false,c,{},0,c,1,0); // No alternate smooths only once.
    test(false,true,c,{},0,{},0,1); // Original duplicate early exit.
    test(true,false,a,b,1,{},1,0); // Existing first-smoothing failure path.
    test(true,false,a,b,2,{},2,0); // Second-smoothing failure path.
}
'''.replace('__OUTER__',outer)
s += r'''
void require407(bool x,const string&m){if(!x)throw runtime_error(m);}
void replay407(const vector<Move>& moves){
    int N=board_info.N,E=0;vector<vector<int>> tower(N*N);
    for(int i=0;i<N;i++)for(int j=0;j<N;j++){char c=board_info.C[i][j];if(c>='a'&&c<='l'){tower[i*N+j].push_back(c-'a');E++;}}
    const int di[]={-1,1,0,0},dj[]={0,0,-1,1};
    for(auto m:moves){int i=board_info.row[m.p],j=board_info.col[m.p],k=m.k,d=m.d,l=m.l;
        require407(i>=0&&i<N&&j>=0&&j<N&&d<4&&l>=1&&l<=8,"command bounds");
        auto &from=tower[i*N+j];int h=from.size();require407(k<h&&l<=k+1,"height/range");int x=i,y=j;
        for(int step=0;step<l;step++){x+=di[d];y+=dj[d];require407(x>=0&&x<N&&y>=0&&y<N&&board_info.C[x][y]!='#',"wall");}
        auto &to=tower[x*N+y];require407(int(to.size())+h-k<=8,"capacity");
        for(int q=h-1;q>=k;q--)to.push_back(from[q]);from.resize(k);
        auto home=[&](vector<int>&v,char c){if(c>='A'&&c<='L')while(!v.empty()&&v.back()==c-'A'){v.pop_back();E--;}};
        home(from,board_info.C[i][j]);home(to,board_info.C[x][y]);
    }require407(E==0,"E=0");
}
void write407(ostream&out,const vector<Move>&moves){out<<'[';bool first=true;for(auto m:moves){if(!first)out<<',';first=false;out<<'['<<board_info.row[m.p]<<','<<board_info.col[m.p]<<','<<int(m.k)<<','<<int(m.d)<<','<<int(m.l)<<']';}out<<']';}
void fixtures407(TemporalLNS&lns,const vector<Move>&plan){
    vector<Move>a(plan.begin(),plan.begin()+4),b=a,c(plan.begin(),plan.begin()+3);b[0].d=(b[0].d+1)%4;
    vector<pair<double,int>>order;for(int p=0;p<board_info.cell_count&&order.size()<2;p++)if(board_info.initial[p])order.push_back({0,p});
    auto test=[&](vector<pair<bool,vector<Move>>> responses,bool expected,vector<Move> result,vector<Move> alternate){
        const int free=state_pool.free_count;vector<Move>r,e;
        {State initial=board_info.initial;lns.fixture_responses=move(responses);lns.fixture_at=0;
        bool ok=lns.mock_insert_two_orders(initial,{},order,100,r,e);require407(ok==expected,"mock success");
        require407(TemporalLNS::same_moves(r,result)&&TemporalLNS::same_moves(e,alternate),"mock selection");}
        require407(state_pool.free_count==free,"mock pool return");
    };
    test({{false,{}},{false,{}}},false,{},{});
    test({{false,{}},{true,a},{true,b}},true,b,{});
    test({{true,a},{true,a},{false,{}}},true,a,{});
    test({{true,a},{true,a},{true,c},{true,c}},true,c,{});
    test({{true,a},{true,a},{true,a},{true,a}},true,a,{});
    test({{true,a},{true,a},{true,b},{true,b}},true,a,b);
}
int main(int argc,char**argv){
 try{
    require407(argc==3,"case and saved path args");int case_id=stoi(argv[1]);
    time_keeper.start_=chrono::steady_clock::now();time_keeper.time_limit_sec=numeric_limits<double>::infinity();
    board_info.read();state_pool.prepare(board_info.cell_count);
    vector<Move>plan;ifstream in(argv[2]);require407(bool(in),"saved file");int i,j,k,l;char d;
    while(in>>i>>j>>k>>d>>l){int dir=string("UDLR").find(d);require407(i>=0&&i<board_info.N&&j>=0&&j<board_info.N&&dir<4,"saved command");plan.push_back({int16_t(board_info.cell_id[i][j]),uint8_t(k),uint8_t(dir),uint8_t(l)});}
    replay407(plan);TemporalLNS lns;if(case_id==0){fixtures407(lns,plan);dispatch407(plan);}
    rng.x=407001+case_id;lns.initialize_spatial_cuts();lns.rebuild_all(plan);
    vector<vector<int>>selected;set<vector<int>>seen;
    for(const auto&cand:lns.candidates){if(cand.ids.size()<2||cand.ids.size()>4)continue;auto ids=cand.ids;sort(ids.begin(),ids.end());if(!seen.insert(ids).second)continue;selected.push_back(cand.ids);if(selected.size()==32)break;}
    int ordinal=0;
    for(const auto&ids:selected){
      vector<Move>raw,alternate,parent,base,first,second;bool extracted=false,ok=false,parent_ok=false,first_ok=false,second_ok=false;
      vector<pair<double,int>>order;uint64_t before=0,after=0;const int free=state_pool.free_count;
      {State initial;
       extracted=lns.extract(plan,ids,base,initial);
       rng.x=407001+case_id*1000+ordinal;
       for(int id:ids){double w=board_info.floor_dist[id][board_info.nest_pos_by_code[board_info.initial[id]]];w*=0.6+0.8*rng.unit();order.emplace_back(-w,id);}sort(order.begin(),order.end());before=rng.x;
       if(extracted){
        ok=lns.insert_two_orders(initial,base,order,int(plan.size())+4,raw,alternate);after=rng.x;
        first=lns.diagnostic_completed[0];second=lns.diagnostic_completed[1];first_ok=lns.diagnostic_success[0];second_ok=lns.diagnostic_success[1];
        parent_ok=lns.parent_insert_two_orders(initial,base,order,int(plan.size())+4,parent);
        require407(rng.x==before&&after==before,"new RNG draw");
        if(alternate.empty()){require407(ok==parent_ok,"parent success mismatch");if(ok)require407(TemporalLNS::same_moves(raw,parent),"parent strict/failure mismatch");}
       }
      }
      require407(state_pool.free_count==free&&free==4,"pre-polish pool");
      if(first_ok)replay407(first);if(second_ok)replay407(second);
      vector<Move>polished,other;double elapsed=0;
      if(ok){replay407(raw);polished=smooth_routes(raw);replay407(polished);}
      if(!alternate.empty()){replay407(alternate);auto begin=chrono::steady_clock::now();other=smooth_routes(alternate);elapsed=chrono::duration<double,milli>(chrono::steady_clock::now()-begin).count();replay407(other);}
      require407(state_pool.free_count==4,"post-polish pool");require407(rng.x==before,"smoothing RNG");
      bool win=!alternate.empty()&&other.size()<polished.size();
      cout<<"{\"case\":"<<case_id<<",\"ordinal\":"<<ordinal++<<",\"ids\":[";for(size_t x=0;x<ids.size();x++){if(x)cout<<',';cout<<ids[x];}
      cout<<"],\"order\":[";for(size_t x=0;x<order.size();x++){if(x)cout<<',';cout<<order[x].second;}
      cout<<"],\"extracted\":"<<extracted<<",\"ok\":"<<ok<<",\"parent_ok\":"<<parent_ok<<",\"first_ok\":"<<first_ok<<",\"second_ok\":"<<second_ok<<",\"first_length\":"<<first.size()<<",\"second_length\":"<<second.size()<<",\"raw_tie\":"<<(first_ok&&second_ok&&first.size()==second.size())<<",\"distinct\":"<<!alternate.empty()<<",\"first_is_current\":"<<TemporalLNS::same_moves(raw,plan)<<",\"polished_length\":"<<polished.size()<<",\"alternate_polished_length\":"<<other.size()<<",\"win\":"<<win<<",\"extra_ms\":"<<elapsed<<",\"rng\":"<<before<<",\"pool\":"<<state_pool.free_count<<",\"raw\":";write407(cout,raw);cout<<",\"alternate\":";write407(cout,alternate);cout<<",\"polished\":";write407(cout,polished);cout<<",\"alternate_polished\":";write407(cout,other);cout<<"}\n";
    }
    cerr<<"case="<<case_id<<" selected="<<selected.size()<<" pool="<<state_pool.free_count<<" fixtures="<<(case_id==0?6:0)<<"\n";
 }catch(const exception&e){cerr<<"FAIL "<<e.what()<<'\n';return 1;}return 0;
}
'''
s=s.replace('int main(int argc,char**argv){',fixture_dispatch+'\nint main(int argc,char**argv){',1)
(r/'adhoc/bin/v407_diagnostic.cpp').write_text(s)
