# Source from the AHC072 project root. Local official toolchain installation.
export RUSTUP_HOME=/tmp/ahc072-toolchain/rustup
export CARGO_HOME=/tmp/ahc072-toolchain/cargo
export RUSTUP_TOOLCHAIN=1.89.0
export PATH="$CARGO_HOME/bin:$PATH"
export LD_LIBRARY_PATH="/tmp/ahc072-toolchain/gcc15/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export CXX="$PWD/adhoc/scripts/cloud_gcc15.py"
export CARGO_BUILD_JOBS=8
