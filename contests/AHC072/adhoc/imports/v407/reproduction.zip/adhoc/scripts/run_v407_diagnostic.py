from pathlib import Path
import hashlib,json,subprocess,concurrent.futures,time
r=Path(__file__).resolve().parents[2];o=r/'results/analysis/v407';out=o/'diagnostic_cases';out.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((o/'frozen_manifest.json').read_text());assert sha(r/'src/bin/v407_polished_two_order.cpp')==m['source_sha256']
with (o/'diagnostic_started.json').open('x') as f:json.dump({'started':time.time(),'source_sha256':m['source_sha256'],'binary_sha256':sha(o/'diagnostic'),'generator_sha256':sha(r/'adhoc/scripts/build_v407_diagnostic.py'),'diagnostic_source_sha256':sha(r/'adhoc/bin/v407_diagnostic.cpp'),'prereg_sha256':sha(r/'notes/experiments/v407.md')},f,indent=2)
def run(i):
 stem=f'{i:04}';inp=r/f'tools/in/{stem}.txt';saved=r/f'results/analysis/v401/outputs/{stem}.txt'
 with inp.open('rb') as stdin,(out/f'{stem}.jsonl').open('wb') as stdout,(out/f'{stem}.stderr').open('wb') as stderr:
  p=subprocess.run([str(o/'diagnostic'),str(i),str(saved)],stdin=stdin,stdout=stdout,stderr=stderr,cwd=r,timeout=120)
 return {'case':stem,'returncode':p.returncode,'input_sha256':sha(inp),'saved401_sha256':sha(saved),'diagnostic_jsonl_sha256':sha(out/f'{stem}.jsonl')}
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
 records=list(pool.map(run,range(100)))
(o/'diagnostic_run_records.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({'cases':len(records),'failures':[x for x in records if x['returncode']]}))
