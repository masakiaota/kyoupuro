#!/usr/bin/env python3
"""GCC15 wrapper. v311 LOCAL-only cloud budget copy; tracked source unchanged."""
import os, sys
from pathlib import Path
root=Path(__file__).resolve().parents[2]
args=sys.argv[1:]
source=root/'src/bin/v311_neural_multistart.cpp'
if '-DLOCAL' in args and str(source) in args:
    raw=source.read_text()
    old='constexpr double LOCAL_TIME_RATIO = 0.80;'
    assert raw.count(old)==1
    target=root/'results/analysis/cloud_baseline/v311_neural_multistart_cloud_local.cpp'
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_text(raw.replace(old,'constexpr double LOCAL_TIME_RATIO = 1.90 / 1.930;'))
    args=[str(target) if a==str(source) else a for a in args]
base='/tmp/ahc072-toolchain/gcc15/usr'
args += ['-L'+base+'/lib/x86_64-linux-gnu','-Wl,-rpath,'+base+'/lib/x86_64-linux-gnu']
os.execv(base+'/bin/x86_64-linux-gnu-g++-15',[base+'/bin/x86_64-linux-gnu-g++-15',*args])
