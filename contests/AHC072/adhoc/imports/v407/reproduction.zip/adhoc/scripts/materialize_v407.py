from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parents[2]; o=r/'results/analysis/v407';o.mkdir(exist_ok=True,parents=True)
p=r/'adhoc/imports/v401/original.cpp.txt';s=p.read_text();assert hashlib.sha256(p.read_bytes()).hexdigest()=='0c241cc3a862d12faf100050df4ea3bafa3c520261d81e5237a41e3c54f25658'
assert (r/'notes/experiments/v407.md').exists()
def sub(a,b):
 global s
 assert s.count(a)==1,(a[:100],s.count(a));s=s.replace(a,b,1)
s=s.replace(s.splitlines()[0],'// v407_polished_two_order.cpp',1)
sub('''                         vector<Move>& result) {
        const int n=int(order.size());assert(2<=n&&n<=4);''','''                         vector<Move>& result,vector<Move>& equal_alternate) {
        equal_alternate.clear();
        const int n=int(order.size());assert(2<=n&&n<=4);''')
sub('''                // 挿入では操作数が増えるため、完成済みの解より短くならない第2順序を枝刈りする。
                const int cap=min(allowance,best_length_value-1)-int(tail.size());''','''                // Keep equal-raw completions for the existing route smoother.
                // No State may survive into that later, four-slot-pool stage.
                const int cap=min(allowance,best_length_value)-int(tail.size());''')
sub('''            LOCAL_NOTE(
                ++local_two_order.finished[branch];
                if(branch) {''','''            LOCAL_NOTE(++local_two_order.finished[branch];)
            if(branch&&int(tail.size())==best_length_value) {
                LOCAL_ONLY(trace.count_by("v407_raw_ties",1));
                if(!same_moves(tail,result)) {
                    equal_alternate=move(tail);
                    LOCAL_ONLY(trace.count_by("v407_distinct_raw_ties",1));
                }
                continue; // First order wins raw ties until polishing says otherwise.
            }
            LOCAL_NOTE(
                if(branch) {''')
sub('''            vector<Move> trial;
            bool reorder''','''            vector<Move> trial,equal_alternate;
            LOCAL_NOTE(bool polished_alternate_selected=false;)
            bool reorder''')
sub('''ok=insert_two_orders(initial,base,order,int(current.size())+4,rebuilt);''','''ok=insert_two_orders(initial,base,order,int(current.size())+4,rebuilt,equal_alternate);''')
sub('''            if(same_moves(trial,current)){++duplicates;continue;}
            vector<Move> polished;
            // 経路短縮は操作を再生し、変更区間の全盤面一致と最後の全帰巣を確認する。
            try{polished=smooth_routes(trial);}catch(const exception&){LOCAL_NOTE(trace.count_by("lns_invalid_candidates", 1);)continue;}''','''            if(equal_alternate.empty()&&same_moves(trial,current)){++duplicates;continue;}
            vector<Move> polished;
            // Extraction and reinsertion States have all left scope. Smooth the
            // two equal-raw vectors sequentially; never smooth the winner twice.
            try {
                polished=smooth_routes(trial);
                if(!equal_alternate.empty()) {
                    LOCAL_NOTE(const double alternate_started=time_keeper.exact_elapsed_sec();)
                    auto alternate_polished=smooth_routes(equal_alternate);
                    LOCAL_ONLY(trace.count_by("v407_polished_pairs",1);
                        trace.add_time_ms("v407_extra_smoothing",(time_keeper.exact_elapsed_sec()-alternate_started)*1000.0));
                    if(alternate_polished.size()<polished.size()) {
                        LOCAL_ONLY(trace.count_by("v407_polished_wins",1);
                            trace.count_by("v407_direct_savings",int(polished.size()-alternate_polished.size())));
                        LOCAL_NOTE(polished_alternate_selected=true;local_two_order_alternate=true;)
                        polished=move(alternate_polished);
                    } else {
                        LOCAL_ONLY(trace.count_by("v407_polished_ties",alternate_polished.size()==polished.size()));
                    }
                }
            }catch(const exception&){LOCAL_NOTE(trace.count_by("lns_invalid_candidates", 1);)continue;}''')
sub('''            if(accept) {
                LOCAL_NOTE(
                    search_reductions.accepted_shortened''','''            if(accept) {
                LOCAL_ONLY(trace.count_by("v407_selected_accepted",polished_alternate_selected));
                LOCAL_NOTE(
                    search_reductions.accepted_shortened''')
sub('''                if(polished.size()<best.size()) {
                    int saved=int(best.size()-polished.size());''','''                if(polished.size()<best.size()) {
                    LOCAL_ONLY(trace.count_by("v407_selected_best_updates",polished_alternate_selected));
                    int saved=int(best.size()-polished.size());''')
path=r/'src/bin/v407_polished_two_order.cpp';path.write_text(s)
m={'parent_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'preregistered_note_sha256':hashlib.sha256((r/'notes/experiments/v407.md').read_bytes()).hexdigest(),'total_strict_lt':19876,'relative_condition':'relative_v800(v407)>relative_v800(cloud401), same exact v800 reference, pending original rows','jobs':8,'local_ratio':'1.90/1.930','max_external_ms':2000,'case_candidate_limit':32,'case_rng_seed':'407001+case_index','problem_rng_seed':'407001+case_index*1000+candidate_ordinal','minimum_natural_strict_polishing_reversals':1}
(o/'frozen_manifest.json').write_text(json.dumps(m,indent=2)+'\n')
print(m)
