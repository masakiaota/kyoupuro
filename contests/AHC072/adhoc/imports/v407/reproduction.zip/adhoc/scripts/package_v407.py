from pathlib import Path
import hashlib,json,zipfile
r=Path(__file__).resolve().parents[2];o=r/'results/analysis/v407';dest=r/'adhoc/imports/v407';dest.mkdir(parents=True,exist_ok=True);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();source=r/'src/bin/v407_polished_two_order.cpp';frozen=json.loads((o/'frozen_manifest.json').read_text());assert sha(source)==frozen['source_sha256']
(o/'REPRODUCE.txt').write_text('''v407 frozen equal-raw two-order route-smoothing selection. Private cloud evidence.
Source and note are separate authoritative files, not duplicated in this ZIP.
Exact parent: adhoc/imports/v401/original.cpp.txt SHA0c241cc3a862d12faf100050df4ea3bafa3c520261d81e5237a41e3c54f25658, already on private main.
Use source adhoc/scripts/cloud_toolchain_env.sh for GCC15.3 / Rust1.89.
materialize_v407.py reconstructs exact candidate. audit_v407.py builds LOCAL/nonLOCAL and records complete preprocessing diffs. build_v407_diagnostic.py generates the bounded diagnostic using saved cloud401 outputs (already in v401 archive); no solver main, NN or SA execution.
Diagnostic input selection is first32 eligible generated/dedup2–4ID candidates on each100 saved401plan, fixed seeds recorded in frozen_manifest. Natural strict reversal gate is required and passed. Both synthetic dispatch and actual complete plans were checked. run_v407_diagnostic.py is one-execution guarded; completed artifacts are supplied.
run_v407_eval.py has source hash, diagnostic/review gates and one-evaluation guard; standard tools/in100 LOCAL1.90/1.930 j8. Additional runs require a new explicit user instruction, not noise tests.
summarize_v407.py reads saved outputs and independently replays without solver execution. Restore archived outputs to recorded stdout_path if needed.
Requested exact historical v800 reference remains missing; no substitute index was computed. Compare v407 and cloud401 under the same exact reference only when supplied. No adoption while that comparison is pending.
Source, note and backlog are authoritative outside ZIP. Binary/input/full preprocessing bodies are excluded; hashes retained. All3200 diagnostic scalar rows and24natural witness vectors, source/preprocessed diffs, all official outputs/traces/records and independent replay evidence included. Full3200 vector records and parsed duplicate case_traces remain private with hashes in full_artifact_hashes.json.
''')
# Keep every scalar diagnostic row and natural witness, avoiding repeated vectors.
rows=[];witnesses=[]
for path in sorted((o/'diagnostic_cases').glob('*.jsonl')):
 for line in path.read_text().splitlines():
  row=json.loads(line)
  if row['win']:witnesses.append(row)
  rows.append({k:v for k,v in row.items() if k not in ('raw','alternate','polished','alternate_polished')})
(o/'diagnostic_scalar_rows.jsonl').write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in rows))
(o/'natural_witnesses.json').write_text(json.dumps(witnesses,separators=(',',':'))+'\n')
artifacts=[*(o/'diagnostic_cases').glob('*'),o/'case_traces.json',source,r/'adhoc/imports/v401/original.cpp.txt',*o.glob('*.ii'),o/'v407_local',o/'v407_nonlocal',o/'diagnostic',r/'adhoc/bin/v407_diagnostic.cpp',r/'target/release/v407_polished_two_order']
(o/'full_artifact_hashes.json').write_text(json.dumps({str(p.relative_to(r)):sha(p) for p in artifacts if p.is_file()},indent=2))
files=[p for p in sorted(o.rglob('*')) if p.is_file() and p.suffix in ('.json','.jsonl','.csv','.log','.patch','.md','.txt','.stderr','.err','.sha256')]
files=[p for p in files if p.parent.name!='diagnostic_cases' and p.name!='case_traces.json']
files+=[r/'results/analysis/v401/records.json']
files+=list((r/'adhoc/scripts').glob('*v407*.py'))
files+=[r/'adhoc/scripts'/n for n in ['replay_slime_output.py','cloud_gcc15.py','cloud_toolchain_env.sh']]
files=list(dict.fromkeys(files));manifest={str(p.relative_to(r)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in files}
with zipfile.ZipFile(dest/'reproduction.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files:z.write(p,str(p.relative_to(r)))
 z.writestr('V407_CONTENT_MANIFEST.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(dest/'reproduction.zip') as z:
 assert z.testzip() is None
 for name,item in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==item['sha256']
external={'version':'v407','source_sha256':sha(source),'note_sha256':sha(r/'notes/experiments/v407.md'),'backlog_sha256':None,'backlog_status':'pending parent merge of results/analysis/v407/backlog_update.md; do not publish current unrelated backlog snapshot','zip_sha256':sha(dest/'reproduction.zip'),'zip_bytes':(dest/'reproduction.zip').stat().st_size,'file_count':len(files),'publication_files':['src/bin/v407_polished_two_order.cpp','notes/experiments/v407.md','notes/backlog.md','adhoc/imports/v407/reproduction.zip','adhoc/imports/v407/manifest.json'],'files':manifest};(dest/'manifest.json').write_text(json.dumps(external,indent=2));print(json.dumps({k:v for k,v in external.items() if k!='files'},indent=2))
