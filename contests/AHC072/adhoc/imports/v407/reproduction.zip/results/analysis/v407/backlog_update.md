# v407 backlog update draft (not yet applied to shared backlog)

Remove the existing B-38 bullet from 未着手 and insert under 決着済み:

- **[B-38] 再挿入の同手数の別経路を経路短縮後に比較する** → [v407](experiments/v407.md) 棄却（固定cloud In100提出候補）。保存cloud401の固定3,200partial診断で異列同raw703組、自然polishing逆転24組/37手を確認し、全合法E=0・RNG/pool/影響外親一致・13fixtureを通過。公式In100では34,592組比較/1,418逆転/局所1,926手が発動したが、401比+50手（33勝20分47敗）で主条件未達。全100E=0/errors0/pool4、最大1931ms（全件外部1900ms超）。正確なv800相対は元100件未取得で未計算、代用指数なし。再開条件: 新たな明示指示で仕事量/費用と目的整合を両立させる別条件を事前登録できる場合。

Add one observation with the next available observation ID, preserving every remote addition:

同raw長の再挿入列は、既存smooth_routes後に厳密な優劣が生じうる。v407固定cloud401診断の異列703組中24組で第2案が短縮し、raw同点で捨てると候補を失うことを確認した。ただし通常予算では局所保存1,926手が最終総手数改善へ結び付かず、401比+50手で棄却。追加探索/比較費用と時間依存経路を含む単回結果であり、同点比較一般の無効を示さない。根拠:[v407](experiments/v407.md)、B-38。
