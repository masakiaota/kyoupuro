---
id: v407
parents:
  - "[[v401]]"
---
# v407: equal-raw two-order selection after route smoothing

## 実験前

- 仮説: B-38の同手数で異なる再挿入列は、既存smooth_routes後の長さが異なりうる。raw同手数の第2順序も比較すれば最終目的に整合する選択ができる。旧v028の1,104/3,890同手数別列は着想の根拠であり、polished短縮の証明ではない。
- 変更: 正確なcloud401 `adhoc/imports/v401/original.cpp.txt` SHA256 `0c241cc3a862d12faf100050df4ea3bafa3c520261d81e5237a41e3c54f25658` から派生。既存2–4ID再挿入の第2順序capだけを同手数まで許し、異なる同raw長列をMove vectorとして外へ返す。抽出/分岐State破棄後に順に既存smooth_routesへ通し、厳密短縮なら第2列、同手数なら第1列。raw第1列=currentでも比較し、勝者を再smoothしない。raw厳密短縮/失敗は旧選択を維持する。NN全モデル、portfolio、候補生成/選択、RNG生成、SA、後段reduction、最終処理、pool4、時間管理は維持。新探索/学習なし。LOCALと非LOCAL両方に適用。
- 機構確認: 保存cloud401全100出力のみから、既存候補生成順と同一ID集合dedupで各case先頭32件の2–4ID regular候補（候補生成の依存関係由来集合を含む）を固定。抽出成功や結果長で選別せず、候補32件内の抽出失敗も記録。candidate生成RNGはcase index+407001、各問題の挿入順RNGは407001+case index*1000+candidate ordinal。既存weight式で順序を作る。診断の既存挿入tie重みは既定support_weight=5/ride_weight=1固定。タイマーは診断でのみ無期限化し、solver全体/NN/SAは実行しない。各問題を固定順で一度だけ診断。独立配列replayで元/完成raw/完成polishedの合法E=0、親cap版と影響外分岐一致、RNG不変、全pool返却を検証。合成fixtureで失敗/成功/raw厳密短縮/同raw同列/異列/同polished/strict選択を検証。**自然発生した異列同raw第2案がsmooth後に厳密短縮する例が1件以上必須**。なければdiagnostic-negativeで停止し本評価なし。固定problem hashes/coverage/raw ties/distinct/polished wins/direct savings/追加時間を保存。独立review gate前に本評価しない。
- 採否基準: tools/in100、GCC15.3、LOCAL比1.90/1.930、j8、通常warmup以外各入力一度。合計T<19,876かつ**同一の正確なv800参照による相対(v407)>相対(cloud401)**。参照v800の元100件は未取得であり数値/式の適用対象を取得後に確認するが、両者に同一参照/同一式を適用する厳密改善条件は固定。旧v311補助指数やv800含有歴代MINを代用しない。v800不足時は相対未判定、採用不可。絶対不達は相対未判定でも棄却。全100件公式採点/独立合法E=0、errors/recovery0、pool4全返却、最大外部時間<=2000ms必須。局所保存手数は最終改善と区別。再評価/調整/ノイズ測定/408なし、採用指定v214維持。
- 履歴照合: 2026-10-04 07:44 UTC、実装前。plannerはmain f512c9eeのbacklog全文/全experiment filename・Front Matter、関連028/029/057/401/406/304–310を照合。B-38未検証。v029は第2順序廃止で本案とは異なり、v057はraw選択保持。B168/169の新混合・学習は範囲外。notes/notations、important_propertiesは変更しない。

## 実験後

未実行。
