from pathlib import Path
import hashlib,json,subprocess,time
r=Path(__file__).resolve().parents[2];o=r/'results/analysis/v409';out=o/'diagnostic_cases';out.mkdir(exist_ok=True);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((o/'frozen_manifest.json').read_text());assert sha(r/'src/bin/v409_zero_cap_dead_frontier.cpp')==m['source_sha256']
review=json.loads((o/'pre_run_review.json').read_text());assert review['diagnostic_run_approved'] is True
files=[r/'src/bin/v409_zero_cap_dead_frontier.cpp',r/'adhoc/imports/v401/original.cpp.txt',r/'notes/experiments/v409.md',r/'notes/backlog.md',r/'adhoc/bin/v409_diagnostic.cpp',r/'adhoc/scripts/build_v409_diagnostic.py',r/'adhoc/scripts/v409_diagnostic_main.cpp.txt',o/'diagnostic']
with (o/'diagnostic_started.json').open('x') as f:json.dump({'started':time.time(),'hashes':{str(p.relative_to(r)):sha(p) for p in files},'paired_passes':1,'cases':100,'ordering':'parent first when (case*32+ordinal)%2==0','clock':'CLOCK_PROCESS_CPUTIME_ID','logging':'symmetric full-call capture duration subtracted; formatting/comparison outside timer'},f,indent=2)
records=[]
for i in range(100):
 stem=f'{i:04}';inp=r/f'tools/in/{stem}.txt';saved=r/f'results/analysis/v401/outputs/{stem}.txt'
 with inp.open('rb') as stdin,(out/f'{stem}.jsonl').open('wb') as stdout,(out/f'{stem}.stderr').open('wb') as stderr:
  p=subprocess.run([str(o/'diagnostic'),str(i),str(saved)],stdin=stdin,stdout=stdout,stderr=stderr,cwd=r,timeout=120)
 record={'case':stem,'returncode':p.returncode,'input_sha256':sha(inp),'saved401_sha256':sha(saved),'diagnostic_jsonl_sha256':sha(out/f'{stem}.jsonl')};records.append(record)
 (o/'diagnostic_run_records.json').write_text(json.dumps(records,indent=2)+'\n')
 if p.returncode:raise RuntimeError(f'case {stem} failed; no automatic rerun')
 if i%10==9:print(f'{i+1}/100 complete',flush=True)
print(json.dumps({'cases':len(records),'failures':[x for x in records if x['returncode']]}))
