from pathlib import Path
r=Path(__file__).resolve().parents[2];s=(r/'src/bin/v409_zero_cap_dead_frontier.cpp').read_text();p=(r/'adhoc/imports/v401/original.cpp.txt').read_text()
s=s.replace('class TemporalLNS {','class TemporalLNS {\npublic:',1).replace('TowerBits* take() { return free_slot[--free_count]; }','TowerBits* take() { if(free_count<=0)throw logic_error("pool exhausted"); return free_slot[--free_count]; }')
a=p.index('    bool insert_at(');b=p.index('\n    bool insert(',a);parent=p[a:b].replace('bool insert_at(','bool parent_insert_at(',1)
a=s.index('    bool insert_at(');b=s.index('\n    bool insert(',a);candidate=s[a:b].replace('bool insert_at(','bool candidate_insert_at(',1)
candidate=candidate.replace('if(cap==0&&reachable_count==0&&label[GOAL].cost==infinite_cost)return false;', 'if(cap==0&&reachable_count==0&&label[GOAL].cost==infinite_cost){diagnostic_early=true;diagnostic_skipped=int(base.size())-t-1;return false;}')
fields=r'''
    struct DiagnosticCall {int source,color,gap,cap,events,skipped;bool early,ok;uint64_t rng_after;vector<Move> result;};
    bool diagnostic_parent=false,diagnostic_early=false;int diagnostic_skipped=0;
    vector<DiagnosticCall> diagnostic_calls;int64_t diagnostic_log_ns=0;
    static int64_t cpu_ns(){timespec t;clock_gettime(CLOCK_PROCESS_CPUTIME_ID,&t);return int64_t(t.tv_sec)*1000000000+t.tv_nsec;}
    bool insert_at(const State&initial,const vector<Move>&base,int source,int color,int gap,int cap,vector<Move>&result){
        diagnostic_early=false;diagnostic_skipped=0;
        bool ok=diagnostic_parent?parent_insert_at(initial,base,source,color,gap,cap,result):candidate_insert_at(initial,base,source,color,gap,cap,result);
        auto start=cpu_ns();
        diagnostic_calls.push_back({source,color,gap,cap,int(base.size()),diagnostic_skipped,diagnostic_early,ok,rng.x,ok?result:vector<Move>{}});
        diagnostic_log_ns+=cpu_ns()-start;
        return ok;
    }
'''
s=s[:a]+fields+candidate+'\n'+parent+s[b:];s=s[:s.index('int main() {')]
s+=(r/'adhoc/scripts/v409_diagnostic_main.cpp.txt').read_text()
(r/'adhoc/bin/v409_diagnostic.cpp').write_text(s)
