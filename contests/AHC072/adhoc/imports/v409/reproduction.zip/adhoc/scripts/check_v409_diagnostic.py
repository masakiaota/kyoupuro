from pathlib import Path
import json,hashlib
r=Path(__file__).resolve().parents[2];o=r/'results/analysis/v409';records=json.loads((o/'diagnostic_run_records.json').read_text());assert len(records)==100 and not any(x['returncode'] for x in records)
def setup(case):
 lines=(r/f'tools/in/{case:04}.txt').read_text().splitlines();N,K=map(int,lines[0].split());grid=lines[1:N+1];cells=[(i,j) for i in range(N) for j in range(N) if grid[i][j]!='#'];index={p:n for n,p in enumerate(cells)};initial=[];nests=[]
 for i,j in cells:
  c=grid[i][j];initial.append([ord(c)-96] if c.islower() else []);nests.append(ord(c)-64 if c.isupper() else 0)
 return cells,index,initial,nests

def replay(cells,index,initial,nests,moves):
 a=[v[:] for v in initial];ds=[(-1,0),(1,0),(0,-1),(0,1)]
 for p,k,d,l in moves:
  assert 0<=p<len(cells) and 0<=k<len(a[p]) and 0<=d<4 and 1<=l<=k+1
  i,j=cells[p];di,dj=ds[d]
  for step in range(1,l+1):assert (i+di*step,j+dj*step) in index
  q=index[i+di*l,j+dj*l];moving=a[p][k:];assert len(a[q])+len(moving)<=8;a[p]=a[p][:k];a[q].extend(reversed(moving))
  for c in (p,q):
   while a[c] and a[c][-1]==nests[c]:a[c].pop()
 return a
rows=[];fixtures=[];summaries=[]
for record in records:
 case=int(record['case']);cells,index,initial,nests=setup(case)
 path=o/'diagnostic_cases'/f'{case:04}.jsonl';assert hashlib.sha256(path.read_bytes()).hexdigest()==record['diagnostic_jsonl_sha256']
 for line in path.read_text().splitlines():
  row=json.loads(line)
  if 'fixture' in row:
   assert row['pass'];parent,candidate=row['parent'][0],row['candidate'][0];assert parent['ok']==candidate['ok'];words=row['initial'];bg=[]
   for w in words:
    v=[]
    while w:v.append(w&15);w>>=4
    bg.append(v)
   background=replay(cells,index,bg,row['nests'],row['base'])
   for c in (parent,candidate):
    if c['ok']:
     augmented=[v[:] for v in bg];augmented[c['source']].insert(c['gap'],c['color']);assert replay(cells,index,augmented,row['nests'],c['moves'])==background
   fixtures.append(row);continue
  if 'summary_case' in row:assert row['pool']==4;summaries.append(row);continue
  assert row['parent_ns']>0 and row['candidate_ns']>0
  assert len(row['parent_calls'])==len(row['candidate_calls'])
  for a,b in zip(row['parent_calls'],row['candidate_calls']):
   for k in ['source','color','gap','cap','events','ok','rng_after','moves']:assert a[k]==b[k],(case,k)
   assert not a['early'] and not a['skipped']
   if b['early']:assert not a['ok'] and b['cap']==0 and b['skipped']>=0
  assert row['parent_moves']==row['candidate_moves']
  if row['ok']:assert not any(replay(cells,index,initial,nests,row['candidate_moves']))
  rows.append(row)
assert len(fixtures)==10 and len(summaries)==100
natural=[(x['case'],c) for x in rows for c in x['candidate_calls'] if c['early'] and c['skipped']>0];cases=sorted(set(case for case,c in natural))
strata={}
for name,predicate in [('all',lambda x:True),('M<=50',lambda x:x['M']<=50),('51<=M<=100',lambda x:51<=x['M']<=100),('M>=101',lambda x:x['M']>=101)]:
 group=[x for x in rows if predicate(x)];pa=sum(x['parent_ns'] for x in group);ch=sum(x['candidate_ns'] for x in group);strata[name]={'sets':len(group),'cases':len(set(x['case'] for x in group)),'parent_ns':pa,'candidate_ns':ch,'ratio':ch/pa if pa else None,'strictly_faster':ch<pa}
calls=[c for x in rows for c in x['candidate_calls']]
result={'identity_pass':True,'fixtures_pass':True,'independent_replay_pass':True,'cases':100,'selected_sets':len(rows),'complete_successes':sum(x['ok'] for x in rows),'insert_calls':len(calls),'cap_zero_calls':sum(c['cap']==0 for c in calls),'early_returns':sum(c['early'] for c in calls),'natural_saved_suffix_cases':cases,'natural_saved_suffix_calls':len(natural),'skipped_events':sum(c['skipped'] for c in calls),'parent_events':sum(c['events'] for c in calls if c['cap']>=0),'strata':strata,'gate_pass':len(cases)>=2 and strata['all']['strictly_faster'] and strata['M>=101']['strictly_faster'],'official_evaluation_run':False,'limitations':'Single bounded paired CPU measurement; no noise reruns. Capturing full call trace is symmetric and excluded by measured CPU subtraction; timer overhead retained. Trace allocation/copies, although subtracted, can perturb cache/allocator state. Saved final plans and fixed dependency-expanded sets, not a whole timed LNS trajectory.'}
(o/'diagnostic_result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
