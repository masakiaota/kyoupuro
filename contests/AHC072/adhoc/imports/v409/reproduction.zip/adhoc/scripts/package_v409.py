from pathlib import Path
import hashlib,json,zipfile,copy
r=Path(__file__).resolve().parents[2];o=r/'results/analysis/v409';dest=r/'adhoc/imports/v409';dest.mkdir(parents=True,exist_ok=True);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();source=r/'src/bin/v409_zero_cap_dead_frontier.cpp';frozen=json.loads((o/'frozen_manifest.json').read_text());assert sha(source)==frozen['source_sha256']
compact=[];rawhashes={}
for path in sorted((o/'diagnostic_cases').glob('*')):
 rawhashes[str(path.relative_to(r))]={'sha256':sha(path),'bytes':path.stat().st_size}
 if path.suffix!='.jsonl':continue
 for line in path.read_text().splitlines():
  row=json.loads(line)
  if 'fixture' not in row:
   for key in ['parent_calls','candidate_calls']:
    for c in row.get(key,[]):
     moves=c.pop('moves');c['move_count']=len(moves);c['moves_sha256']=hashlib.sha256(json.dumps(moves,separators=(',',':')).encode()).hexdigest()
   for key in ['parent_moves','candidate_moves']:
    if key in row:
     moves=row.pop(key);row[key+'_count']=len(moves);row[key+'_sha256']=hashlib.sha256(json.dumps(moves,separators=(',',':')).encode()).hexdigest()
  compact.append(row)
(o/'diagnostic_compact.jsonl').write_text(''.join(json.dumps(x,separators=(',',':'))+'\n' for x in compact));(o/'diagnostic_raw_hashes.json').write_text(json.dumps(rawhashes,indent=2)+'\n')
(o/'REPRODUCE.txt').write_text('''v409, one exact cap==0 dead-frontier certificate. Private cloud evidence.
Authoritative source, completed note, latest backlog and outer manifest are separate publication files, not duplicated in this ZIP.
Direct parent adhoc/imports/v401/original.cpp.txt SHA256 0c241cc3a862d12faf100050df4ea3bafa3c520261d81e5237a41e3c54f25658.
source adhoc/scripts/cloud_toolchain_env.sh selects GCC15.3/Rust1.89.
materialize_v409.py documents the exact minimal patch. audit_v409.py builds both modes and compares complete preprocessing outside insert_at. GCC uninitialized attribute prevents auto-zero overhead on cap>0; generated assembly review recorded.
build_v409_diagnostic.py plus v409_diagnostic_main.cpp.txt creates the fixed harness. First32 exact-ID-deduplicated successful dependency expansions per input in original candidate order, saved401 plans, seeds409001+case and409001+1000*case+ordinal, natural caps. One paired process-CPU pass, alternating variant order. Full repair+reinsertion+work-array destruction. Logging CPU subtracted symmetrically but cache/allocator perturbation remains a limitation. It is not a general solver throughput guarantee.
Ten frozen boundary fixtures. Every call success/full successful move list/RNG and final completion compared. Independent color-stack replay validates final natural completions and successful synthetic fixture board identity. Natural gate: saving in>=2 cases, full workload CPU lower and M>=101 lower. Gate passed and reviewer authorized exactly one standard tools/in100 LOCAL1.90/1.930 -j8 evaluation.
run_v409_diagnostic.py and run_v409_eval.py have one-run sentinels; DO NOT remove them or rerun solver after results without new explicit user authorization. Rebuilding/preprocessing or saved-output aggregation does not execute a solver.
check_v409_diagnostic.py expects full raw diagnostic JSONL in original private workspace. Compact JSONL retains all scalar metadata and hashes of complete operation lists; ten fixture inputs/outputs are retained in full. 62MiB full operation trace stays private under diagnostic_cases and is inventoried in diagnostic_raw_hashes.json. Recreating that trace runs partial solver and requires new authorization.
summarize_v409.py independently replays archived official outputs and aggregates the one evaluation without solver execution. Restore output paths noted in archived records if aggregating elsewhere. Inputs are existing tools/in100, pinned by preregistration hashes; saved401 full plans remain private and are hashed there. Parent official scalar records included.
Exact historical v800100-case rows unavailable; same-original-reference condition remains symbolic, no historical MIN or proxy substituted. No final adoption without that metric; currently adopted v315 unchanged.
No retune, no scored reruns, no v410. All raw/preprocessed/compiled artifacts retained privately with hashes. Publication exactly5files.
''')
artifacts=[source,r/'adhoc/imports/v401/original.cpp.txt',r/'adhoc/bin/v409_diagnostic.cpp',o/'diagnostic',o/'v409_local',o/'v409_nonlocal',r/'target/release/v409_zero_cap_dead_frontier',*o.glob('*.ii'),*o.glob('*.asm')]
(o/'full_artifact_hashes.json').write_text(json.dumps({str(p.relative_to(r)):sha(p) for p in artifacts if p.is_file()},indent=2)+'\n')
files=[p for p in sorted(o.rglob('*')) if p.is_file() and p.parent.name!='diagnostic_cases' and p.suffix in ('.json','.jsonl','.csv','.log','.patch','.md','.txt','.stderr','.err','.sha256') and p.name not in ('case_traces.json','backlog_before_remote_reconcile.md')]
files+=[r/'results/analysis/v401/records.json'];files+=list((r/'adhoc/scripts').glob('*v409*.py'));files+=[r/'adhoc/scripts/v409_diagnostic_main.cpp.txt'];files+=[r/'adhoc/scripts'/n for n in ['replay_slime_output.py','cloud_gcc15.py','cloud_toolchain_env.sh']]
files=list(dict.fromkeys(files));manifest={str(p.relative_to(r)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in files}
with zipfile.ZipFile(dest/'reproduction.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files:z.write(p,str(p.relative_to(r)))
 z.writestr('V409_CONTENT_MANIFEST.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(dest/'reproduction.zip') as z:
 assert z.testzip() is None
 for name,item in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==item['sha256']
external={'version':'v409','source_sha256':sha(source),'note_sha256':sha(r/'notes/experiments/v409.md'),'backlog_sha256':sha(r/'notes/backlog.md'),'zip_sha256':sha(dest/'reproduction.zip'),'zip_bytes':(dest/'reproduction.zip').stat().st_size,'file_count':len(files),'publication_files':['src/bin/v409_zero_cap_dead_frontier.cpp','notes/experiments/v409.md','notes/backlog.md','adhoc/imports/v409/reproduction.zip','adhoc/imports/v409/manifest.json'],'files':manifest};(dest/'manifest.json').write_text(json.dumps(external,indent=2)+'\n');print(json.dumps({k:v for k,v in external.items() if k!='files'},indent=2))
