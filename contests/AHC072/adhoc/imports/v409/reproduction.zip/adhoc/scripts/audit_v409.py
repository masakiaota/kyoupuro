from pathlib import Path
import subprocess,os,re,difflib,hashlib,json
r=Path(__file__).resolve().parents[2];o=r/'results/analysis/v409';source=r/'src/bin/v409_zero_cap_dead_frontier.cpp';parent=r/'adhoc/imports/v401/original.cpp.txt'
p=parent.read_text();c=source.read_text();results={}
(o/'source.patch').write_text(''.join(difflib.unified_diff(p.splitlines(True),c.splitlines(True),fromfile='cloud401',tofile='v409')))
def outside(s):
 a=s.index('    bool insert_at(');b=s.index('    bool insert(',a)
 return re.sub(r'\s+',' ',s[:a]+s[b:]).strip()
assert outside('\n'.join(p.splitlines()[1:]))==outside('\n'.join(c.splitlines()[1:]))
for mode,flags in [('local',['-DLOCAL']),('nonlocal',['-DATCODER','-DONLINE_JUDGE','-DNOMINMAX'])]:
 pp=[]
 for name,path in [('parent',parent),('candidate',source)]:
  dest=o/f'{name}_{mode}.ii'
  with dest.open('w') as out:subprocess.run([os.environ['CXX'],'-x','c++','-std=gnu++23','-E','-P',*flags,str(path)],stdout=out,check=True)
  t=dest.read_text().replace(str(path),'SOURCE');t=re.sub(r'"SOURCE",\s*\d+,','"SOURCE", LINE,',t);pp.append(t)
 (o/f'preprocessed_{mode}.patch').write_text(''.join(difflib.unified_diff(pp[0].splitlines(True),pp[1].splitlines(True))))
 assert outside(pp[0])==outside(pp[1]),mode+' outside insert_at differs'
 binary=o/f'v409_{mode}'
 with (o/f'build_{mode}.log').open('w') as log:subprocess.run([os.environ['CXX'],'-std=gnu++23','-O2','-Wall','-Wextra','-march=native','-pthread','-ftrivial-auto-var-init=zero','-fopenmp',*flags,str(source),'-o',str(binary)],stdout=log,stderr=subprocess.STDOUT,check=True)
 results[mode]={'build_ok':True,'outside_insert_at_preprocessed_equal':True,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest()}
(o/'static_audit.json').write_text(json.dumps({'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'modes':results,'scope':'Full source/complete preprocessed diffs retained; all changes inside insert_at independently reviewed.'},indent=2)+'\n')
print(results)
