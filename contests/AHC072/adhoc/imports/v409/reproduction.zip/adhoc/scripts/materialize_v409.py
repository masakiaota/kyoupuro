from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parents[2];o=r/'results/analysis/v409';p=r/'adhoc/imports/v401/original.cpp.txt';s=p.read_text();assert hashlib.sha256(p.read_bytes()).hexdigest()=='0c241cc3a862d12faf100050df4ea3bafa3c520261d81e5237a41e3c54f25658';assert (o/'preregistration.json').exists()
a=s.index('    bool insert_at(');b=s.index('\n    bool insert(',a);part=s[a:b]
part=part.replace('        label[source*8+initial_gap]={0,0,-1};','''        label[source*8+initial_gap]={0,0,-1};
        // With cap zero no paid move or escape can create a new reachable cell.
        // Gap closure only copies labels inside the same cell.
        // Keep -ftrivial-auto-var-init=zero from charging cap>0 for this cap0-only array.
        array<unsigned char,max_cells> reachable __attribute__((uninitialized));
        int reachable_count=1;
        if(cap==0){reachable.fill(0);reachable[source]=1;}''',1)
part=part.replace('            board_info.apply(b,m);h[p]=height(b[p]);h[q]=height(b[q]);','''            if(cap==0) {
                reachable_count-=reachable[p]+reachable[q];
                reachable[p]=reachable[q]=0;
            }
            board_info.apply(b,m);h[p]=height(b[p]);h[q]=height(b[q]);''',1)
part=part.replace('                        label[ns]={at.cost,bonus,ptr};','''                        label[ns]={at.cost,bonus,ptr};
                        if(cap==0&&!gone&&!reachable[tag_cell]) {
                            reachable[tag_cell]=1;++reachable_count;
                        }''',1)
part=part.replace('            // 変更された2マスとそこへ入る辺を開き直す。','''            // An empty live frontier cannot resurrect; keep an already reached GOAL.
            if(cap==0&&reachable_count==0&&label[GOAL].cost==infinite_cost)return false;
            // 変更された2マスとそこへ入る辺を開き直す。''',1)
s=s[:a]+part+s[b:];s=s.replace(s.splitlines()[0],'// v409_zero_cap_dead_frontier.cpp',1);dest=r/'src/bin/v409_zero_cap_dead_frontier.cpp';dest.write_text(s)
(o/'frozen_manifest.json').write_text(json.dumps({'source_sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'parent_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'selection_seed':'409001+case','trial_seed':'409001+1000*case+ordinal','sets_per_case':32,'dependency_expansion':'grow_dependency rounds>0, dedup exact sorted IDs, candidate order','official_allowed_after_gate_only':True,'official_runs':1,'jobs':8,'local_ratio':'1.90/1.930','strict_T_lt':19876,'relative':'same original exact v800 reference pending'},indent=2)+'\n')
print(dest)
