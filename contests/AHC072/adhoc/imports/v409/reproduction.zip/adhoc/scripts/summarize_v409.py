#!/usr/bin/env python3
"""Read-only aggregation and independent replay; no solver execution or proxy relative metric."""
from pathlib import Path
import json,re,hashlib,csv,sys,collections,statistics,shutil
r=Path(__file__).resolve().parents[2];o=r/'results/analysis/v409';sys.path.insert(0,str(r/'adhoc/scripts'))
from replay_slime_output import replay
label='cloud_v409_gcc15.3_LOCAL_search1.900_core1.870466_j8_20261004'
records=[json.loads(s) for s in (r/'results/eval_records.jsonl').read_text().splitlines()];records=[x for x in records if x['label']==label]
assert len(records)==100 and len({x['case_name'] for x in records})==100 and all(x['status']=='ok' for x in records)
parent={x['case_name']:x['score'] for x in json.loads((r/'results/analysis/v401/records.json').read_text())}
def audit(t):return {k:v for k,v in re.findall(r'\b((?:v311|v315|v409)_[\w]+)=([^\s]+)',t)}
pairs=[];traces=[];replays=[];seed_diffs=[];(o/'outputs').mkdir(exist_ok=True)
for x in records:
 case=x['case_name'];inp=r/'tools/in'/case;output=r/x['stdout_path'];t=Path(str(output)+'.err').read_text();a=audit(t)
 counts={k:int(v) for k,v in re.findall(r'\[summary.count\] ([^=]+)=(-?\d+)',t)}
 times={k:float(v) for k,v in re.findall(r'\[summary.time_ms\] ([^=]+)=(-?[\d.]+)',t)}
 metrics=replay(inp,output)['metrics'];assert metrics['E']==0 and metrics['S']==x['score'];assert counts['final_ops']==metrics['T'] and counts['E']==0;replays.append({'case':case,**metrics})
 pa=audit((r/'results/analysis/v401/outputs'/f'{case}.err').read_text())
 keys=['v311_nn_first_hash','v311_nn_retained']+sorted(k for k in set(a)|set(pa) if re.match(r'v311_seed_\d+_(raw|origin)$',k))
 diff={k:{'v401':pa.get(k),'v409':a.get(k)} for k in keys if pa.get(k)!=a.get(k)}
 if diff:seed_diffs.append({'case':case,'differences':diff})
 traces.append({'case':case,'counts':counts,'times_ms':times,'audit':a,'input_sha256':hashlib.sha256(inp.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(output.read_bytes()).hexdigest()})
 pairs.append({'case':case,'M':metrics['M'],'v401':parent[case],'v409':x['score'],'delta':x['score']-parent[case],'elapsed_ms':x['elapsed']})
 shutil.copy2(output,o/'outputs'/case);shutil.copy2(Path(str(output)+'.err'),o/'outputs'/f'{case}.err')
elapsed=[x['elapsed'] for x in records];errors={k:sum(t['counts'].get(k,0) for t in traces) for k in ['construction_errors','lns_errors','baseline_recovery','final_recovery','lns_invalid_candidates']};free=dict(collections.Counter(t['counts'].get('state_pool_free_at_end','missing') for t in traces))
result={'label':label,'cases':100,'score_sum':sum(x['score'] for x in records),'score_mean':statistics.mean(x['score'] for x in records),'score_delta':sum(x['delta'] for x in pairs),'wins':sum(p['delta']<0 for p in pairs),'ties':sum(p['delta']==0 for p in pairs),'losses':sum(p['delta']>0 for p in pairs),'elapsed_mean_ms':statistics.mean(elapsed),'elapsed_max_ms':max(elapsed),'elapsed_over_1900ms':sum(x>1900 for x in elapsed),'elapsed_over_2000ms':sum(x>2000 for x in elapsed),'independent_replay_ok':len(replays),'error_recovery_totals':errors,'free_slots_distribution':free,'search_limit_distribution_ms':dict(collections.Counter(t['times_ms'].get('search_limit','missing') for t in traces)),'trace_total_max_ms':max(t['times_ms'].get('total',0) for t in traces),'source_sha256':hashlib.sha256((r/'src/bin/v409_zero_cap_dead_frontier.cpp').read_bytes()).hexdigest(),'memory':json.loads((o/'memory.json').read_text())}
manifest=json.loads((o/'frozen_manifest.json').read_text());assert result['source_sha256']==manifest['source_sha256']
result['initial_first_hash_mismatch_cases']=[x['case'] for x in seed_diffs if 'v311_nn_first_hash' in x['differences']]
result['initial_candidate_changed_cases']=len(seed_diffs)
keys=sorted({k for t in traces for k in t['counts'] if k.startswith('v409_') or k.startswith('lns_two_order_')}|{'lns_attempts','lns_accepted','lns_improvements'})
result['mechanism']={k:sum(t['counts'].get(k,0) for t in traces) for k in keys}
result['source_bytes']=(r/'src/bin/v409_zero_cap_dead_frontier.cpp').stat().st_size
result['absolute_pass']=result['score_sum']<19876
result['correctness_time_pass']=max(elapsed)<=2000 and all(v==0 for v in errors.values()) and free=={4:100}
result['requested_v800_relative_score']=None;result['requested_v800_status']='pending_exact_historical_v800_100_case_reference';result['relative_condition']='relative_v800(v409)>relative_v800(cloud401) with same exact reference'
result['decision']='reject_absolute' if not result['absolute_pass'] else ('reject_correctness_or_time' if not result['correctness_time_pass'] else 'pending_v800_relative_no_adoption')
result['acceptance_passed']=False
for name,value in [('result',result),('records',records),('case_traces',traces),('replay',replays),('initial_candidate_differences',seed_diffs)]: (o/f'{name}.json').write_text(json.dumps(value,indent=2)+'\n')
with (o/'paired.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=list(pairs[0]));w.writeheader();w.writerows(pairs)
print(json.dumps(result,indent=2))
