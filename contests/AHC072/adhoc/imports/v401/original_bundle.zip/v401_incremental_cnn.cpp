// v401_incremental_cnn.cpp
// v401 / B-159: exact local CNN activation reuse; direct parent v311.
// Experiment v311; direct parent v105_nn_lns.cpp at 886464d2374ad81e937fde84fc25cba771307e2e.
// Reuse exactly the parent's 26,866 policy/value parameters, without training.
// Output-channel SIMD kernels preserve per-output accumulation order. Multiple
// symmetry-generated completed plans compete AFTER short LNS refinement.
// V311_SINGLE_SEED is the preregistered speed-only ablation, not the default.
// All preparation, inference, transformations and LNS share the parent's clock.
// v104の固定165採取時点のNNで完成解を1本作り、v214のLNSと短縮処理へ渡す。
// 学習条件と重みの由来、時間を含む比較条件は notes/experiments/v105.md に記録する。
#include <bits/stdc++.h>
using namespace std;
#if defined(__GNUC__) && !defined(__clang__)
#pragma GCC push_options
#pragma GCC optimize("O3,unroll-loops")
#endif
namespace nn {
struct Input {
    int N = 0, K = 0;
    vector<string> C;

    void read(istream& in = cin) {
        in >> N >> K;
        C.resize(N);
        for (auto& row : C) in >> row;
    }
};

struct Point {
    int i, j;
};

// 入力から一度だけ作る地形・巣の情報。塔の変化する状態は持たない。
struct Board {
    // d = 0, 1, 2, 3 は U, D, L, R に対応する。
    static constexpr array<int, 4> di{-1, 1, 0, 0};
    static constexpr array<int, 4> dj{0, 0, -1, 1};
    static constexpr uint16_t unreachable_distance = numeric_limits<uint16_t>::max();

    int cell_count = 0;
    // 床だけに行優先で連番を振る。壁と盤外の未使用領域は -1。
    array<array<int16_t, 20>, 20> cell_id;
    vector<Point> coordinates;
    vector<int> nest;             // nest[p]: 巣の色。巣がなければ -1。
    vector<int16_t> nest_pos;      // nest_pos[c]: 色 c の巣の床マスID。

    // ray[p][d][l - 1]: 途中もすべて床なら移動先ID、それ以外は -1。
    // 途中の塔は飛び越えられるため、初期スライムの位置には依存しない。
    // 4近傍の移動先は ray[p][d][0] で取得できる。
    vector<array<array<int16_t, 8>, 4>> ray;

    // floor_dist[p * cell_count + q]: 壁だけを考慮した4近傍最短距離。
    // 塔の高さ・着地容量・帰巣を含まず、実際の最短操作数は表さない。
    vector<uint16_t> floor_dist;

    explicit Board(const Input& input) {
        for (auto& row : cell_id) row.fill(-1);
        coordinates.reserve(input.N * input.N);
        for (int i = 0; i < input.N; ++i) {
            for (int j = 0; j < input.N; ++j) {
                if (input.C[i][j] == '#') continue;
                cell_id[i][j] = static_cast<int16_t>(cell_count++);
                coordinates.push_back({i, j});
            }
        }

        nest.assign(cell_count, -1);
        nest_pos.assign(input.K, -1);
        ray.resize(cell_count);
        for (int p = 0; p < cell_count; ++p) {
            const auto [i, j] = coordinates[p];
            const char ch = input.C[i][j];
            if ('A' <= ch && ch <= 'L') {
                const int c = ch - 'A';
                nest[p] = c;
                nest_pos[c] = static_cast<int16_t>(p);
            }
            for (int d = 0; d < 4; ++d) {
                ray[p][d].fill(-1);
                for (int l = 1; l <= 8; ++l) {
                    const int ni = i + di[d] * l, nj = j + dj[d] * l;
                    if (ni < 0 || ni >= input.N || nj < 0 || nj >= input.N) break;
                    const int q = cell_id[ni][nj];
                    if (q < 0) break;
                    ray[p][d][l - 1] = static_cast<int16_t>(q);
                }
            }
        }
        // 各床を始点にBFSする。全点対でも O(cell_count^2)、最大400^2要素。
        floor_dist.assign(size_t(cell_count) * cell_count, unreachable_distance);
        array<int16_t, 400> queue;
        for (int source = 0; source < cell_count; ++source) {
            // この距離行への読み書きはdistだけを使い、rayとqueueの領域とは重ならない。
            uint16_t* __restrict__ dist = floor_dist.data() + source * cell_count;
            int head = 0, tail = 0;
            dist[source] = 0;
            queue[tail++] = static_cast<int16_t>(source);
            while (head < tail) {
                const int p = queue[head++];
                for (int d = 0; d < 4; ++d) {
                    const int q = ray[p][d][0];
                    if (q < 0 || dist[q] != unreachable_distance) continue;
                    dist[q] = static_cast<uint16_t>(dist[p] + 1);
                    queue[tail++] = static_cast<int16_t>(q);
                }
            }
        }
    }

    int floor_distance(int p, int q) const {
        return floor_dist[p * cell_count + q];
    }
};

// 1塔を32 bitで保持する。下から順に4 bitずつ c + 1 を詰め、
// 未使用の上位部分を0にする。色0も非零になるため、高さを別に保存せず求められる。
// 色・添字・高さは呼び出し側が条件を満たす。top/popは非空、追加後は高さ8以下。
struct Tower {
    uint32_t bits = 0;
    static constexpr array<uint32_t, 9> mask{
        0u, 0xfu, 0xffu, 0xfffu, 0xffffu, 0xfffffu, 0xffffffu, 0xfffffffu, 0xffffffffu};

    bool empty() const { return bits == 0; }
    int height() const { return (bit_width(bits) + 3) / 4; }
    int at(int i) const { return int((bits >> (4 * i)) & 15u) - 1; }
    int top() const { return int(bits >> (4 * (height() - 1))) - 1; }
    int bottom() const { return int(bits & 15u) - 1; }

    // 高さが既知の処理では、h/gを渡すオーバーロードで再計算を省ける。
    void reverse() { reverse(height()); }
    void reverse(int h) {
        const uint32_t swapped = ((bits >> 4) & 0x0f0f0f0fu)
                               | ((bits & 0x0f0f0f0fu) << 4);
        // 4 bit単位の反転。64 bitに拡張し、空塔の32 bitシフトも定義済みにする。
        bits = uint32_t(uint64_t(byteswap(swapped)) >> (4 * (8 - h)));
    }

    // 上側n匹を順序を保って切り出す。0 <= n <= h。
    Tower take_top(int n) { return take_top(n, height()); }
    Tower take_top(int n, int h) {
        const int k = h - n;
        const Tower result{uint32_t(uint64_t(bits) >> (4 * k))};
        bits &= mask[k];
        return result;
    }

    // upperを順序を保って上へ追加する。空塔の追加も扱える。
    void append_top(Tower upper) { append_top(upper, height()); }
    void append_top(Tower upper, int g) {
        bits |= uint32_t(uint64_t(upper.bits) << (4 * g));
    }

    void push_top(int c) { bits |= uint32_t(c + 1) << (4 * height()); }
    void push_bottom(int c) { bits = (bits << 4) | uint32_t(c + 1); }
    void pop_top() { bits &= mask[height() - 1]; }
    void pop_bottom() { bits >>= 4; }

    // 巣の色cと一致する最上段の連続部分を除き、帰巣数を返す。巣なしはc=-1。
    int home(int c) { return home(c, height()); }
    int home(int c, int h) {
        if (c < 0) return 0;
        const uint32_t different = (bits ^ (0x11111111u * uint32_t(c + 1))) & mask[h];
        // 最上位の「巣と異なる段」より下はすべて残るため、一括で切り詰められる。
        const int remaining = (bit_width(different) + 3) / 4;
        bits &= mask[remaining];
        return h - remaining;
    }
};

// 1手を4 byteで保持する。pは床マスID、dは0=U, 1=D, 2=L, 3=R。
// 値域（p:0..399, k:0..7, d:0..3, l:1..8）は呼び出し側が保証する。
// 操作の合法性と盤面の更新は利用側で扱う。
struct Move {
    constexpr Move(int p, int k, int d, int l)
        : p_(uint16_t(p)), k_(uint8_t(k)), dl_(uint8_t((d << 3) | (l - 1))) {}

    constexpr int p() const { return p_; }
    constexpr int k() const { return k_; }
    constexpr int d() const { return dl_ >> 3; }
    constexpr int l() const { return (dl_ & 7) + 1; }

private:
    uint16_t p_;
    uint8_t k_;
    // 下位3 bitがl-1、続く2 bitがd。距離8も3 bitに収める。
    uint8_t dl_;
};

// 探索の各枝が塔を所有する。固定長の未使用部分も0なので盤面の完全一致に使える。
struct BoardState {
    array<uint32_t, 400> bits{};
    int E = 0;
    BoardState() = default;
    BoardState(const Input& input, const Board& board) {
        for (int p = 0; p < board.cell_count; ++p) {
            auto [i, j] = board.coordinates[p];
            const char ch = input.C[i][j];
            if ('a' <= ch && ch <= 'l') { bits[p] = uint32_t(ch - 'a' + 1); ++E; }
        }
    }
    int apply(const Board& board, Move move) {
        const int p = move.p(), k = move.k();
        const int q = board.ray[p][move.d()][move.l() - 1];
        Tower a{bits[p]}, b{bits[q]};
        const int h = a.height(), g = b.height(), n = h - k;
        Tower flying = a.take_top(n, h);
        flying.reverse(n); b.append_top(flying, g);
        const int returned = a.home(board.nest[p], k) + b.home(board.nest[q], g + n);
        bits[p] = a.bits; bits[q] = b.bits; E -= returned;
        return returned;
    }
};

int flat_cell(const Board& board, int p) {
    return board.coordinates[p].i * 20 + board.coordinates[p].j;
}

// 学習側は20×20座標で候補を保存し、C++探索は圧縮した床IDを用いる。
uint32_t action_code(const Board& board, Move move) {
    return uint32_t(flat_cell(board, move.p()) | (move.k() << 9)
                    | (move.d() << 12) | ((move.l() - 1) << 14));
}

vector<Move> legal_moves(const Board& board, const BoardState& state) {
    vector<Move> moves;
    moves.reserve(2048);
    for (int p = 0; p < board.cell_count; ++p) {
        const int h = Tower{state.bits[p]}.height();
        for (int k = 0; k < h; ++k) for (int d = 0; d < 4; ++d) {
            for (int l = 1; l <= k + 1; ++l) {
                const int q = board.ray[p][d][l - 1];
                if (q < 0) break;
                if (Tower{state.bits[q]}.height() + h - k <= 8) moves.emplace_back(p, k, d, l);
            }
        }
    }
    return moves;
}

array<float, 16> action_features(const Board& board, const BoardState& state, Move move) {
    const int p = move.p(), k = move.k(), q = board.ray[p][move.d()][move.l() - 1];
    Tower a{state.bits[p]}, b{state.bits[q]};
    const int h = a.height(), g = b.height(), n = h - k;
    array<float, 16> x{};
    x[0] = k / 8.f; x[1] = move.l() / 8.f; x[2] = n / 8.f; x[3] = g / 8.f;
    x[4 + move.d()] = 1.f;
    x[9] = a.at(k) == board.nest[q];
    x[10] = k > 0 && a.at(k - 1) == board.nest[p];
    float delta = 0.f; bool same = true;
    for (int t = k; t < h; ++t) {
        const int goal = board.nest_pos[a.at(t)];
        delta += board.floor_distance(p, goal) - board.floor_distance(q, goal);
        same &= a.at(t) == a.at(k);
    }
    x[11] = delta / (8.f * n); x[12] = (g + n) / 8.f;
    x[13] = board.nest[p] >= 0; x[14] = board.nest[q] >= 0; x[15] = same;
    Tower flying = a.take_top(n, h); flying.reverse(n); b.append_top(flying, g);
    x[8] = (a.home(board.nest[p], k) + b.home(board.nest[q], g + n)) / 8.f;
    return x;
}

// 床×40、以降の推論でもマス優先。壁・盤外の特徴は常に0。
array<array<float, 40>, 400> board_features(const Input& input, const Board& board, const BoardState& state) {
    array<array<float, 40>, 400> result{};
    for (int p = 0; p < board.cell_count; ++p) {
        const auto [i, j] = board.coordinates[p];
        auto& x = result[i * 20 + j];
        Tower tower{state.bits[p]};
        x[0] = 1.f; x[1] = board.nest[p] >= 0;
        x[2] = i / 20.f; x[3] = j / 20.f; x[4] = tower.height() / 8.f;
        x[5] = state.E / 256.f; x[6] = input.N / 20.f; x[7] = input.K / 12.f;
        for (int t = 0; t < tower.height(); ++t) {
            const int goal = board.nest_pos[tower.at(t)];
            const auto [gi, gj] = board.coordinates[goal];
            x[8 + t * 4] = 1.f;
            x[9 + t * 4] = (gi - i) / 20.f;
            x[10 + t * 4] = (gj - j) / 20.f;
            x[11 + t * 4] = board.floor_distance(p, goal) / 40.f;
        }
    }
    return result;
}

void read_snapshot(istream& in, const Board& board, BoardState& state) {
    state = BoardState{};
    for (int f = 0; f < 400; ++f) {
        uint32_t bits; if (!(in >> bits)) throw runtime_error("short snapshot");
        const int p = board.cell_id[f / 20][f % 20];
        if (p < 0) { if (bits) throw runtime_error("tower on wall"); continue; }
        state.bits[p] = bits; state.E += Tower{bits}.height();
    }
}
// PPO iteration=165, dataset SHA256=df529c17cad6ee0c40983ee0b1588ce65741a813d9aa8223d8aa40b6ee4f7356
constexpr int NN_WIDTH=48, NN_HIDDEN=64, NN_DEPTH=4, NN_ACTOR_INPUT=160;
static array<float,1920> nn_input_w;
static array<float,48> nn_input_b;
static array<array<float,432>,NN_DEPTH> nn_depth_w;
static array<array<float,48>,NN_DEPTH> nn_depth_b;
static array<array<float,2304>,NN_DEPTH> nn_point_w;
static array<array<float,48>,NN_DEPTH> nn_point_b;
static array<float,10240> nn_actor_w;
static array<float,64> nn_actor_b;
static array<float,64> nn_actor_out_w;
static array<float,1> nn_actor_out_b;
static array<float,3072> nn_critic_w;
static array<float,64> nn_critic_b;
static array<float,64> nn_critic_out_w;
static array<float,1> nn_critic_out_b;
static constexpr char nn_packed[] =
"ZwV1PPqSAAUUAwXsLAMCCOwC/iny+f/3AAME6hIAA4EZ/gLgBgUKA//3+Dm346I8AQ0AAAveBQUjAAUQ+QD8BQT/ARD///0IBv8C2fkAAvDo+wl/9v715P2R"
"nTrBIuH4IMPFnt7bMZr+/X/5zZ8mEJDzpA2m3Uv3B0OsQ7n1lk0Fwt2GwtSZOpawmsLbZYGX0lEjHJeuuRNFBaOlqLPU/Z40GvuKR/nAs/zvB2zMnIY+cck8"
"CQYA//soIwsHAQEFAQL+Dvn4AiH5A/0fzQD/O93++36BBgMD8///RWq4pDvgS/4E/9YS62oG6FTz7u8ZBDL4LPX49hMF9QnwHAb8wBIJ8gLHGPR/E+LfPPz+"
"Df4H//oA9PkGBgoC/vILF/DrAx/f2gBAxLAFTrSXBV2tgflpiYjSr0Q8AQD7BAKw8Q0TAgN/8gf/TPn3/SkEAv/z/AEBEgUD+fACBP70DQMF8M2ZmTqtPQbf"
"4TzMPqshZRgnmNzrjiNIMDgNSJiy4V11uzgP2n+sAEyZFhyVD4O9Pf8AAAACAQAAAQAAAQQAAAAEAAD/AgAA9AIAAOUCAADPA/8BogYA/4FHjAQ89wjg+Q35"
"FgUxgfibAIj0ywL1//H3vPzzB8v6zgXJ+MUC8twH9+ki7lkxZDwGBgPZEv0dACQYioEDB5y9BRnL8QL9xuIKANew/wHqA//2AxX7+v8nRPwBPf4ABAACAfwA"
"//UB/vrEAf8Ef/3/As8BAQD5AP8AAgAA//0BAgAB//9C3Z08BfEABAju7/s5AAEiCgUCBAPyAfMEBQP94AP/Sdb/An/uA/xDBgEF99Ut2Dz9CwIABwn+/xYD"
"AXH6CPwc/ewDGQUH//wCAQQFBf8H8AUDCdgX/feBj2GPPA0gAAQJ5iL7JRIcJyU+7ZIMgRABBDb8SPsPAyT7BQcW/gf78+kCE9PdIcY7KUMD/xL2A/k4AP4V"
"EwwDzRXdChP+D/wtAgUD8+YDBX/mDgA35/chcnD1BTznAf0sDev5/jP2e6r96n/I/BdG9/30ReYF+jzC//whCQb+C+ry5UoID4/DOzWBGQyI2R/mhslFy83+"
"AQbw+P7z/fkJ8ufq+eb/AvMFAu4K9RHw+f8AkBg9/f8A/wYD/QIAAP8CHv8ABQwDAAEF///y/P8BBfEA/STkAfppgQQB4b8JyDqN3IHBvg7aIaIvyNFR/pgL"
"p85XNJcU5dWJI/HfQeMENuW1Migrsl4XM/oAPCTkAv0uEqUR6AEHGygT/zFL2/mRMxQEl04FB4FQ+um+LA6/Qj/0VI5iTqY7EgsCBV/y/gUe/ADTf/cDGGcO"
"/gVl/f3iXgADF10CAglkAQvkXv72qcJKrzwD/wEDAAIFA/gB/0v8/wFEAwEDZvz//38I//5bBf39TAX99FoF/BK/xKsSPf4AAAALAv4CCwABCwUD//0O+wD5"
"BQMB9gwAAesEAQIH/wEFMPwB/H8tCJk9AQIAAAIBAAANAAGBBgAA8gD+AP8AAQAB/wAA/wAAAP0AAAH/AAAAA6brujqQr7cs8lSSqyzcWwND0cfNk9H+8JVU"
"tQPrBPrnBKg4gU3zPiZMWDzk+mWvOyCBCAOgACHxkv0do+HrAwXpHA/r5fYT+xsV6g/p6RYO+AoR7v4c7+lbIjw9AwIA/wAJB/8CAAAI+gAA+///APAAAv3u"
"DP7/lQD7AYEGBPiO5Pn/w5JcFzw2Av/7+YESKRD+/uj8BfgMCgP7DvUA/vcR+fsg+/oR1fkHAv8CG+65KI6sOrlHqFUiFIlV80sWTZrm37lZzNe/X/L1j6wi"
"FhlX03+etLFUU7Di2VwjwIs8F/v+AOIW5gLlAAH/AAAB/QkBAX+R+wEACQH9ABYAANnm8/T2Bu34IDWhBj0A7AEA/f8AAOwDW4EQ/rthAQHoCwEAAgYBAP/9"
"Af///gEBAwcLAQNA7PCtPAEC9/UCBA//BvDv8gnm7d4O4de6A7a7kAK0tYEEsK+R/aexj/+tjJ9qml49CQAAAP7/AgD/AAAA/AAA5gQAALAFAAKB+P8AqfEC"
"Afj9AgL9/f/+/ThoJT0EA/8BAv39ABsBABP6AwAA+PoCBPkCABPvAQAH/f8BzhP/AQn0AAB/5rc+PQD+AAAF/AIBFwAACQMA/wT/AAEJ/AAADP8BAP77AAD+"
"+QD+/v0AAoEmr8g8BwYMBwQD9wEGAQQBAPwB+gUaEusDJCbZBUFEoAdOVpD+VHaPAX9HzBocQjwHAwLDBfQcAgMCKNwABS/fAwcp5QMfQsiB6dSX1wPu4uvw"
"/QLlE/IGEJQPPPz++lz5+9ABCP14xAUAKuoDDB3o+P9A2ggTAdD6Eh0I5R5/6BAT4c7jqUE86QQwAQv37AMyfwmmCWUDy/xrAeb7MQPrBS3/zwInAN77FvId"
"+wwI+4j2szz4/PsKAv/+Agj9D/wE+QsABvgS7ATSK84EvEaeBLNfnP6pf4sDglW3kBimOxRnBgUZ/foBOPn6rfv8++0O/PsWGfn11RD7BBwP/vTBCvDdgfkZ"
"T267WJA8Axz7/QUJAvwRCAXp+gYJCPj1+/kC6evvCMLLwweutZMImJyD+IWBi55VBz39/QD/BQAA/wr9ga/+AGYw/gYTFv/+BgMAAAIAAAD//wAAAAH//wEG"
"YJUmPCMo+vME3SsnPPry4xEJ+x//6QEYDQb87/QCAykH+OfX+/2aPgb+fxrTSSU9AAIAAAL+/wAEAAAX6/8B8/4A/wIA///9Bv348gwFGQH1+mnLDgOBOtBN"
"5jtLgfYEwBTo/Iv//7DdEQgG6fED8wT4EBPt/u7wBu/vBOMK7esH9gzkZRkdPsfDCT2rA3O9YwmyPf7sZT46T9U9gZGsPXNlsL0gCeK94CHHvLL3Fb5naAS+"
"cMWqPbaa1D0/2zy93ycWPigHFT4N8nG9qUyXPt4hfj1KZjY8LzecPmJRlz0jNhG8lY46vskuEj1kX9a90uAOPlRVDrtOWbk+FwAGvi50WT7RDws+jnaJO6ST"
"7T5Dv6y9e5ICvv2/sj2N69m91YpxPZwagb2D6SQ98boAPVNkEL35HP295RF7PmgiAr6HZNQ+UwqbO//uAup/7AXqBSns3TvtHfMggSDtIOzOeBg78YF+rg3m"
"D1SY+y7yOviFn1jGCJz9fwuDODz/gf3yDe0ECgQTR0E87YHb8NXZ/PH044kKPPoLCuyBEP3l+vvCQzvkjsFcpoE2Wr5LgQw74hvq/3enKAN/5B3dOwEB/QB/"
"AQAA/xJckDsVARsX9S44fznNCiU7FMHWfw6HQOLzeVa8O/7+Af9//f78/Ych1jo4bj91939AbEN41jE8+fn43OnPgdCIx3PdPM0CAYH4Av3//+efizsGIRD5"
"DRrVgcEtI4M7LCT8f+0WOiwD5XhrOjCxHbd8Ksp/2VuxFTu1LRKQgaYDIe7XbR87aioCx4HJfhu1ZrQSO7I7vtjgM6HNgcXO7To1xD3YgcpHzjaJAj08BAYD"
"BYEFAwQDNJOFPIGg+Zvn+u7y+9TTUjwNDw0NgQ4LDg6MugA78DnU4ev8d+Z/9rDiO/fY+dJ/1fHQ9eA0uzvjuOKzf7nit99UuC08COUDx0jLBIEEwnocO0uB"
"wauLVI1i3WhkAjwGAQcAf/8G/gZRe4E8AQH+AYH/AAEAS+yMOyRJFT6BwhHF74p3Gz0BAf0EAIEBAP54Ps862UjgQH9F8UvnfVNZO+ez3rF/ttmr0SAGkTu8"
"gdmF+BX6IxftdYg7/hX0DIHoCRvwXMHLOwsI/Q6BCAgH//W1UDsvfyUpSxD8BQOzWUA73srrFxyB/RnW+v00Owp6GG+kfxN9Ejc8tzpbaj53IX9ba1vNMWU7"
"Bg4d/4EfAQYR6sFEPAYMgfHoFgP1BBUPGjz+/vv9f/79AP4SAGU7DTAIKoEjBy8IzBuYvmMZ2j36W5u+y6s0u0IDLD6fRIw+WbcWPob5q7u9/Fa+1dYEvvEf"
"ijqvW0g8Wr+WPJXpD74ji6Y+MoiwPmeTUT5kn4q78KGnvtO1WrwKVY++Mxf6Oy3R4T2X7cM+twJuPhJVjrsiZvK9H9DMPSYIfD5nbEM+fCgWvuVGq76TtnI+"
"mTMfuxwFeTxd5Kc7bLY3vk9ihj6FCB4+YcEvPkeISTsBdi8+xAfjvJ4csjtcb9C8818GPv00Njy8kga+60KNPN+B+gUN4eweA/3hAwPUps/85QLqAO8W6vXw"
"/tM0HgP3BCT09y8H7hvj46edDPsAB+IkPzzrD/z75RsKMP3OAAoCGRj29AEG7fnmgQYTwwAkLdsA+ecJ8BTr5gcN9/kBDPom9/9LUr06gT5NUpWRrdsf5/Uk"
"qga2yQygIzW3pAn19OsF1t7m+MDVIPnGty6HvpW0iZHLpccu0KstPPsB/vrusAbn+frS6Pz3Igl//Aby/g768uvn9RcNH/jr9Pj++wbrFRcwEeHn/AEH5crj"
"LTzpDv8G7BUJ+w2B8/ILGBL38Pr16gnpCvYz7fUD09IKCuP79vQD8Qz3BAjW8fIUDPbfHyc81BP6+u6BDB8GFegN7gEV6APe/zED/PQKEev9HO73Bd/7JQIa"
"FSML1eL3LAcU/f/VH5W3O+b6Fer//HTe+Bsez9UG/N3uJwbZBNP49yroEPoREgPEz7IH/xsDFRU6fwn/JADr7zUKYjwHGf4FBswB5gUDIf8FzYUcDyIAFgUK"
"AIvcKP2BNAP/7uH5FwNPGcI0EQ33+PH8/Q5RdtE6h9XYyNOkpKe5u7qrOrK+2fyz2ijYvstO8LEHBsMOR13rqOvNJAXPB4GSFNK7Ci3ujIUFPD7nAAkA9tsG"
"COb0B+4NDv0L8/EqEA0ZfwUq7wI9/QwNGQIUDvoTHurx3kEu8gCO/Lo6Kzz5Bfz0AhglKvYBetHT56Pc3RH47/bwCvEu5fs4/+QB8Pra+Q8f9woKgSzZ5hIk"
"FOAx8ss7yQDuGCX22dzx2AQ+7APiXx39KU/59gXzhuQN+fUZ+hYQ6NH8HBV/7gj6OaMe1AAUvjgtPMoZAwH0/xPpA+kLB4E/CQPwEAP+CRnj7PMI984R8f7w"
"DP3zEOXw+gUVGiYAAAH7OyHbFzzXqgn3DhkECw3EGwwO0S0mCwEICw7qDYHDAQvsBQkOSuUAFSDnFMg7BwDZ+xHvFQrc+QE8kQr48wHcAR8CFPQNMQDH8vjz"
"BvsL3wXw7P/xXxwKCAyBCvYVKuzcD+3oQt8ACNwIIIl4PO8k/AYF1fDv+f3/42j/y+71CQLr+fzP3x7dCBASBfkBgR/62wP7+zbc3A394fQJ/2CifjsvYiAW"
"1eshEBHP9sooW+DR5zvxHu4E+fvo1PDBHLvh1aQM5z5k4eQeBgd/AvsaAELS4/w78hTvEAT+IxL++PMD5vH54wF/7wYK9vjm5/QAD+4FDwAL7uoBAerjRPXL"
"+gcd/Ajx482HPMQEBwH3AyL9BosS+YEA5Pf3GQP7BAgUE+4PBQIX5P4C5ObkB+3jIzYXGuPiGO7t+AVmBjw/qvkE/xf+/wiY+gb7/uIX/f/5PfYb+uaB6fbP"
"0PMEGvsD/A4b9gjgAfcMCfcDDvYDgf87KxL09PfOIrHw5vnQ/BbKE/3/EgIQ6+sH790QJ+W4BgIE8vQoaPoq9zB/6wAmA/r8kRmwO/htBQS5SnHG/9c0ACrs"
"La/JOhO2/BD1Hk/+FvOJgfrSPBXG9/u5Dw4fHTPZLzQ23IoIZDv38PkOFD70BwkF/gDzCOnuCgD7E+4G/Ct/6BE7m0TvCfQOG//7KgwQAQT0AgTz9+Cv06M7"
"ytwN+v7m/3/1MMsNERfz3gHs2ToQIzF/yZnv73PuAQq3Fx8qCxPgJs6+6e3+IjS4CUD9OzQ0CPEOEwv/DOML+wrNHAX4GeoW/OwaTjMR/n8YIQzoEd0V08YD"
"9uUFC/rYFgf25MOq0jvz5g4D/cINFBPtAggJ/ggQAwEA9usDVtgugQC+QwT+CAD8EcgzDPIPAv8n4gb4+RtP3pA79ifr5vT1HSTzBiD2D/jh7dp2NhHzBMbw"
"gcfxaR6Z5Pg50fk/WtbRCxwGUG/fD/HaBNe4PIEc/fz2/Rz8BvwL+QL5BfDuCv/5AQ366wXx/wHw8QQO2/PsDQfgBRcFEh0RCgzyFfrMGTwL+P7/wQQL3PMN"
"FfgDHvP29RQQ3Q4+DfbyMPPjxoEESDXo6NHE6RL8ESssLvLy3P3BY/g87u0D/Pzx9v8E+PAJ/CL6AP3t/gwEC/oR9fH9AQ31BMIa+/cSLfcG8/P2Agfq/YED"
"h/6WOmS+K13KzfcNxYFRzwKCmp8dywwBcR+UBhWuKxWU9w/28UGrMAeyMd2iHMn56MeTvLTNjjypAQMHAhfO/f6D6AUp4QoJBvT5CPwXAwIJ3gL3CQID6oES"
"DwPoGujO5+n29/kBEsUkjTw8ut7+9+0DBA0CHRX77hYWAgQJAHT/Iu3uFvoJ8zbhAfyB5gYP0/4RCgf1AA71+wYc8r3vO9DHDvjvxzcbBfQB+tEGl0fvEgHb"
"ABzmJLwhA7/5xPjy68fmIUwMfxgV9SSZ8SoJI35ODDz1EfsN/gv/Bwdu/QMDCgQQAP37Avz6+f8F+gDm+vkJ2PEC/An3Bf8H/Pzn+gcCgQNiJMg7BRoH//L0"
"9BMFsu8PHQYDGQXnGBkUIdOhgSwEyzfnEhDU/PkS9BejeeTw6CgcBgcM+CsCPApH9AXygRTY8wIK2wIjivb/FwD5AigJ04rtBzsE4fz969nyJxvu1QcXMvX0"
"9/z7KT6D6Tvr9fQO/zrc9gj1G/vu7hn2/z0Y+Poo2hbFDRMsxvz2CyEUBAMOFIHbHssG7f303xwMbV08Ax0H/ezICPcGGAD0Cw7fBP8B+fj7Fvcd7iwG5hPc"
"BP4R7/kw6fp/Fv4L/eMOAvUH/7cdPAMTCAXi+Pz0+vkR3vMOzxH7EwEM//z0Btj+/vfuqfcYKQQIE+P82383Kg7oGgL9DBtkITzxJAbz/QECDwgMgcm38M0G"
"4RwEBPK2BAPU9/YX6/P5CwHZFwf2AfUKfirVH/4IEN8Ll6c75+r9Cu9/N9H5/Ckk7BJL5PgZAxfoDdD4Nhj3XdTrBy1X5O0p/9S+Ewb3+RAU0db1TZPzO3Y5"
"BfvnwREjDQENCxXvxtnzHvLd/wXXOBP28z382QjevQbqf1X2CQX+7SnzHQIbtll+XDs9F+brG+/0iiG7FQ45C/RQ/iEkKPkXE//ZiOa6fzPzhh3/3BX11HIY"
"2vwDON4+1iaNU/I7+RHvD/zzEA4DAecQ7/P8+u6BEQsMEA8AOQcJUPziBvoRAtkN4/X64eIUDeDeAwD5g9UCPMJUDfPWgSD+/+sTEyFmn9j0EfP0Af/nA+Ht"
"9uMHmgj27PrMDiLY5cUH9V1FMCxWRkZn3jvsLAcJHRsT2fHzCOMFEb7z/QgK8wLn8reo5e7SF0wTyvnzAFik//UJCyMoFeczgSni1QQ9uvb//gsC7AUCkAUN"
"CQT3EA3+AQv+BPgJ7RQA+Bgk/gGBExD/jhD18QD17fr/9en4u+9tvrlAdz6twDe+czQ9Pr7Rn76Tn2E+F1r3vEbnIL2elGy5BdPxvdfugT2al6a+L+0UPg2j"
"ID6YGyc+e6D4PuhPN74BY/Q9iS74vPAtvr3rRwc9hLOTPlTBrb6SaVi+z4rvvqBGmr0bsBo+MUSTvhKfYr5QXzC/qTdEvnzKZj6E6OM9bgrMvjTBrr4q4Ty9"
"ZcAxPs1XGL4YiJg+VLs9PsCmZj7knB++XjFGPPY4sLs5uyc+diUJPhPQ+b2dmAs+4RCKOyF9Gn35eh1/IdB2dDtJ7zwP0uCBcdUsnhs7DSGBCRORzITqs4gf"
"PCJ/HP76CwTgCuZjRTsKyQjIgcYBvgVj2sU7IS2BA6Ag4RUqO/YNPAb9CBGB9A8ZB3+GPDtDfzx/T3Y+cj2Xxs06AORif1o+y6MippJyOx4yITGBMiErHpYa"
"nTv02QAJDv82fzc/KKY7CBUtM4EdBSMwQofqO1DVStaB2kXZSn6BnDv75/vmgfH87AC6ewo8CAwJD4EPCAwJZlW5PPfIBMb6BgQEgZOGlTu4d8N1gWe9eL/K"
"dI07vvkWgn8yu98YxdLLOixqIn/pXi91LBr14Dv7/f79f/39/fz5AdM7+5qtEfGBIQzvlc4eO+aW3qSBl+Wj5ixHqDsHKgkugSwHKQfaCqE7GB8XIIEdGyIW"
"TiccOyZpHXN/aypyJhMtETz1AfUDfwT0BPERfyw859ACgQAK9NIJsKydO9u/18N/vtfB27VWOjuOup7Ef7uav43kyyA7vVuuXoFgsGisJJcRO84b8vp/cImy"
"qRyCYjv8lgSG9IH7iPW7/9c6/VPtd4p/HVAgMzUrOwoN4QUJf5xeLVBwRjwBAwIDgQMAAwKMJZA7ByMDIH8eAyEE/rkQO+ty8n/5f+166NnRcjvsgiGBjVsY"
"XzS3uJc7n/x/+awIeveiMP63O3/ts/DD/aL2Y2IMXzuwgcfTXgj+NRJyzHk7jNWB/8KiifyCG84ePAsRBfPtzPOB6cbkvzsHAwcEfwQDAgNfXdE78vf784H5"
"9v36qyrEO/zjAWCBY//j+pnrlDtoIlsmfx5bMVxyhu07DQoKDH8LBwsH/UgmPHvEOL6pQe27LW+SPE+UOT+OAfQ8vTA1PgHX9rttVVS+ZYO7OyXd8j3jKLA7"
"jUABPsRdlj4fKag+wUG8PdZqXb2BaLI9xxqEvicgg77jrmo+4ZZDPxoEaLrjCyA8JggevgJZeL9Nl68+vYU0PkxA0z7tHTc9fuiJvkS7lz45Yze+IXYMvV4f"
"Lj/RBKm9Zf69vCnuWzy1WOW99poPvdGP1D1R6ys+OAuePvxVYLwkmsI+Xw0SvWkw470pN+i+LI72O1sbAd1J6yFU7uX7Eev5gfbdEzgkD1Xg6diEALjq1PQb"
"7wEYMLwt/f4HJfkEDe8C1gI7Cj0NDQAJCAL7Bf/9Av/sDBMDA/4D9/AMgRHp8fP8F/n+9u4ACfT3+hQZAQTv/P4E/ft6Br088gwDC/wJGe0E+Abz/ggHBPX8"
"/fX7/Aj++YH6FxPT/xEQ+uz3/gwVH/wR+RT7AAb4IpKlPLoYAe+hNyiBBKv84YYSBwMSHufnMe76BlUjCsbt+wf7CBrWjpYJKfoX9P0R6vJlJYG3eDw0DQMT"
"/w/0CPvLEt3r6/YPBu/vFfgQ9SD61/rl+wMA8/v3fxwS9QoB9PT//P4N2f0j0eg7KF0EeQlN/xsRHzbYgQ4e/W0ZMjjr4y4eHUWT7gXs9vPd7UECLuYqHBsv"
"i+c9QBOuH5r3O0bm+ifKDvv7CeUN++zI/r7lwRAZ4hP2BxwLs/Qi+wcP7BtP/yD05we56RB/Cw3b4Sk2LD0ABADvFP0J8v738wrxCvAB/Qj0AAEH/gbqgfkD"
"BQQA1t/5ABH7CAEBBAX//P389wJvW+866wXo9Mvlv6vhHZ383bn4+NTj0g0L4/wblUTW7wy7NBsxHNGBk+EDucye5uXt6uPlH0eMPOwF/QEBAwn7+wT8+/76"
"4QUQCRD+BvTxA/uf/uQG+gXyBuaBLvEG/PYJAQcF8gcO5k8tYjxFHvsB/BrfQgj689D6+uTRIDZiF+JLByYy59jlLOkAMgMQIxAXzgH9JH/q+xX+FS0f+yc8"
"EO0KCgoO4QEJ7gV/7RMNC/keDvaxB/v34d0A8B7/9gEbHAECBd8QBv0iDf7aDwL5WHGKPC4K/gv9BewiAfc4Ff7oDQr7+/YK9gD7/f8M8f4YEfoDD0cVE+6B"
"8Qn2KNH6DhL14kqSNzzb7gkE9PwDAfch7Q4NJwrq3g/83x4VE98EJR4O9ugC1+8FN+z9B+foAfIT+vn5GYFSwRA8OQb2Kg4F8ksA7xQVr89/IAb7ENjxCdHv"
"yh/b3SED/hoO/CIT8gQcKfff5QbQCwu4b7j9OxIlBTsTOR8j/90825gT4dAhkgjVvnkHTfLB3d9/+QgNOe0OEjQWKB6oNKUWhCW8xkVt/jt0Gv4fEOWwOgT2"
"dv7p/jgbGLL6NbkHCerygZXtRBEOGPIDSEXw6xoU7vH1IQMyxPfl2jM8GPMKwCIM5wAJAe8T3TUOFyCBIeXi9fbz9wYD4C4JBAQrK/H9BuwWF/M+BOLkPQnb"
"NWnYO9DEFPcW1Ngk7eUr8OcjKgijgdIUFOcBFua6ST43/g3RND3JPdX49guoFi2gHf4w+RFaADzr9wviIOLuMQcW8OPsY60d7xMfqCZug+rsySYkJroE3wgf"
"LeuTCfMLCPYUAv393IHbZAM88+v9O7UV2bQL/10E2cD+CAe2FaLQMP+PLQbQ8CACCuzyPR+BJNgWIan42Rw7H6e3wijjOwbpBwQM6zv+CgH8+QA/5/8cD/jQ"
"GLVf07AoGPyb6v6B5Aj5Lvgk6OL+EB7eCQDRBEXIgzv3AfsF/AsO9wLvAtoGy6wS9gYNCgIMG/gFwh+sBxEZ79/4C0UL+P30/xkPBAj36oEO1Os7/C75NngR"
"AEIIHyT2KhY1+TQRDafo4fR/EV/aJwz//BcBDAQ4ugxEQxMm3tzjLgLz01isO3PtBi/bIBQG+jYi8N8aIgX41uBz4vwy76oB2yS6IvYk6CX+f2QHChPYFucZ"
"ABdeA65s1TwRA/7zCAMP+QT5+PcC/gMB/QQBEgX2BwIGfw4Q+gIDCgH/AxsmCP7/AAYOAPj3+v+bjrw7WOcGYggiuUT7My0NtkAsPznqEROt7R3rA1/zuCIv"
"6/szEyZu3+oA4cF/wf4WQ/uukiUbPCI8CUoeGxI6/OYELMQ9JoImFjOB9RxEGuo8x9tExwog/eik0uX0TFwc86biyTEj/v/zHjwUBwcN5AXd3w0QFvEHBPsS"
"OvgD9u3qFffbFPEGvfQJfw0e5QcW3efe+Cb5CxMMKOz2Dxw8zQUM7hbowKcBSLnp1CHt4vU59Y4sOvgIh/gKKEMB8hRGssSWgQX9DlnaEQnt9Ezzg8lTPCL0"
"//vq7vLmCO8B9+ENG/7eEQvQDf0tJfQfCLv69fw+8wUK/iDl+/gI9Bka4QT9gXhBRjwUDP789wHdXgngHf7r7cwI5OkpLy4x6O0SBlE/F876uyQakebI7fgB"
"5BclgTH6GAdlcfc75xrvDvUGBgnvUfMH4vTuI/oXEHsT6X8XKR/9Cy33EewY4foX/usUJhrf/wnrENj+TGTQOxoQ9SgD+X/TDcz4PSHlA94ANeLnJtoE/ubZ"
"Ehj0HQcZmsfa8wZ4BvkmjQ8DCyL66HmElzwY9v4Y7fv8CvzpEQIF+/gJ/vYc4/IHJAyBNfkbBewB4P73Jvb6BvP+8QX28wwLDfeayw085wH8+Q/0IO77DfAQ"
"8Vzp+SQV8X/98wsGFernCvgMAhQV6S3/5An9Bw4Q8/jvABwdVkfPO1oC/frmNLP0/e0t1dvG/93k/A3D/+/tAxeB8gzrIwj9/kvw6wCmBvnrQvckChWj2/us"
"kjvbIvUuDArwJe8XJAi5COygQAEWUfznNQr57td29N4ZJjfr2SobCDdICHWaf/c/P6+OYj08CRL+GxkO0uf77Rf5HbrkAfXv9rjzfyQhE771RgjtA/okG+rx"
"FfAC8PUY6SkPFtEHBMEYPDgG9GFnB5wTAvV/8ev78A4swvnr2RQQzgHs+dI4IAMYxir81r/E6QKkFdgGXB42wsaNVzzkNPD9+wPw5vv7MwvoG+0iECMX6Am1"
"A8q77NiBAiMB2BgyBh/iFi8J898CsRkMGtrblMg7NgIHBgfyMfcFAwLjLQHnZf7wEPAMrr1J/iEtyQH8/ghDDAzu/wAXDRAZGMTj+wCBUg76OyQYE1zxTwRH"
"9BsgFINGFkpa/nZP4b0c+RFkoNwm9e8PKQYcPgT1QDgAMbfZAX8zwWijHzwcC/siGw3fFvoCGgPsDgL6N/IFBcjTBgH9GrUK5fn+NPsUBAsI4QoD+EXKgQgc"
"19QvtRg9Dgj/DgoD5/v9/ggA/gkH+Q8AAP7w6NoCB/z1A/8B/QTxDwX4//MBAAME5/6BAwvg390MPEMM91IYEeg89OwR5oGy/DdADCLh+AQcJRHqvshT//oR"
"QvYl1gvaM0wDb9//+zY31HT5oTtMI/d87k7AK+naXvPD9RB6fL4m848ADgYKMIHoWhwIKhFKIQs2zUlSyUCF/RY8nbdlGng87/EI8PjpHfgIEPAIGAsWzMsm"
"FIkPIAAC74ELHuHk+O8X/I7uEhLs+BIMEpIB7SHpN86DPqZTaL1TpoU+GRbmOyBXiL44ngs/Qry2PZr50jyg9WG+RR8IP1zwaj9zCJW9ZbD1PXJVWr599568"
"YgHJPZpGY74PD+87ZC5TPq8Fy7z229M+YGKOPkG6CD4FG4e+WtJKvtt2Yj2oTtE88KKRPovxXz7wqyk+rBHdvVoTlz6DegW+X4BhPaPEAr3GjGy+ELkqvriG"
"/T6E0DA80qbPPMjxOr3JxU69LLAOP3wZCj4AbGw+bO5evniDxTykEDE+40r9Om1mdG/sfnN/f3SzGzt0O3c4MTl1QX95Zok63bUsga9aTEXsOtBKO3wXfydC"
"DH8wbNHsgDz/gQv9/qQG/vzFnjo7/IUBcd5w+YH9bD8JPI+N3IHpANIGEM0FbDv8cgd4rG8Hfwes1iw7KKB/wvyeN1xtE/mHO/jG9cp/wfnB+OKUmzsKnAeQ"
"f5YKigRvrZc76hBS4vt/7/c2i1dIO0hD40T6geuFuRCT7DsGGAIZfxoEGAKvIyM70YH7kQcz+Ts2xLmCOxLtCeqtVAtDgWscTDvjPUiBAzyxiuqdgmY7Aar2"
"fwhrDbIAIpo+O+iF54X2mOuB5Q32mDsKcwd2Cn8SfBP7eQw7aElmcIFeckdhw+JeO4Ejiyb5JYghgfMegTv9f/x9fn3/fPYJrsQ6J38tcVd6NnM5PtSaO/TJ"
"885/ze/L8pgXLTz8BAIkgfjqJvoeXoY72oHIJwS/LzoJ/lwfO+qtFgTi2qKBhJjk6zvur+yzf7juse93YlM7Un5UdLZ8YH9fIgi3O/r+8gZ/B/MC9JwCkjv5"
"PwCHhoH8Qv2NxOE7rpSsieCDt4Gk8bN4O+bP6deB6vDx9PRpWTvqVupdgVTqWe9T5sc7AP3/+n/7AvkDgsRfO/yZBZZ/kf6ZAgnXoTsRmyAu4qaBLg7hxqk7"
"+MEEMu6B8pgBuvVQOwx2/r7gvwp/CqIRoTseNx0OgQUABfnKZ687AfwE8n/+9vP9N61FO/J97IHajPh79rCOmDt/233h+t1+3XQA3+U65FSvWYFfzlrb7AmC"
"O4FVE1G1vBqzEXX3fzv9f/txHmjxffDooek7AAn+CH8M/wn7U+qhvaqyE76ZXZq+jV00vyfJKT5JaGo9RptpPu+DIrsLtRy9C6o7PvalAj+0wLg9VOv0Pebz"
"M745Z8I8PBI/Pb5aBT7hWFo+0hnEPlLiJL1xnAI9v/8OPrTmAcCAbFW8dV0JPm1IFL/+CAw+EduOvlmxaT5HMjM8ImXuugtsiL4X0uA+Q93YPhRcqb5UAdm9"
"PgKyPsLhlz3sO7O9ulQDvibzkz27oFS8p8VXPeg2hD1g5JO9IIvzvH/XgL0sHMS+A84nPf7rAO39BwcJAgEE/QUHAQEFAOsFB/iB/wfuAv8U+AMJC/4C+hMF"
"CQYBAAb9AgHoAFbU+jtLZvjjyvPCTwIEwAHSFNwf0AlJh7e+ErQBldYDTYEBJiMCKCcsEQ0EGff0yUIcAxSkqc07KyEAKsXPot3v9LQvp+jBRqpM9VH/AP4O"
"9uumAU7f1PmwThL06mULIdb04oEbSCOrBLKBPBz7APX76RrFAffb/foy5Q35+cguxM0CgSwG/vhaBN8LiRHC6xkPGPgI/enXzwYRExqshzsO2w88MyoL/94F"
"ZSHxP+T/6y/iINIAEh2ODvQE1C7ZNPIQB9vx/CQ0+/cu5xMq9X81EsI7TRb10unhjFUAih0gyyPDItQyMygKwdf4iMqs7TND1UkGgSIruDaEDdgN/djGHCWK"
"1qKYPPoRBOkSBB3g/BMVAQT1/PoLCBEa+g/+/wLbB/rSAgIEgb/o/wj5/gbxPgUF/vH/8bu/HDwp+wvZ2vX5ePpW9O4NOQwJBd8jFJX84v+1Ew4EFwPY94FB"
"3g7rE9LdA/TwCSX9GBFs4a489AH/7An89A0DFc/9/hYFBQABBQTrAAQVACz6BA8M7+WB7wL1ARkA/QEB/AcCHgz+UyYLPAbcCL7nFQIPA9m8/erk8fDsLPf6"
"HQ8HA8mB7wO27AAkANH68uzmmzD3Bhcq/vIb7jJIWzzXCfzI2gw1HfcL9yoQ+fH9DvrV1wH1gdwnvQj1DCbxHKu/+tvBARb1yQMRB9YUyMgtvMo7+uoMf+4R"
"mX4DcojUu1Xa/7EyyEHjsQsm8iC6/TvKm2M3Q37flCPtQLD+Hs8T5huIbZfNPOMYARgIBxIsAA8wDha6BPMV+Duh/k79gRkbDQTiCfy/+gJ68Nv3G/0aBgcP"
"BQHd/mgAIDz67wjKAxU5TPfuN88wrBPwMc/73eoDFAP11S/05hkWCATvAi078tr7AwYP9db8gY5R5Yo7KAfqD8wI5fLc/ZwKz7vnK90gzeRH5SHzoi3JFBfS"
"5/jxMNKFYjpxKAnaCIECF8fS32YiPNQTAvrS3twGDyI4CeIn8vHiCvo/89X29wwA8QztLNAkgSMg+x36BPE2B+oIAgj01AhtWTw82/xd7QDvAfag5BXWf9r0"
"3gXrBfnzB7b5Mt0ID/nTIrwNGVsN7dYBM/oB6unu+QcltH489f0IzvEL8OgAgfn67E31AOj5Htv2JOrtwkfj/S37IwJoAOpLD+4U7vTeFh4I9BP2RBUQPPgb"
"AVn1sC0QBycnJ0zAOORJgQMeDh4a7fnYXPIJ6xDuBjdArfS7Rsoc8KNCA9C99zMG3DvuJw78ClUEFP72vfcBFP4Q+hAAV/XmAn9n7/0HSvG4C+w72TPmN/Mu"
"/PZVzRAhptDmmkE8BQ/5APEB0+0JCIEt1xPjEdkR2zoe8gPj/h/Z/Bne3AnjBvIeACDOARn7B9IKGAveXOoHPM3w8Q4M7io2DwtMCBT1CfkTBdZV+iTv8qx/"
"FQxLPApO0wEV4MX6w/0R+ub75gADJ1lxBDz2D/f1IPYKJAHtOgoB6/zx/vvz9Q4W+xHp8QD43yfm+YEg5B3t8xL+9/71Ee/v+NzSRx08FgMIRcr24O77//YH"
"8Aj3Au8s9//++gKhHGjzBdMEJSB//PKDIArVHRH8/AcSBQ/Q4zjuO9cJ+4HhK/nkADKzEO4h6hnvKEkEOA/6J7/s8P/iqdb74gjA1cYf9CPF9inoCRj5SvwW"
"/Dvl5wz3LeEQDeT+BeofDxQGFvcUHeQO6+H+GhvzAOQpFP4qUfLqBn/o3PjgyAQQDuG+Ip479B30st9/0SbwFpMoySnY78NSWfpcBvCdsVjo8rjOFZ/brUv3"
"M9nLU/0YesBG6vt9h8UFPez0AQEHGvfx/Qry+PkA9wf8/fwOAP/8/f4I8/74CvHegfoSBff0/gvr+hkHAPLyB0KIFjwJJ/X5UATa+fL9CiztHvEC6zUoy/kT"
"+xvC//Xx24Ee/fto9prq/CYW5/cDrvcEDsuxa3Q83hQJ6ucLLQIB6O6PFtoBASHgH+DX9+QQwRAN+ygvr7/4zoEb4QU2wtIYD/cFAtwDtjt7POD0+5EK9QP+"
"/cDy+PwC8gP4GiXdAQEBBAj7/AYKBO3Jqwj8m8IGKxsBgfqrBv/7wD/mhTwp1AcUCB8a9P0a+vsi3ggDGxrt8en2//HKLB0F7B+BDwf+NTe0DBEaLucgCwwI"
"pQAQqT88EQ0CL+kbBOEF3eH2AecB+wED2xILCvn66uP/A7X7peDpAfHhAPTjBNn7GfeB9vYSLePpO9CpDg7E3PYBB+iiCswQ4ArSH4P/Hv736Y8p7AxQ+csl"
"gVYLDjE0YQz/UOvYISULJDFvrjwKGv8QBgP67P/8Dwj88vcF+gABAg4JgQD9F/r76dnn+QwbLQEMDwIC9PoFGPkK+OKeG5k7DQTeXNXvUC4QM7frOSoi/CwH"
"HO8MIPYhINY9DADeC/7LRoEiA/6hGhT35hjW3we/dHGjPQD5AP7//gQDAPz+AQQFAAAD+/8IAACB/QMIBAAE/foCAwIFAf0B/P8DAf8A/wD4/SZy7TvNPQ33"
"3A22BfIQBRXv6PYg5gETBvjv8QLRf+ADI/XrAmDsGr70/6H9AzQc+QoW8+C6RMk9AwQBBf0DAAIAAgYCAQIAAAD//Qj+/4H89/wDAP7+/QAHCQID/QEF/wMA"
"AwQCAP772bo8PBft+wgMHPqQAvoFXf326/zwCiITQCL+ge7bDwQBJBbT8RTXBz3y/S5BBgrM/PnL5ewEijwCAwfwDUX5IALtMfX3ogny9DK+T9w+AIHmPu4H"
"LhKoPPHjdu8Z2jA8Cvg9xATsvPt1Qz08/BIHBPH32QwM8/wW5RDyB+I16RkI7wTuEQjo/N/S//Yj9Bz7CQ3/H/uB/On6/zDxfHELPB+3/tAK/+vf++bo++2I"
"+A3yavQYBgoB90PM1gnS7Qbkyep/SfkJ7B/n7TTcHRA23Gtq7Dsk/RE46u7aNhAM3RnJ/cEdxz4IPuzR/tJV8+EPALE4MvZ/msGa7/wD9PsAoDMDSa6OrVo8"
"Gwn51OgF9xD+Av9PAxDuCfD79gwK+Qf7+iYDBf39AeveEQIE9/8NDCj1AO+BAwfzXiT9O+s186EBHBg++VT0HfpC4Sv9LAr33+zfF6SD7w0k7c6qgf26tAEw"
"6x+9ETHSGzb22ncoUjwpKfwoqibPBwUUxw7iLt4R2hkVHt3tt/eQAef5IoEK/dZJBArtKe8O+eIl6AsT8xFkh1g8AP3/5y4ZEOr9/CPtDw8K6Azu7dII1/kA"
"2VEE/fYF3n/54lDTwq8S5PXCECYG3/ATWbp8PEroODvpcvA+HPtePUxmy77Uaas+yKgvPghMwj0Frmc+69kGPq33Gb/icYk/5pykvhzq0j11mo8+qxHVPKER"
"0b7/mAW+8mTbvnTPDj5S9WU9xogaPjkduL6ghe08kfJ3vNdYFT2UmnM7RBiJPiUU9L0BDx4/ejcSvnDTjr5UBx09O6UNP439cj4Se1g9KXjpvVmdGz6PNwe+"
"GwLzPYMm2b7Sx2I+PVG6vbAIEb9nX+g9tnhBvuE+ML9FZcu9lhdXO/e267Z/tfi6+t6ECTtyWG9h4F9/WnA5Qm47DVASUX9LDlEPwcTBO/0X9Rh/GfcY80iY"
"7jrPVlSOmmPKgbojBTA74JIlkehGIkyBKmOVO//y+/Z/+wH7/b0tBTs5fERy6H8tej0bEFk7JYc6gdBBPjqMnJK3O+yH8o0PhveB9bvQHDsd/RYHf/Qb+hx0"
"14M7H6HqO+CdgS4hKGdOO3obfxZUCnQgcN4ggTvagtiJ1oHVgttteAo7AXz1d3B4An/2H5AtO8Or06eBlc+k1RvVFDvzjvWIeIHzjOyRS2o7Q5BFq4G+Q7xB"
"WbQTO/B/+3bfcft6/5mwgDv7SfRJgUXyRvefX5s7Atn913/cANsCNSNQO/Or7a1/sOSv5Um7FjsOlgSXgZoDiQNRJpE7/AX8CX8I+goEBSSOOw0XDhZ/FhAY"
"ESslaTv+9vz6gfYB9f1GWJQ72NXa1X/b3NvcF/GIOoqc8JbsTt1/De3+6DrIBSyBEjK4AjgTuKY7JiUoHYEnLiss9qTYO1pvT26BZlpiVTWfBzwEJQcngSYE"
"KAYvk1o7+jICNoE0+Df+4aFVOw+B+hS6ODRQDqWtrTvnsQbpjt/TgQoX74A79gME/38E/P/9C9lnO/R5+31Vf/x8+Yz8gzsJEwwWgR0OHA5SKTQ7NMMxvX/F"
"OsU1QzHSOkN2SHXuckh/Rs5nmjt0Yn9lgmF2WXJqh107In0ffyh/IX4bJN8EO2KBaYJNjV+FZIrWBDsHgQ6CNoYNhgO3z8w6OwWTaOGBTyqeKpMfOyFNiYHz"
"T92OIlWEVjsPcxB04nEQfw4gCN47AfoG+n/8A/wDkE1fPsgzWb2j1OG9kCCRvSUKNb32ktU6SOovvn8UwzxDjTQ8u6LlPpDQhblFTRA91u7lvkMpBj87Mdi+"
"q9xyPwaOEz1fqtm+PHTFOp4KID69mAY+NcfLPtjDQj+B5Zy8e8bKvgbJMz9XiKA+CzAEvY6/qLvQxbo75uU5PnHgGDwsJYQ9bXggv6ehVb7Pt6G/JMh2PP9U"
"+D724Ti/STXwO0LoGr+Hj4O7UrEMP8Lq4j6uHQc8H2kzvb9/GD0RvT49KZ4hPK8ZswH7Bf3Z8xUQ9B0+0v/cbkvlwOETPfAz6ADzF0wqyMoTWBMLS+YKgQPH"
"E/jf/N0hxTvtR1/TrjKs+tMkBzPgW+iBSFC2+5iiElDVrskf4Twy39yb9uq2SMTS6wX299U8lwKZjFs8BdTMFRkc1lMZRhYSMRfqCj+01tnhVAva1tQg7Pve"
"DRsc2QL7/zDs5B+BAx8jIwT5RYFrPN3sEtbh7RRKFkkB9QgE4ars0fbcBiYCLqT+NPsGHrrt/Y/07PHzLAzygUjgCgP59ifmhTvG6TXM/DMg+jMV2WLqBObu"
"CzZDDe7pKMPd7gfB9v0Z6OR/5EvjphjqKgdFKf1AteoG6uY7vfEg6/UEEMDhzg/lqlKtwKPq8Zev36DPuyThEePvtKqgB77ZKy0O3n/CFQAc/yZXTcFePPuG"
"Dg34CM3Z3d3oAAP8/4EBGBvx/fu6BvMk9v0O8RTyDg0QvQ3BEcgT6wkC+e3zCpgVFjwlMLwsS9bY5sC2OLzgFc2B+/jUtYza/UbrvwEfFxM0/AeuFEwWHssl"
"TNb7EhPZJgJEKUM8Gaw3gfwvKu0y9/gz2Nvx5vL8+RsBJMQLCQ7mGuulA/D96BQYzuED6eH/5AfuOCIm6qu+OyHUIIHm+F0VFaDz+kVF98uNIQPt//8O4aOe"
"59oZFMvnGhra7vObQ9Gt8fteGPwp/nvsXjzf+e60CSJb4hw86xTMGIEb5oEX5OwmBifiCNjt7e/V8sJLCcOXvCa9qrMBHWcYDU/oThs8AAj5WfvxMubaIAv6"
"BeuLmtQRFQqtMBzKvLDeG/qmFjYXyvTl5sMuB/oGNP6B1/DZeRRsPP4E6AEIA9v3//D5A+HyKaYFDe3r3i04HdTy8/EQ+j/c93/j0xQg8xHjBg3nB//I0aUN"
"IzwA0fu0CBknNiMaAx3SKgaBxMUlAjYQDtPpBTLs7xIg8P3qGj4U0xe2uM3qBvUMFg/RfCg86xXV6APoEQ4QGe355BnA/OjI8g0A9dP89wzuCP8yIPzlgfDx"
"1/n033cGB7H6+hf6O3GBPAXRJBn7CRDW9PDZCDjv+YH9EgL+5gn01hXf+BID9PMC5ODlEgLu8QXh6fgC0QgEMjWemTzq/Rsf+fwN6Quu6gEUEvL5Cyz27er6"
"AMYD0dwH/vQD8RgA8YHR+gguAPkI/Pz+6vS6N2g8Eun8KPgN2d7R9gwACvU2A6vx8goRAB7X+8AW8ekA4dkqWgfY7TkuDYHy8A3qAOatk1LcO5v52YMe/A0Y"
"wtgm9Cf04OyqRSzD+PECRgwolQQyMhceNH9FP+H79+BB3hzWQ9olO5JmNjzJuuWBFAb13hL6Nv/yDha26t8HG+kCCxvEINoYxyDyAfnJIutLEuPA69QJ2wwQ"
"sgT2msM7grY6G+ZuRj0FwP5VDqHVgQNTABy7c0jA/Jrv8ugi/8rQ2f27MrQdT48eyxbKT8E6aSbgOxvjVr/9HuQU5dX2B+ehGMHl/aj4BiPpJfxOxOn78hnt"
"yvngNgs6g/d/+hz7/QD2gR2zDDwL5dLsHev6+PrC/fYAGwuB++oM8Q8CzO/Ozv0JCgQSKP/1/gEh+vwc+BkAzAPoDTlBTYI8pB3jxPAKCQj8GyQCz6AKBOjv"
"AQEE3Sqx/woU7wAAHev+f/cUQPsV99ET7e7/BPjYU/3lO/Fn6wrwFRReHjHUFhYi9dfG4uwiCA1V64HYuRMHEhr79iYKFPcB8d64M/POARpQ5SkkIjzyAPf9"
"GQMDDf/gBAUAzvaf89jK5Ab4zR/Uf/38DRDMHAc9/BDw/KrZFxD15AgHHh53GBI8Lgoi/AkACu38GTkCuWsBr0HgDwHn1x871YHF/ePd1PShs+xP+PMONAni"
"GBYC/9z8XgATPFPy1bDikqAW+uwhmusz682B/Bgb3Pa0Iezi4fQA7iDrGvny8N1ZCsFb8dHlGpzh87JKGTyqBkD4DQ3Y2P7z2f8k0ROBCfPiBv8BGvnqKeru"
"7bAs7yNX/E3ZMwH/yyroCwwBGBBCHyE86ejwGdkCBM3+FPkGv+wJqiqB9zIXqcoOyb8WD+hAK8D+//DO9vcqAAK+NyfxDtPcluDSOyf25vD+9PT39UoK9sxC"
"Cdgj8gE1Gw2OLDtGAfrqvgjD+XAEw1/98KYVGRp/6/Ur/UpiwjsbKLETCAE9MhMQSPoGBFk9uPcq4yAJSv6ECUUV21BDTdt/8jsU2tYpB6H8tf8Cr2wRftI7"
"ABP8++viAAEFm93fzXCZdv7rwgsq11Yj1uPy2h5J5umBmOXOy0In5qX4JRzm5eTomwA2POv59vXtA3/4IeMIBRH9PrQBEfHtxCEFweYGve/19fIP8BwMAf/e"
"vQrq/ez+/A/4E1Td6Dsm6oGw9wz8AgW1IgvuGhi7FCLZKBymMOjQJd8WIAh7MSOK6SAZC67jq6cQbRYS6LsuqeU7PAbRqirB7/sCDNjBHwb4qgouB7/q7uoD"
"BPn78jdP72XMf9/a3BlBAy7iCiQb0wkSgZPRO9r40IUK8hIB3rgf5+Kd/ULkUgXwFNzb/vUZ9fsr7iDUyW0XNDf6LhGtHyKBF/EL5I6BYTz8gQABFfH0AfgK"
"9gk69/L7ABL/7eMNB+PY+/QS9Oz7Kf4YB+cQ2hkUDgz5/PQCACuu70g8xvHO1wIFBBb7IP0FHNAK8y8QIOIeO7zYDOgZ5Rou+jz1gQSq/QQR/OIAJOkR+uj4"
"q2UHPNUMJfBD2gH17B4t6ofxhLLsf/7VuM3C+hmyNREIG6QGJDgytF0BkSExsAciDOoPGH8ZXzzdC/AMCALu+wIuFQIsSwOg9Bv6rAIYOwr4+gPU+sr62IEi"
"HgUU/vkI5u/5/QcEF/ku5vQ7CuP2FwLsHBjo6jbk/5qYsv7LthjrA/jl/BQHDBUcM+cLQgXqf/kK+PUu3Nof727ekklgPP8S6gzw8scG/YkY8RLf47z/6fWp"
"zQqpge0W0/T6/gYREboA9rlDzSQW7QzkEPv3MhRwrDvN/0Hs5AfbBwI/+wgXhCqR8ODRDv7cqO8r5w79CBIsDv7TEt5/HSce2BHT4+oP2981D7k8/esKBAn/"
"BPXy9fwD7PXlgQEAAfzv9fX6+ev9Bvn+8AcKuw/4+gf5AfD0AxAJ+/+9kOpnPO3O5Ojt/87XF9gHACEK/r3b/PYd9fSBMOIH+PT3Ae/35OgAE/UvGu4S8fvi"
"Cg33RNqF1jsv8h7sGSbQSw3jExzdovuBx/0M5RSg6fepA+kU+8JSNUo+AwfQI+bQyEPv6wgoJycCEek7F+ER6v8I+OH67toDLRz5Mtj2Htn9Ixv1NBj56QDt"
"RBjpQeoHxwQRPrZGB+H1BCuBJP21PjAOvD7uCFI+cUoxvnCFur5ADRG/JWsVP2ey6D2IgPC9yM5VPhqwjT50KiS+9anoPSR1Yz6HyYA+TSMlvwsL0r5za66+"
"y14COy1LyL2LSU09xZk2v64Qxb3uAwC+19KTvgzHcL4V3YK+b3CnvBv6uL5bZRA/CbI9v/C5iL53noO+eaCLPl1WDr5Vgce+Y9fdPtNbA76lSAi+HfyqPknG"
"X73FZ2a86UwHv8zIbT6hTQg+vYMXvxFXgz6MgQO9ThXgPPQEGSjWAu/q9gvfAvX59ATuH94EAgb6w/f1/CwFB9gGCAP4AAD60Ant5gj3BeT+1vD9BerqBuoG"
"ABAV9wMNB/oFDPD7+QAF8gT7//P8CgAf+fYT+v3++/ASEfwA/gMX+AsF/Pfx9xiYA+AGORQP1QKzgRDtdQ660f+iFtIFAyoGDSQIz+8mIB8F96Mhy5zxHTCd"
"8f4JCAoJBtIPdvEFBefiQuc71hP83NXo/gsBBxzs6AT6GRTLDwLdDvkF+QYA2hMRCf8K47/98fAk0/EJ6/8LJfDlFAoMKAQU8/v4CwMMEvAL7gDzFAT8DxcZ"
"/eT7EQ4B+cL94gkaAAwH5wv59/wD/vYM+QAaBvfS0Q3K/Q688xIk9AT7/hjS2c0aFc7p7Q73CfbZ6/j5+r4Lsg4Grf4T5hf6Hv77/w8LEAvfDQAV+PkmgTdc"
"qjoh288tzRTwDfi65v0HC7/k6MTlyPbGAPfI/Y/6BeoNCyUbAurX8RjLUaTxrf6bu/a3xwzrCPCnuxT88rwzu/jsRf1l//XCAbri/M1AKOkmB0Ih+Ognozme"
"+OLr493t/8jV1ePVo+kI0/vYxSX1vh7E5c3c29TaiQIIzwPT3ZxAoLmO1PayIb3lCun10OoX2IHlua0Dwf3V8/vx5ynBF+Levy9bPfsD+AX//wb+AfEFAfcC"
"/wH+/P//A/wE+f0CDAD2EQTvBQEGAQID+e4D/vsGBPwIDwL+B+j++gsC/vkC/wsABP4G+/8G/P7sAvz+BAYC+P4QAgIAAgwI/AgB/f8D//0A/f4A/AH6GQDy"
"7v0GCfv4AA0O/QD9AQgT7wAJ9Pj5AAz/+f0C+eQEF/r1/gMM7hf//RyB/AEEBAUE49nz/PsJDxiATIA77+jwIxDo0gbi9hH4+egbMc4i6ef5EOoK/8cTCvvo"
"BtH24goQ+KnyGfL6AIjhGfvWHQgjDvjY9PkB/BT9+Pm35Qz4A/cD8fX5+vwFHvYM3/reA/Is8Nvw0M7mFPoJF/HK2cnFvYH9xbfNubvyKaaulSa70b33zr/Q"
"wL0LwcK5pujD1+ahy9zMBQzl0tSiicEq7cEX/uL84uszEWX+AdffH8pAET34+vfu+wgZBvUJ5/YA/OUQ//slBRrxCc7/8BUWBRUC+Pr3BO7o9fb4/+T6EP/7"
"9xHwAAQQCu8MCAEIAAnrGvD8+//9AQIKAwIEA/Mc+w0d7f/xCAYC8/cJCQ4GCf3+DgwL+Qj4A+SlIwL+GxUIHBA7GxgV//IKBhcB+OLg3PIGBwII/Q4JAg72"
"Cfb+/CYlAvcn6tUcBgMDBKIOgfrt1e0NqWMrPQQI/fD+CAYK+wAEAgD5+gTwC+7+Df8EBP/8+wb4/PcbAgn+/fQGBwcHFv8EA/7vAvf6Bvr9BREG/wz3+wjx"
"9P73EfkHA/oICQL//AkEJPgNBv3/9vsQAQkK/vj5AAH/Cfkz9/MCDuwEogzsHQX89gXrQvqc9tWXYwddJvka8KcBBvgc8wn/CRcKDPrMH4EHBALDBPsDAQIC"
"HgTs6P8H6g2s0hA9/A74AP7+A/3+/QAD/wMA/wX4Cfr/A/z3AgEF+P0AAwn7AvH9DQcS+FIBBwD+Bff9Cu8F/AAAAeb/AfIKE/8HBf7+Bg75/wDu5fv+APwK"
"8yAL9Azy6wL/BwEMAvsB//QLBv0BCO8KBdMBAgD78+gQBvX7BMQLCh/aEdQNH/0JLgAIBAPiB+rU6QEaBDIRAxYJMQf55QwMDgwf8ASB8vUAsPFhoDoSvdn6"
"z9Qb3w/q36br5I4WxQbO7/Xr3Muc08wK0Pm25+eoBsfC4e4B2tgOBssF8vgrGuPjENUZwe7o+dQJEI+wOxLNCfsBwQPtEwT3KOMGzRO1vAMVySoC6MjqtQWj"
"8gS8DBCo9hjQFBqqyNTc+Z0EyRyBGNwCrufF5eAAzdvvyd7VyMPKtea32KXz5BLywuLk7rv86Q7r7dUHJb4BFBQOVd6yPAYn9Oj+/wIMDscB/rMEDP799gcF"
"DgwdAP0Q9Asu+AISDBAG/w8BLfDYIunzBQMH5QX8Gd4eBgoO/O0r++UOCAQR/An1Buf4F/TKAgnv6/H5FPEO+u7f+RPuAPsABfgBJ/0d6OOmExi5zeA5+g7K"
"kQSz+AjiJQqn4PKDJO8l+tr87r/h1OjFxfXi+5v23LwCA0SB/NsEBggIcMPBLfID3NQIBDg66Nzrq7T4NIsKvgQ/6IM836KG+84UC/As07e8PeL/vTEY4w/1"
"1I8eGkkn4QSJrDbCMEAAoCiFRpjLkI7BMco5PPos8h7mFhCnwdSjoxKLFBdAFQbS9tbCl8pAhdM0DZyk+oO1nzmX7UdGpwe349IQhiyyisrboNTIzfeXluKI"
"0/3HH7UP1tqn1qj7N+bHgRj2NgmDq/zX0dcbq/D02kcuMFZfizv4+fYNEwznAg3uBwQJ/QsHA/8UCvT+/Pn29P0VDAjzAgYDAf73+AkCBAn/9gL4/PwaAQbt"
"AvsM9vj4Ivn3+gD4Af0FAAP+7BcD/vwMAvfkBvQCAQ0DAPUB/Pf6AwAH9hIBPCgd5kQg8AYwFHJmHxIAavt/C1L4EQdAG072GwjuOB4hNQwkIxo1ISoKPunr"
"F00LBRgCCQ4JDvweBi7+HPMEK6wqPfsF/wf8/AIBBAb9AfkJAwH//ff+/gMCBQb+AwcBAwQG/gP5/P0A8/cRAwH//gIC/fr+Agr8BQH7AQMAAQL8AwAAAAEB"
"Af35//z+AP0AFf4TAQYG/AAF/gT9/P0AAgL6Bf35CP4K89si9Pr5DAT+Chwc/gUMAfwL6/8D/Pvy+QYB+/UA/QwR+hMM8gj8/A0B/wifGfT8/Pz8AQgFfxMF"
"/gJnvJU77+3UHfXlyPrY3grf/uMKH+AY4ef38f0FAMEEH/LuEuPy7QQN38//BPX396fj9PfhDgL09eXt5fD9FwjY/ACuCu4J7fgC9vP66eUT+v/25e3T++kV"
"++X23OvhAv38+Ozj3srFyrwW9LSh8tEiBMm0wEvZDs0T9OKq9MwB2dvOgdTs+vHd+t3Q+vAI7+W9yOUl+dT5C/sK/O4SEF0LFu/IDCwMuzwEAwX2+fjwCwAD"
"A/oF9Qf7+A0O/AgXpwn5Cfv0BfUGBBHzAvv98gcBCPED/P//BQT8BPsF/wIQA+gDIAj/AAIFBgL5/AD9BQX9+/4CCAcECgX0CvoK/QUGCAMO+wLz+wQRJuD/"
"BAloC1j/5iEmsfTj0RHnq+L0AiH88wTsD/kGBv3GAwDrCxfZD/M03NRt7P2B7uMLAgIDAQ8SE/f5tfQCEOBFPQ4ECQUEAv79+goCEAMC++YGB/wA8vn/A+8D"
"/QkGBvgO3gME/wMCAwYJ/wD/2ggL+gACAPECAP///v0CAfwAAP7+/gcAAwEBBAL+AQH++/39AwH/AQX+AwEEA/4AAAEDAwYIBA/8Ixz3/RD69/72+CH+8wrB"
"HggC5QP8Gg0MCvMEDBAK/QoF/QD7Cg4UEt0CEYGwF/oEBAMG9POk9g8FAPrN+Bc9DQr8ABwGDAAR3v7//gMC/QkP9AUIAAfv+f0H/PoIEgICDAAT+wwRAfgB"
"+AoE9AMA/P4JBwLsAw36/PgACPgW+fECCvb9BwYF+/4PDgYIDP0C/P79B/INBQXz/AEB+wkOBAQE//HqGfH0Fu37ItH9r+ASAAIcJxzxB8Dx/x8I+QcCA/T0"
"+QHg//EaIgrZ8fwMFt723wEDAwH9/PuB4vcE9bw4OzrbwAxZJN8aLwGqGokpldHPtRwouRUZus8IDi3FU0YhCPCbS54LDkSh2Q2RvASTkqbhDMP6vxvAKvfJ"
"tLLG7P1Pg6s0VdcOrhCfQ777jt8ZlTycR+UKCSYFAyVEQD3Pjx+T6xwSkSOhosc49tHmyNM2BOHIXaWaQpn3Jj7dnz49kfn9Mi0N9ozdIq2vy86BQBgt5Yes"
"oI+frqO4Ww2l4Jm8Z3FdPQL9BAgA+P4H+vv6Agb9+wcJ+wQB+QAHAgD8/RIFBP8D9vkK/vzx/fwE/f4D+fwA+fT8+///Af4A/wH2APf/AAj6AwYK+gfz+v8D"
"AwYABwL4/wIEAQcACQMA/v8HA/cDAAULBQf2CwDl9woP+fsADfb+/wjuBgLu7AX4AwMFAgQGCA4HAwT38PcGB+cMEgIDB8eBGN0FBAYF6fvh0gzyAfyJPOU8"
"Avj8Ccz9Ewb0M/YCCvkRA97mFvv/FQD/6PILBQQW9gn/AwPQ+AYI9fDs8wMBBPgIAP8EAEEC+gIB2A0A/ADtAB4fBwYB6AX7FwnyAvb6EgABAf8lAPf7CAYR"
"D/r/8wn5Awn7BPcO2wgQCt0C8gIAFPf8BALn9hUP+/8JBf788QECAAoIBxcVIAb5AvQDzwH29hjtKQUFBgX4CPR/AgrpBomj1zrsBQAuoLcJ2+Qt/zroE8fP"
"1/FLFxTw3P7P2/w3zw4MBTbq69quIQnFeefb5v7VIP0t0M1CDgP5Db3mEwHi0/HON9rlNhUDDjMiB8CqtvMpMh3nAfb/B+P2PAzsnRzwvQjr5NjTudar2bji"
"y7XBupTx0gTlyN/M1/ffkcS/xO3hwcbv8MXfpqPhgcoLn62ht+46BvoJ8M4TBjXx78D37we4BDo/OiCxtE0roT8AEsYX0MW116KfmAMPHPKwijpQtEqe/O3c"
"w9ZjlV8JirvYkSrzyoGvK+fmzbmp26jr4f0bQ9erqj4e8E8NrK33vzXLDI2DKc2v5wzNx6vwxqghn5bP3eZLqOuIGx0N25EqXiQvLa8CIq60D/eY2sfAY5X2"
"qIwqpFDdqd8NpSwr/iEy/gNY7srAoSKO7/UHQg8wu9dZ1xbysOGWp0s9BAcGF//+A//6BAz+8wP/+wT9B/0ICP76/f0AEPnf+AH7AgcKAgMBCfwF/Qz6BgAE"
"/wD7Bf0CBfbyBsv8Df8CBQb+CAQDAgX7/v8F/fz/BQL8//4EB/7+AQQA9f//CAMGDxPjBfjtBCaX/O4GG+YGsooe8IH+5oEh9fAB3A7t6v7z3gv3/BUc2Q78"
"LM757/n68RgH6f/+///5Bgzt+hQFCgsoaDrW29amMZqSyhwKBMaShQWeFYlL68oa5+/ayefg70f3qLvzFuSpz7or/qWtL+kOQUYdsJjC5wL4EIeFmtgj9afc"
"lLfmodG37DXoH7qLm1b63vKSBrTYqpGHQ9W/pPiLwCHVLQfXAJrPwxO3viy8gdkW258TIu8W2bbkBKQAj4sY9R7bDPD7BdMdGgrY/+GfF+Lgxu/h+vrnD/bx"
"KuYm4kAL0bWtPQIGAgQECf7/BPwDBgAD//j+APj7AwEA/vz9BgL7BQECCggBAQIG/f4GBgD9CP7+Bvz/AP0CAAYC/AH//v8DAAECAP4DAP8A///8/QAC9gH+"
"/wAB/v/9AgQEAAH/AAABBAH4BgH97vUAEwX/AAEE+vfz/ggQ9wIP/Qr0+PwE/wUB/f37/wf29voI++8I6gQDAIHWEgX///7/CwDBARH7/QJJ6ss8KAcUFwYP"
"DA8ECgYYBQX71vEM2vzy9gnn6foB9PvwAwcQIwv4Fhb7DP8IBw0KCQYJ/gL8Af4C8QD0AAn28wXzAfoDB/YC+/7q8wD78//7DvP9Bu8EBvoB/QX4+w7+AAIK"
"DxgbB/L5J94PAhra7A0SCPbmFy4w/hjOBrcRLx/+MBUKEBf2+vga7RUExA/LuggTisFD3AYJBAcY3IaBLwoB6fRVGT39AggE/vkAAgEJ7/4M+wMM/wUGBAUI"
"9/n3//oA+Q0FAAACAvPz+QIGA/cE/gH5/wsJ/fwHAfkA+/8A+gX3BgD/+vz/B/oD9wAB/QP8AP3/BPsG/QIE/gX4AwIAAPwMDPb+Afr8Ax3lEfHn9f0G8wrx"
"GQwIAgb0EQUCBgANAgfvAArw+/sBJPj4CgI0/Q32+wSiCz/sAAD//+z8gXkyBAAHICwPPfwBAwkABhAEBgr/+v/3AAUBB+sB9PgF+v4DBv//Af36Af7++QAB"
"Dg8P/gkEAvj/BxH99QsCA/z/AP75Av4H/AH8BQv//v4N+/cDAgf+AwMHAP35/PQJ8/sA/wAAAPr9CvT0D/oC3LgOuPwIIOITHQsB8A5WDwUF2wjr9Azy/yoE"
"/RT9BwTu5hb1/KkTCS8G+cyBLgj7+/z8Cd74byv9DfdY4VA82fraNLzP/wzrU/8ALiwKD9Dw2BDYS/7xIN9aBOsYLq4lxSfwBOP5+tfy1qsXG/7+89cF3Bro"
"2SO/MQItDTFQ8uEIC+wKEhHkJQsPBPzr6dkG8Pw3DfDy+uIhFhD9/ubpBBDFCenoiKFktK0PB4En4/8p/ZUgvgop3p0KAysA8frW4RDP0JwaEs/oXQXhse4E"
"MysxSgMC/QNtJ2stU+Q9Gj3PlTzXBRGz/hL3EQ76Cv8R8vL6BAQB6gHs5/r+AAHnBuDx+BUbBwkHH/XZEAQN6w0DD/Me+QLq6u0GFP8DJPf+CfkVBvs0F/cN"
"/+X39vrs/vXsJA7Y9vwI8w7m+vMJ/QoF6Af7B/zQCxIBx0QbHd709AIKEuf38hAhI/QQ7gQdEOsbAAIZCQn86+qk7xP+CwsxGgsbBOATDg0LDoH2rEH1H/oI"
"bhTYPfz9/voB/QICAP/6/v4DAgH///4G/f4BAQD7/voB9gIA//0DAgT6/gMCAP79AP0GAfYAAgP8//gBAAD7Av39/AMCAP/6/wAA/P8EAAD+/gD4/P8A/v/8"
"AwD//wMCAAEC+v8B9v7/AwLsEgHvAgDu/wMLAf/j/wAGCf/+BgsDAgIABP8E+PgGAPf4ABf///X+AYEEBwEBAQEAAQLsuAb//P5anFE98gP95//0DQH6BfoB"
"DgL8+/349Qb9Af79BAQCDfgJ/AP+B/r5Bwfy/u4SB/v7CQgG9AT7Cfb+EvcB+vwF/PIV/f8GBwkGCAL78/0G/PgF+xQCDvv08gnyAAj9Bf8BCfkIDvYEDxP1"
"5OlJ9xEB/QsHNv0OCSbYCH8PCifwKu4POggJ+AoB+PAcIxQA1wgFR/35/inxAwIEBAPh+gf+9xkQD85FKD3vAfQeEgoF+QHm/v/z/fX+9w7z/f/+/hEIBe//"
"9+YE+PoI9Q4TCvYUBQn4/vr4Ef8T+/cB+fvoAPQVCQr8CgYE/vAOBvwI//ny+QkNAREGEQT8E+TrC/IDFvD9/AQD9wcL+AMDAAUS8dL+CAn5BxEM9AkA6g34"
"F/4EGgUG/AT6/AUS/ezwARoN+AgTDfPc+/wT3/4BCAcICNiB96EBDAULWNgoPQ4OBhP5/v//8gz8/wcDCA0KA//69/wDBAkIAPD8D/kJCvb3Awb4AwIEBAD4"
"CQgBAPv89vj/+f7/+BP79wDxGQUKAgz5Agb79/X+CvgB7fr4+RkE//sLBfL6+/0C/gcB//cQCxbh8vHRQSoT1dnrOO1M5wv3ASj5xhrf8yIKDU4CBhnyEe7o"
"1Lnn+LwePhAIDvvZ+/kEAwMA+QmBDPXnAOn001c9B/wLCf8I//kB/v8C5QLy/v0W7gX6BgcIBwb7A/YFAAYBAgL9CgHUAc8G+wIB/fLt+wgACQL6+gAK/wkB"
"BgoFAuz++/wHAf7q8gT9AgL9CAYBAf8B9wH+AP4EAvsB/P4L/wX/+fQGCwSpFQ4OB9OV9ZC5BJMm5+sSyA8h/g79nQD/DQLr2yURJvvY+cutgcQABwgI7AEA"
"AAEG/+7XBAsCBINLYj0C9fwWDgr4BwAHAgMEBA8D/QAK/gD9//cEA/vtCAcNCP8HAP0ABf8B9vwE/gAI+QHr+PMEDBAI7fcGBPj8CgAFBgATA/j4A/oNCwgA"
"/gMEA/339wEG/AP5DAgOAAECBhcKDgH84QHuDgr44P8WDg0F9BYANBMG5P762/zv/wYs/gjwAwoN4v7uBf3X+zs79QX6Dv8DAQEDAtyBCOcC//fwnQTmPPsA"
"+iLp/xb6CQcV9ff+/wwEBfwD+xYSEv8JAxPz/gYT/vMTDesE//X7/Pj2AvkBCAH/BfIIDvUM/wQBBeoQ9gf+/PTz/Pv19AID/QIDE/kE/fwF+QT9+v/xBQP5"
"Ag/7/P7z8v4e1uT1CeQDFAHq+sj06f7yCOjwCAfw9A/4+xz3+hb0/xHq3zX2ERoXCAcOAqEdS9MEAwMDBPHvgTL4AvHbu5081xjgDR0UA9zH3gn/9twTAAH7"
"1vfz7OQh8AUbrRXEH8IIDgb36AIOCfsVB/EEHzYzDwASCurdDBzL/+4L7xsT/Q/12BYR89EZz/wECOsZvhUMFAv9KRINFhLi8+IF+Pbe9eMG7+z+0SsRGkD2"
"/yTvDjkMDxrhIfjo+x7kLuYBAAUJFyIa6s8mq+z7xvr+It8EgSTzEw0QCw0HGy9e+Oj/DakD+TwAAwsG/vkF//v6BAT8AP39BfYM/QcCCQYG//n1B+wO0v4K"
"+QIFBQP8IfkAAP4FB/sF/Pj2AQL9+An+BP0R/gQEBAEKBf72C/34AAEIBAPwEwAF9f/7//wCAgQAAAD6/AL4/PT7Ah/TOwUQ4u39/xob4xYI3/MF/f7w7u0M"
"+PTr+vbs+Qv96wzkGPAZ/wPw7ur2uDE18fHx8dYY9n89Cv8JVJ53PP8C9h0W+gIQKQo3EtHlFgrxGDAB4yAU9BX2HPYb6SkKH9kaI+30GuoDz/ECJ1YcDy0d"
"HdZR/hAIBdIXBM0O4yE+JC75EBPmBRAK5Pjm8Rru/fkIPPDr0ADO8xsABEXzzyLZ9f7sQwMXvCP9K3/gJtkIyx4ka8rxB93zMs4NEcYnJwwJ3TFsPzgyFg5e"
"5cMLOg3jPOIEAf39bx0E3iwY+D8HB1I9/AIDFgT9AP/4//YC+v72Bgn79vcS/PoUDwcE6gD8AfD6Avj29AYB/f8GAP/6Cgz9Av8H9QEJ//QEAgP//wL6/wMC"
"CwYA9vsO/vkDAwECAg/+/QX8Af309gHz/f8B/fj+AvoJCf757hMCCgYTBxYLJw//B/X6/O0D+BTxDvsC/wIBCAsQ/PkR/QD99u4KEPsEgfgIEQcGBgYJACmu"
"De/898u8djvx/AEh5AMQCv8EBAn+9/X2+wMBCP36AvPxAvwZCAD4Hf0GBPgABwD3Eg7/AgTxAP0iDv0I9wDk+AsV3vD+8wT7DgH0BgcEGRH8Bfjs8wQGBAH5"
"9w4I+vsFDezwDf8BBQY1SgcaAFkgGP4gExlrJxgSZBATDGIjHwkwKWYhQSwSNTUxWwxnOTZUME0ZMAj/Qn8fviMV7/n+++QLAOP98f70PVECO+7iI+399Ln6"
"LgcEDg8C0vLlGPzp4O3X7P8CvLzfGgriIqEf2u4MBb4IH+/3D/QSwjHE2jfMyNziH/sm6dH9wyjrBzrA18zx79HuygH6I+42GcP2GpjM6M9MHPzZ+Q3/9+2o"
"4ADhgczU2L7mpr/RmOSfjq/l173Piam4v9W6v77s5KW8hZCkrdXzqpa4w8q8scuy3+Q7KMntI+luzvI578uSkFU8IQAi7Aow/Nfk/A747QGr/hPlAvMG9gX0"
"9fvfDgr3FqLh7vcO8evU9yIMBQr1+fL6KvcB6PHt+voICQsGHwo82//zHO7VD/H5se/99e8i3foHBPYI9A8HArEC7kIABxAY+gbTEdnsl7aBJbXmMcS74B/i"
"CpIb/ObuBf8W6Rz/uf38MAfSHS2qIbAUDBXG1hAfPcv0AAkKDwz97ezy6PcNARjZTT0BAwT+AQb3AgUIAP/+/gUAAf0A/QUACAr++gL9+AkCBP8CAQL3APwF"
"Av3/AgH7AwMH+/4LBQf8/PsDCAAFBAED+wAGAgUDAP78+wAAAQEGAAAB9wH/Af397gEA+QABBP0BBAf++P0LAQT4Av8G/PUH/v7/D/z67AP+KfwDCv/w///8"
"/wUIBgYSAwAWAvjR/f8bgQ7tAgICAirnzZUH8wMQiY7+PAj39PULAv7pAAf0BvUE+fvzBfYDAPIDCPwACf8UGA4P/gH4BRAC//sK//X2/vr7DwwN+RH8BgoG"
"9/z1/foI6wYA+OP4BPn+BQgM/PD/7vcDAAX4DvwBCfr0+fAA/wkC8v4QAP0A9tEo4QoG0esRCOg18BD3HRv6/w4qBvbyBdUKCQsQERTt7QDp8un8AccTAyaE"
"xSQAAQMB1gqRf+/6/BjDmN89AAH+CAcBBfz/+QP+Av/6AgAF+gf3AvwC/wEGCf4H/gMDAQQG+wP6/fgB//wD9wD8/f/4Bvj8+Qb8/P79AgUHBP77/wEG/fX9"
"AwEHBQL2/AsE+wb7AQH/CAgGAv4B+wT//fr7//8JBQnZBQUHAvz5BfH//8AKB+76/PT77gYA7/0A/fr5/gMECQMAH/j41/sDgQcI6v//AP/0BQMIA/z4AqJR"
"4TwB6PTu5OXODNT7EvX4AgkU5cb88wYRBQv1B/cHDvMQy/zM3dQEzRLxCwMA7wAXJg0j8iMF9QP47QAe9gIaEAz99u7y/P0T/v7iBfwZ/hD9BO38Dgr5B/Tr"
"7wX3Av/9/Rj0Nw0IwwfNyvTj3BoV8QoWf/v5FBwYuBr5pB33/AsaDwMMEA0ABgP1x/XTA/+/8Awc+PQNDQwMDO8A/Dj9CRIHwxemPgP/AAEAAAAA/gEAAAAA"
"AgD///8A/v/+/////gMAAQADAAECAv8AAf8A/wD+AAD+//4B/wD/AQABAAEBAQD/Af8AAP7/AAH//wEAAAEAAQD9//8BAgICAQIBAP8B/wAB/wH//gEA//z/"
"/wH9AAH9/gAD/QD4BAP+/gEAAv8DAf//AQIB///+AQD/AQIC/vj/AYH/AgAAAAEB/QIBAwEBAP9tz60+AwD//gAAAAH/AQACAv8A/QEBAQEA/wAC//7//wH/"
"/wL9AAIBAAABAQAB///9AAEAAP///gAAAAAAAQH//gAAAP8AAQH+/wD//wAAAQABAAABAP4AAgACAAEAAAEB/wAAAAEAAv8AAv/+Af///v79Awb9APsBAgP/"
"AgQAAgEBAAABAgD/////AAICAwIDAQEBgf8CAAAAAAD9+/z1A/4AAILCbzqt1QvmjvHrlUABi8OQxuzJB5sixvQKitPU2AgDuQqK5/K9tcsE6bT9MfYQ388Z"
"y9osyMTejKiqEOPmphuXuJv8msZIFor6zxD73g/GuePQ1h0nFx+OpowLgesKGbQUA+jqG86bsIkP55zsFgAC7YnD3x233h6i8t79mLzfABsD2b0Xo+up1ZLr"
"8BuUsBC8zLAVk6X54qNbDM4c88bfxyHs67BOPQH/+wj8Agj7BAj4+QoDFgcF7P0B+wEIAP0FCQ8ABgP8Agf7/wEIC/b+9/ILA+b2/QH8BPgABPv+Af8CAQT8"
"Af///wQAAf/+AwH//v///wH8AQIAAwD+AP/9AAAAAf4C/Pz/BQLxDPsC6PgZBwH17t8C/APnBQz+9gP+AvwAAe/+Af4B+/4ACfcBCf8G/QUJATr9wB3+///+"
"HvWBBez7AApwSRg9//sCFgn9Cvr9AwX8Agv4CRH3BPz/+vzx+wQH8/MaBQj8DPYDBBDxAf8J+v7/BAAF9gEF/AD6+gL3/gv78gH7/gMC/v4FAvz1CAL9/Pr5"
"/wcAAgH+AP7+/AECAQEACgX8EwXsBf4j9glXBv0kB9b8FcUUBNj5/zAx7/30ERAFGAgC+gvv8RMm/QT+2PT8Ifv7gZEw+/7+//8Lt/IcKe359OHfcToHjUnY"
"0BQExQcKtyIvkfnOx7XvQAmbKeOWvvXGr7uBuQvk+aC9MwHmVvibnO/G6wkC+SHxprz3Ot4iMpwWoyey2w4YpN4MHkjCzfru1ScPFtumn6rV7a4AFRlKuLDq"
"7O3foK0E6NSrqRUiyMznIQe/HBPYzZ2TBqeWig+dhRQTFLKPmpXUDYz7ipXUoYKf1RrxCMP7L8ECJcntPMnlJv/lJPCAOr3Q5Mv93+0bHfQU6gOluQrDE7v2"
"ldnAxFk+g63P+NuSFcil6d/j2pJcmLkiCcGxP5222eTZnazSpumR7Mn4xZrtmwul/xPQ76MzHxSGDMzKHvjhwRrVSf4U9AyswZvJkeOs5QSPgaUj2KSmuf8D"
"uwWh6hz6v875oJoB76q/8A0S+My/yfqpD923/uoXLOL/8gmN3gTXi882Oi/kG8PaIb2nQIg9+wIB/gAB//4DA//+AQMAAgAAAP0GAPsA/w4E/PoH/QwFAQD+"
"/wL/Av37AQAE/gAEBAIABAP+AP7+AAIA/gL//wAB/gQB/f////z+BAH8BgQAAAH8Af8B/gUBAQD//gADBP0AAf0C8Q0FAQf/BvoMBAT+/f33AwL//fb3/Pz/"
"AP8A/P4D/PoABQcH9v73FwL7gcgTBQEBAQIE8fKOEPz/+9exxDoT88wgFq7oCgYKLv02tMqw8+sVFfQNwBbDAcsV7+zjKd/s87DHPQi9/Ce/8Qca/w3jG+/x"
"0BUEz+PgxALPFQzHGgPR6cvC5R2llCEV59nUE73JFRLb6a8DzK9IDfEUFwbt19z0y8Pk956Bu47xvPbOgYc0ALmo5BPMsv8L1jeR/w6tBOKYkuK13sLrnKeq"
"6cbiCOL7vsT87crApPf2yBHTVyQDPQcR9gv4+/Du9P/z/QX99AoXCCTuBxcA5/cKCfkSNSEH/PsJ8g/09wjs7xPzAPjzCfX6BfIW8f3+D+8D+fMBAPYPBhEA"
"/A/1/g8K/hD8/wUJAvb4Fgf6A/T+Axf8//sM2vfl+/z4Kyyk8goLSPzr/yio2PmBMcbv1wAP+fDs894DCAwK1fsOHDEiEtwU59n+/hMNCPQCAQEA7AX/WQDi"
"6A63hos9BQsFFgAEAwYE9P7+9gQB/v0C9fkI/AT77vsM+/oJ7gsDA/8F/QEH/Pv+/QMCAvsB+v4E9gcFBQT7AQD8BQMDBv0HAQH69Pv5/v0JB/75DvkE/gEG"
"BP8JAw0A/P4D/QcO/gf2/PP18fMTEPPtA+vyD/X8/ub5FwAGBwb3/wgCAf4C/fv2/fjx5f0DAAIB7/z8geAGCQABAQAA5wUlCRUBAEbewj4BAAEAAQEAAP8A"
"AAIBAP/9AQH/AP7/AAD/Af8BAQAAA/wAAQAAAQABAAAA//sBAP//AAEAAQAAAAAAAQAAAAAAAAABAAAA/wAAAAEAAAAAAAAAAAABAAEAAAAAAQAAAAEBAQEB"
"/////vwB/wEA//0ABf0A+wIDAf4BAgIAAQEBAAECAf//AAABAQECAgMAAAGBAAMAAAAAAP//9vcCAgH//SmYPPgD7BX48vcA/Bb5/esOF/kR6SYAAAL3B/MF"
"9CcX6RPvAvv93vL+/AEd8vP5+fL6DfYCBfnoEOL+ChL1EQce/f//4NkDCgAbAAn/BgD39etG/fv/+wv6/wPs/AcJ/QAR2vri6g0EGcLuE9jmDd76vQHxEfT2"
"69K+APcuARMBAuns+PgFD/TKGxj7EOTuBboK8hrkoUX9+vz7+GXkf/Py+Wa2zGo9/wj35/sBAgMFCAED/gH6AgEI///3+woAAf37Av8B/AQBBwj9+wcECwoG"
"AfsBB/kLBgD/8QH4Av8A/gkCDP76Av4A/AYC/wIB/f4A+P30+gf69f0C/AH6BQ0BAwD+DwEGGArsEQ0gU9539fEB8r4FFvQR9//oEnEM+wHuPf4SOAgH3u7x"
"6gMT/vsGGQQPf/7yDvr1/AEAAQL1/Yfw9QIAAIn3ST31BAAL/gP4BfoEAf79/wb//f0I+gMF/P4JAAH8AQ/7+wDy+gQa9wsG+AsAAv8AEPQS/gTyAQX7AP77"
"+vwD+wL/+QINBAH+Bfbx5gIGAfIBCf4DCvjv/fwCAfIGAP3/9/4I/fcC/f8J2yINB+kDAAjvE+775xIP/+0G9/zzDgr0/QgLAgDvB/jr+QAfGvbe+QnXgQLw"
"BwgHBxvoAcf7DPr/lwRqPf/+AAAAAfz+/gL/AQj+//0A+v3+AP4D/f4BAAIA+P/z/v/7//3/BAMEAAD8/v/8/xH5/fsC/AMH+v4AAP0DDgMFBQMA/PoJ/wX9"
"/wX7Av0DBgAE5PsE+gAIAQH+BP/8/gH+9Qn8BO7u9wAFBfr19AsL+wQGAwUEBf8YAQQDA/b++Q397v78/gDxAfwN9/YF/gUFAoEEBAQEBMQA+Pn8HCTcYi4/"
"d4navRvFv71hyXA+T5IOvQgHkD59/4Y+Rq41Pxt1uL198qK+pOeWvbG5ej76WvS+4tqdvamYaLwPSmM/eCLnPq0Rvr3arE8/QT3MPV67ub2blqy9VDrxvjqd"
"z70vyOO+fpF+P4JLkL4y/Ne+u3ZMPuUfFj7qCII+UDodP1I+ND8DYSc/emuIvrajQT82/uU9bzDrPT2omL8vnH0/p8EqP40SsT6EUpK9xPoOPF/VwzyGU9e9"
"Mk+PvsY7Mj8hjwI/HDqpPkgtYb1/MOq+BVWYvt+Ayr36Tji9+WAIvsWuBb42gK89woEuO8ExCj+voi+/xNYMPj/t0j4/gIK+V5wQPEjEAdf97OW0BdgCBVz9"
"nsHh/tTQ/ws0/zbLOzgW4yTh4+y/5tPfRxzP9QGQudwkKicpAK4/+v6B/yMoQq/bvKjj7L7Dj/4DPRbrBiPfM0kDzPL3/AHYCZL0EBTfAgQ0IxMoGPMIIO8Q"
"//8CtCn2BAruFUgMM4EfBtsiljz+9/DsQwIb17oL5QwyBQxv5fjzuu7Al/IHKe/rDwT16vzLBBwXKPuB+O7M9+EK9PwRAvk8/RQJA9MwCr0LGADlFweB/LMM"
"FwpJ5iS0Bh4F/+cD2vv49/6qIiwJIi0Q2NquKhP/Df+bPADk/OBA8X8ExN4OExX4Lijs2gAw28jF9QgL8g4Q8gz5BfXtGBEE70/75jILFOYX5vMijjwG5xIm"
"MvzrYH/PHBsW3iTLm/S/Vdo75grtmQubCQ7nDAvvCioECvvOw9kE+R8j/+QLw5w8EO/FJjgW3AsP9bjPKBYvy67MzQFcAYHpE5oOAv3hKRD3wv3o2hgE9Obs"
"89kawgvuaozIPO74BBo1s8T8GOj2LfXrFOLr7f/68vGBA//WAdcF+v8J+wEhCPvk7voI663nIAAK/pYN1DwO9gcBLQaz0Nb74R0H/g8WHPf7+tmpgQz4GO4E"
"DOwD9P/iDgwDBvqvH/KW4uLs+fkCkpg75fM8FoH9SaICDQo777qysQnm3a0CGPyO/e0J9tfg0vzTF/jl0DgLFUfyZAf49hjp6ulnPPbmBut/3dwOIPL//wgP"
"Jy/s6+gp6vDW7vPp9/oO7hX8AxPnLA8FBr3w4u8HEhL56QxBlT38/vv+Cu+BCxcL5x31Bg3iBAMN7O8XpAH84gH5/AILBgMGB/3z8gkqBgHlAf8B/wPBP5U8"
"/gwkEIEc+pOu6xz8GwOxKu0pEAZC9+zOC1YkA9AmxRUEz+2NGDTzVzERFtHCNygLDjS9OruN6/ChydPnK96lLgI/l5w4EO+m3TW97vqyGMbxLJ877arl+juJ"
"JJkz3R+MP7ifgXn22zrR9aDK2UjrG8f1rJgi2xy0geWhD6qL6SCZx6kb8yXoGwQOGyfg054yNL8pCjW7wQhaLVc84t3L8ju4rgnV5dTHCPMbCN3rzALKDIH9"
"9N7o8gbZ0t/g+O78+/3flMLVw9LrIubvth+lOugVweiH1qXXrUjAvC+YFqTeyPUbVyXarh3Irg2Nz+WvWR+BxgO/oNgxrPyZKZxVoE0yCT33+AjnJxhO+4H8"
"Musc/+Ie8tzl/f/vKCjwKP73DQvIAf4Q6NAoFArbFf415vvZBvqm2J461QSBJbDxq/Js9F2n3ZTSPQBq9rzU6Jah8+wD27z1CAAvmuPLsQaNjV5c6AcHVEIh"
"2JIlPgIAAgEB6PoD5xEB/QEBBAGR7gGz7gTpgesG/gHzAsb/AAH/BiwC8wT/9ATT5+kSAlonmjoqyf63ocoDkTm6ljgjhK1KPldg1sD71Qr+4x+/I+/dmpKB"
"xohZG+kOjfj1gU2P+6OIRwU9AfYDBh/hQPujBO8XBujx8B79B938CyMf+SYBAP8B3///AQaBEQHnAwDmD+LlCxoH9pOoPPwD/f2BCEMdEMAT3AADNAkJ/RFi"
"/v69/CU4JyMA+Q8GEe3uMwnd9RgK8NUe/QQhBpaYizqluU9N3Qqst74kjN1cLsJKQ6mmdbXMigGUHvWuLB2ZlR+04iTwrNKunwSB6AMdrXvE7aw8+fz+AinY"
"QwSSEOf4BdPK7iThF+r6FzIa/fP8AgUC4xP6+w2BD/vTAvjuQv3Z9gcTrnuxO/f3IR27Dyqk0hvUDPnG0rTs58+BHPXtveHlHtzn4+720xL74doXGfNG8Svu"
"+OkY7aliWD0M7gcK/vIqF6kTCw0T2fDulfIHke4QCJTuHAP3CBOB/gn6CqJDFhoS/vr22tTBTgs5z0o8+errEj3FnhHy0en+Eu0IE+Lr2/jP7JYB7db9ywn6"
"2Ovo5vcB9NXu+e7lgc/77uXqiqWAPA7xAftECzu6gQkVwT0FIFnm+wHT/vAY/P465ywfBQ7sIx7nLCQm+s8J3jPo8Pfq/fvhiDrwxQX5ituflcoCXPZBVupi"
"Q1eP4uOJiMnLXSb9lrDm4nfXM7imgVeXkfGqFpIY8Eo2k6Q6OQzcANmzJ+bvyqAJPeLftK2q1w8wLRvJFtNKHkc2nNPOnOHt5vw5y9ZJOulQ7oGdurDVPQPz"
"AwEF5gMSxgoHAgjxAwyHxQOi5QjkgeUB//4GB5b+A/sE7DIK/QoA+/bT2tItA1k0sjrZ1PEC7aesSyawIuSUxUKG8TDVpf24XvY7NCy1ou6mxqOBAqyJD8sQ"
"8Ny9EbiejwzO4Tg9CvgV8xsYgeL68wsDBwgGIBUF6/PcDMv//STl9AX+8/4I9gn8//8Bugj5jvgF1f75V0kHPRPhEIEYCxT6IP+16gIMLeKuF9/zIPnpIf3s"
"8+T88QH1AesZ+v325hbh9/oBBzD8+Zfkkzz+tRfsKwV/CQfDxw7j9i/TJNflNvav5hcBI2cYCBAWCuPk7hfVESL/CM0Y/LzzBuzkr6c6rM4H973bFOaqEqjU"
"I7HZB0ckx1gsu4abpKLHvjMKpfPQ28vIMIEqMo+Zvrn0KvMv6JymOsT8Sc7PEaImytn1qJsGMbW7n/Ut54VHqyQSga++yQsYz/i0I76U8OjfmLnGvhnfK082"
"bzwY7h/mgTVDASMIB/ECDC/yRiQT8QxAu/8fGgAa/v8YHAjuBTAC9xq9CgZCKxRLGBRX+L06pYEg4qPPAZLuKKG83fumr6b1srO5uLPUCc+mPRWrBqqjxtCs"
"Gd7CzZaQFt7FHTU3rqU4PODf0PpHp5gD2tzJyATgGfXT5NILvxCBAPjd6vQE1tXY1fsI9f3w1rWq0MTh5Bnk47xVbjwJ8QLsf+/qBhoc8gz9AjsH+vr4DPHq"
"6PQBB//9G/4Y9QYoBCwRBATF8PfzDiQl/PnyDVQ9BPMC9hbbJQ3GEv0fF+z64Noh/eHtE/L56iEEAPYN0/oE+wWBKBPuAATnDeHW3yQCWQewOo3oCy6Qw8nC"
"ldpGF+OlpNQCJ0wHNezBJyo6l+YqmT6l4Zubmq8kgda/EfzK2TLQD11UZDz+9d7ef93oBPQQ6PISAS348w3iAvLaxQoM9PjqH94g4PMf8ScV/ALd6u4CBhAS"
"+fe2Fdg83/r6MC/eEQbr/ykBGO0u5zDh/Rfo6r8XBPvp9gPNF/nt9vT+Gi/vgffjW/wQGQP1JuEjPOfms/E9uJ3z0fPm5A75IAjK4+gHwgeBB/je9AwSz8rN"
"7vcE+fn25pXK3ufj3Uzf3AQg4jzy++YGM98TFzjJBCkI9Q0G5+0IPBPjgQv62grfBQUIBPfpCgTxDvcn7vwr4xD7CviRh2o8B/0LJX/Q5AsH9e039wtD+tHZ"
"8vHb37QPCcUC9QsFGwb7EBYbCu4D7g/nuP/2EAfpqMGjOrXfRKqthvc9nO23/7Ea9CKB7hLorf4S+MKk6AefhcmKrMJJxsbSm5wZJwbbJfQRocRyjzzt7Oo6"
"OrwlaAj3L+sc4UM0ydL9TfLBgR4Ov/QCAOUd/gk22BYMU/rQ7cA77T0JHukLICk9BPkF/hnsJvXGDOoeD/Xu0e8CBc/7DP8H7iQNBwIJ3P4DAAaBERDrAQHf"
"7eLW6R8EM5biPA72Gg/1Izy+BuA88O3U3wfm8dxG7fV/2AX1JQkL7/T8/Cz0Li4Z3RcPJCAc+iAp939rNDz/3w4ef7DbNj272z8EFFH/pcLhO8Hdn+kA4w7C"
"/uALAPQP5yv3t/b21LojDxsWD8dbOMA6QecXkc0J1tSYwaJH7CWVyKSswYG3Dt0PBrmVxSEd4pO2KDE7sr0Tv5Y+4r05+joOcgSpOiAk0++1obCxlIe8CoG4"
"la/SqzDoHZah2gghy+Q2rLY3xbwGg9OfFc0ijYYYGaUpu+qFijwK6foDf+z8BBsP8xcEDj0G+Aj3Durj6foPCPv8IAEh+AMk9ikKBw3u/fcEDBsqCAKbOdE7"
"19en2lK9p/Hd8hH/AxAgM7PX3yyy84HxAPTq/v/NvbDxyNvu7bHbwb7Ess/BStDlp1qbOj4OxQ+ELkW9Ojo6rq7mRJ9PHa++5q+s1w6BHNI09ML+37enIk7l"
"xpKxoArqmz+9w+Z0PT0G4/f6JJ0EKpsOEhIk2fYPvMj/uOAI2PrPMg4I4wyN+QoCEIE/Euj+B/jp2KLeQgMLjhk88QUa8YH8NNHYAfAW593m1AQd9Mv6FATu"
"/+368/P6Af7+8frb7A35LRn5IwLa8g30xLmpPAPJ/fMyvcEYGv8n5QP+2O6wnMEw2fDxgQDGEMwRBc8VBhkCMV4g/MEd3tqhAhYf81Y3BT3+AQP1ge7E2BDy"
"Ku7+8P/uJxgC/vEv9RH4GBf49wAODPvUDQMX8QgjDfsV9R7UCfueZ6U9BP8H1fUBgQQf+gYBAQ8UIf8K9Az8/78AA/z/7P0J+/gD8fwX/gsGCAIAyQL9GwD5"
"xhv9PPr+GN6BDCn4P+owFwUJ9/kiEgDY/Sf4A/jeFQ738AAPDeEB8B/59xUXABPzMuoWDVn1iT57c8k98gsDPt+aQb6D+kK+BU8Hv0jgBz4VYsY9/ZEBvvrp"
"jr246YE+gCHuPkMRJb5X0v+8osFEvhjkjzyC0Fq9rI7gvdfQYr4nIBy9SWnwPqMOAL2Abo+9eeq3PuIFIT2XQ+k+PK+SvXsxAz6cxzS99UkWvuUrAz4SX209"
"lVIMPHnGlr47I5y+4bRuvbjDLz3IvRC9ziB7vKdeFL5wWqM9vTURP3+oI76Rgw6+3ejyvSXgQb5cEau+yMO+PfemZD0COMi+wnoeP7OFvb7AHz2+N8u8vP4X"
"e73cO788ZvBRvKBf1L0ZVtQ+S2okvc1b775pwUM+NACXvkWnvj6S3VI8/BX4GCYbExYAFRD2/wYAAvYHpQD3+/7y/vkAFgUB6wcdQDsCAO78/hX4/hgV/xEU"
"/yL6EiUB/SgDAPUAf/Pj/tf7nj4="
;

// The trained row-major tensors remain the authoritative decoded weights.
// A one-time transpose exposes independent output channels to SIMD, without
// changing the sequence of multiply-adds within any scalar output.
alignas(64) static array<array<float,NN_WIDTH>,40> fast_input;
alignas(64) static array<array<array<float,NN_WIDTH>,9>,NN_DEPTH> fast_depth;
alignas(64) static array<array<array<float,NN_WIDTH>,NN_WIDTH>,NN_DEPTH> fast_point;
alignas(64) static array<array<float,NN_HIDDEN>,NN_WIDTH> fast_source,fast_destination,fast_global;
alignas(64) static array<array<float,NN_HIDDEN>,16> fast_action;
void prepare_fast_weights() {
    for(int c=0;c<40;++c)for(int o=0;o<NN_WIDTH;++o)fast_input[c][o]=nn_input_w[o*40+c];
    for(int b=0;b<NN_DEPTH;++b){
        for(int k=0;k<9;++k)for(int c=0;c<NN_WIDTH;++c)fast_depth[b][k][c]=nn_depth_w[b][c*9+k];
        for(int c=0;c<NN_WIDTH;++c)for(int o=0;o<NN_WIDTH;++o)fast_point[b][c][o]=nn_point_w[b][o*NN_WIDTH+c];
    }
    for(int c=0;c<NN_WIDTH;++c)for(int o=0;o<NN_HIDDEN;++o){
        fast_source[c][o]=nn_actor_w[o*NN_ACTOR_INPUT+c];
        fast_destination[c][o]=nn_actor_w[o*NN_ACTOR_INPUT+NN_WIDTH+c];
        fast_global[c][o]=nn_actor_w[o*NN_ACTOR_INPUT+2*NN_WIDTH+c];
    }
    for(int c=0;c<16;++c)for(int o=0;o<NN_HIDDEN;++o)fast_action[c][o]=nn_actor_w[o*NN_ACTOR_INPUT+3*NN_WIDTH+c];
}
template<size_t Outputs,size_t Inputs>
inline void channel_matvec(const array<array<float,Outputs>,Inputs>& weights,
                           const float* __restrict__ x,float* __restrict__ out) {
    for(size_t c=0;c<Inputs;++c) {
        const float value=x[c];const float* __restrict__ row=weights[c].data();
        // No reduction is parallelized: each output still visits c in order.
        #pragma GCC ivdep
        for(size_t o=0;o<Outputs;++o)out[o]+=row[o]*value;
    }
}

void load_nn() {
    array<int,256> lookup; lookup.fill(-1);
    const string alphabet="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    for(int i=0;i<64;++i) lookup[uint8_t(alphabet[i])]=i;
    vector<uint8_t> bytes; bytes.reserve(sizeof(nn_packed)*3/4);
    unsigned buffer=0; int bits=0;
    for(char ch:nn_packed) {
        if(ch=='=' || ch==0) break;
        const int digit=lookup[uint8_t(ch)];
        if(digit<0) throw runtime_error("bad model encoding");
        buffer=(buffer<<6)|unsigned(digit); bits+=6;
        if(bits>=8) { bits-=8; bytes.push_back(uint8_t(buffer>>bits)); }
    }
    size_t pos=0;
    auto scalar=[&]() {
        if(pos+4>bytes.size()) throw runtime_error("short model scale");
        uint32_t value=0; for(int b=0;b<4;++b)value|=uint32_t(bytes[pos++])<<(8*b);
        return bit_cast<float>(value);
    };
    auto matrix=[&](float* out,int rows,int columns) {
        for(int row=0;row<rows;++row) {
            const float scale=scalar();
            for(int col=0;col<columns;++col) {
                if(pos==bytes.size())throw runtime_error("short model row");
                const int raw=bytes[pos++];
                *out++=float(raw<128?raw:raw-256)*scale;
            }
        }
    };
    auto bias=[&](float* out,int count){for(int i=0;i<count;++i)*out++=scalar();};
    matrix(nn_input_w.data(),48,40);
    bias(nn_input_b.data(),48);
    matrix(nn_depth_w[0].data(),48,9);
    bias(nn_depth_b[0].data(),48);
    matrix(nn_point_w[0].data(),48,48);
    bias(nn_point_b[0].data(),48);
    matrix(nn_depth_w[1].data(),48,9);
    bias(nn_depth_b[1].data(),48);
    matrix(nn_point_w[1].data(),48,48);
    bias(nn_point_b[1].data(),48);
    matrix(nn_depth_w[2].data(),48,9);
    bias(nn_depth_b[2].data(),48);
    matrix(nn_point_w[2].data(),48,48);
    bias(nn_point_b[2].data(),48);
    matrix(nn_depth_w[3].data(),48,9);
    bias(nn_depth_b[3].data(),48);
    matrix(nn_point_w[3].data(),48,48);
    bias(nn_point_b[3].data(),48);
    matrix(nn_actor_w.data(),64,160);
    bias(nn_actor_b.data(),64);
    matrix(nn_actor_out_w.data(),1,64);
    bias(nn_actor_out_b.data(),1);
    matrix(nn_critic_w.data(),64,48);
    bias(nn_critic_b.data(),64);
    matrix(nn_critic_out_w.data(),1,64);
    bias(nn_critic_out_b.data(),1);
    if(pos!=bytes.size() || pos!=30800)throw runtime_error("trailing model data");
    prepare_fast_weights();
}
// 重みはこの直前に生成する。Pythonと同じ演算順で可変容量CNNを直接計算する。
struct Encoded {
    array<array<float, NN_WIDTH>, 400> cells{};
    array<float, NN_WIDTH> global{};
    float remaining = 0.f;
};

// The cache belongs to one board/search. Global E is an input at every floor:
// any homecoming MUST invalidate every layer, not just the two moved towers.
struct EncodeCache {
    array<array<array<float,NN_WIDTH>,400>,NN_DEPTH+1> layers{};
    array<uint32_t,400> bits{};
    int E=-1;
    bool valid=false;
    void invalidate() { valid=false; }
};
#ifdef LOCAL
struct IncrementalStats {
    uint64_t calls=0,full=0,home=0,incremental=0;
    array<uint64_t,NN_DEPTH+1> cells{};
    uint64_t full_cells=0;
} incremental_stats;
#endif
unique_ptr<Encoded> encode(const Input& input,const Board& board,const BoardState& state,
                           EncodeCache* retained=nullptr) {
    // The diagnostic one-shot API uses a fresh cache; production owns one per search.
    unique_ptr<EncodeCache> fresh;
    if(!retained){fresh=make_unique<EncodeCache>();retained=fresh.get();}
    auto& cache=*retained;
    const bool full=!cache.valid || cache.E!=state.E;
    array<bool,400> changed{};
    for(int p=0;p<board.cell_count;++p)changed[p]=full || cache.bits[p]!=state.bits[p];
#ifdef LOCAL
    ++incremental_stats.calls;
    incremental_stats.full+=full;
    incremental_stats.home+=cache.valid && cache.E!=state.E;
    incremental_stats.incremental+=!full;
    incremental_stats.full_cells+=board.cell_count;
#endif
    auto result=make_unique<Encoded>();
    const auto features=board_features(input,board,state);
    auto& first=cache.layers[0];
    for(int p=0;p<board.cell_count;++p)if(changed[p]) {
        first[p]=nn_input_b;
        channel_matvec(fast_input,features[flat_cell(board,p)].data(),first[p].data());
        for(float& v:first[p])v=max(0.f,v);
#ifdef LOCAL
        ++incremental_stats.cells[0];
#endif
    }
    for(int block=0;block<NN_DEPTH;++block) {
        const auto& h=cache.layers[block];
        auto& output=cache.layers[block+1];
        array<bool,400> affected{};
        // Propagate the exact graph dependency including the residual/self edge.
        for(int p=0;p<board.cell_count;++p) {
            const auto [i,j]=board.coordinates[p];
            affected[p]=changed[p];
            for(int di=-1;di<=1;++di)for(int dj=-1;dj<=1;++dj) {
                const int ni=i+di,nj=j+dj;
                if(ni<0||ni>=input.N||nj<0||nj>=input.N)continue;
                const int q=board.cell_id[ni][nj];
                if(q>=0 && changed[q])affected[p]=true;
            }
        }
        array<array<float,NN_WIDTH>,400> depth{};
        for(int p=0;p<board.cell_count;++p)if(affected[p]) {
            const auto [i,j]=board.coordinates[p];depth[p]=nn_depth_b[block];
            for(int di=-1;di<=1;++di)for(int dj=-1;dj<=1;++dj) {
                const int ni=i+di,nj=j+dj;
                if(ni<0||ni>=input.N||nj<0||nj>=input.N)continue;
                const int q=board.cell_id[ni][nj];if(q<0)continue;
                const auto& weights=fast_depth[block][(di+1)*3+dj+1];
                for(int c=0;c<NN_WIDTH;++c)depth[p][c]+=weights[c]*h[q][c];
            }
            for(float& v:depth[p])v=max(0.f,v);
        }
        for(int p=0;p<board.cell_count;++p)if(affected[p]) {
            auto residual=nn_point_b[block];
            channel_matvec(fast_point[block],depth[p].data(),residual.data());
            for(int o=0;o<NN_WIDTH;++o)output[p][o]=max(0.f,h[p][o]+residual[o]);
#ifdef LOCAL
            ++incremental_stats.cells[block+1];
#endif
        }
        changed=affected;
    }
    cache.bits=state.bits;cache.E=state.E;cache.valid=true;
    result->cells=cache.layers[NN_DEPTH];
    const auto& h=result->cells;
    // Never subtract/add changed cells into the global sum: preserve parent order.
    for(int p=0;p<board.cell_count;++p)
        for(int c=0;c<NN_WIDTH;++c)result->global[c]+=h[p][c];
    for(float& v:result->global)v/=board.cell_count;
    float raw=nn_critic_out_b[0];
    for(int o=0;o<NN_HIDDEN;++o) {
        float v=nn_critic_b[o];
        for(int c=0;c<NN_WIDTH;++c)v+=nn_critic_w[o*NN_WIDTH+c]*result->global[c];
        raw+=nn_critic_out_w[o]*max(0.f,v);
    }
    result->remaining=(raw>20.f?raw:log1p(exp(raw)))*100.f;
    return result;
}

vector<float> policy(const Board& board,const BoardState& state,const Encoded& encoded,
                     const vector<Move>& moves) {
    array<array<float,NN_HIDDEN>,400> source{},dest{};
    auto global=nn_actor_b;
    channel_matvec(fast_global,encoded.global.data(),global.data());
    array<bool,400> used_source{},used_dest{};
    for(Move m:moves){used_source[m.p()]=true;used_dest[board.ray[m.p()][m.d()][m.l()-1]]=true;}
    // Empty/non-candidate cells cannot contribute to a returned logit.
    for(int p=0;p<board.cell_count;++p) {
        if(used_source[p])channel_matvec(fast_source,encoded.cells[p].data(),source[p].data());
        if(used_dest[p])channel_matvec(fast_destination,encoded.cells[p].data(),dest[p].data());
    }
    vector<float> logits;logits.reserve(moves.size());
    for(Move m:moves) {
        const int p=m.p(),q=board.ray[p][m.d()][m.l()-1];
        const auto features=action_features(board,state,m);
        array<float,NN_HIDDEN> action{};
        channel_matvec(fast_action,features.data(),action.data());
        float logit=nn_actor_out_b[0];
        for(int o=0;o<NN_HIDDEN;++o) {
            const float v=source[p][o]+dest[q][o]+global[o]+action[o];
            logit+=nn_actor_out_w[o]*max(0.f,v);
        }
        logits.push_back(logit);
    }
    return logits;
}
struct StateHash {
    size_t operator()(const array<uint32_t,400>& state) const {
        uint64_t h=0x9e3779b97f4a7c15ULL;
        for(uint32_t v:state)h^=uint64_t(v)+0x9e3779b97f4a7c15ULL+(h<<6)+(h>>2);
        return size_t(h);
    }
};

struct SearchResult {
    vector<Move> path;
    int E=0, depth=0, inferences=0, duplicates=0;
    bool deadline=false, exhausted=false;
};

template<class Timer>
SearchResult search(const Input& input,const Board& board,const BoardState& initial,Timer& timer) {
    SearchResult result; result.E=initial.E;
    BoardState state=initial; vector<Move> path;
    auto encode_cache=make_unique<EncodeCache>();
    int64_t best_score=int64_t(initial.E)*100000;
    uint64_t rng=90003;
    for(const auto& row:input.C)for(char ch:row)rng=(rng^uint8_t(ch))*1099511628211ULL;
    if(!rng)rng=90003;
    auto uniform=[&](){rng^=rng<<13;rng^=rng>>7;rng^=rng<<17;return double(rng>>11)*0x1p-53;};
    unordered_set<array<uint32_t,400>,StateHash> visited;
#ifndef V090_STOCHASTIC
    visited.reserve(4096); visited.insert(state.bits);
#endif
    for(int depth=0;depth<2048 && state.E>0;++depth) {
        if(!timer.step()){result.deadline=true;break;}
        auto moves=legal_moves(board,state);
        if(moves.empty()){result.exhausted=true;break;}
        const auto encoded=encode(input,board,state,encode_cache.get()); ++result.inferences;
        const auto logits=policy(board,state,*encoded,moves);
        if(!timer.step()){result.deadline=true;break;}
        int chosen=-1; BoardState next;
#ifdef V090_STOCHASTIC
        const float maximum=*max_element(logits.begin(),logits.end());
        double total=0;
        for(float value:logits)total+=exp(double(value-maximum));
        const double pick=uniform()*total; double cumulative=0;
        for(size_t i=0;i<moves.size();++i){
            cumulative+=exp(double(logits[i]-maximum));
            if(pick<cumulative || i+1==moves.size()){chosen=int(i);break;}
        }
        next=state; next.apply(board,moves[chosen]);
#else
        (void)uniform;
        vector<int> order(moves.size());iota(order.begin(),order.end(),0);
        stable_sort(order.begin(),order.end(),[&](int a,int b){return logits[a]>logits[b];});
        for(int index:order){
            next=state;next.apply(board,moves[index]);
            if(visited.contains(next.bits)){++result.duplicates;continue;}
            chosen=index;visited.insert(next.bits);break;
        }
        if(chosen<0){result.exhausted=true;break;}
#endif
        path.push_back(moves[chosen]);state=next;result.depth=int(path.size());
        const int64_t score=int64_t(state.E)*100000+path.size();
        if(score<best_score){best_score=score;result.E=state.E;result.path=path;}
    }
    return result;
}

#ifdef V090_DIAGNOSTIC
void dump_inference(const Input& input,const Board& board,const BoardState& state) {
    const auto started=chrono::steady_clock::now();
    const auto features=board_features(input,board,state);const auto moves=legal_moves(board,state);
    const auto encoded=encode(input,board,state);const auto logits=policy(board,state,*encoded,moves);
    const double elapsed=chrono::duration<double>(chrono::steady_clock::now()-started).count();
    cout<<setprecision(9)<<"{\"inference_seconds\":"<<elapsed<<",\"value\":"<<encoded->remaining<<",\"x\":[";
    for(int f=0;f<400;++f)for(int c=0;c<40;++c){if(f||c)cout<<',';cout<<features[f][c];}
    cout<<"],\"codes\":[";
    for(size_t n=0;n<moves.size();++n){if(n)cout<<',';cout<<action_code(board,moves[n]);}
    cout<<"],\"features\":[";
    for(size_t n=0;n<moves.size();++n){const auto x=action_features(board,state,moves[n]);
        for(int c=0;c<16;++c){if(n||c)cout<<',';cout<<x[c];}}
    cout<<"],\"logits\":[";
    for(size_t n=0;n<logits.size();++n){if(n)cout<<',';cout<<logits[n];}
    cout<<"]}\n";
}
#endif

} // namespace nn
#if defined(__GNUC__) && !defined(__clang__)
#pragma GCC pop_options
#endif
// v214_local_color_runs.cpp
// v214: 途中の1塔・2塔の再構築だけ、選択範囲の同色連続部分を塊単位で再挿入する。
// 塊はこの再挿入中だけ保持し、同色の背景を足場に残して離れることを許す。
// 盤面の32 bit表現、初期構築、通常近傍、時間配分と終了処理はv210を継承する。
// 探索の実数演算の順序を保つためfast-mathは使わない。
#if defined(__GNUC__) && !defined(__clang__)
#pragma GCC optimize("O3,unroll-loops,omit-frame-pointer")
#if defined(__x86_64__) && !defined(AHC072_PORTABLE)
#pragma GCC target("avx2,bmi,bmi2,lzcnt,popcnt")
#endif
#endif
#include <bits/stdc++.h>
using namespace std;

// v073〜v075の保存結果から、ケースごとの短縮率を重視して選んだ設定。
constexpr double repair_weight = 0.83;
constexpr double removal_size_exponent = 0.95;
constexpr double priority_noise_amplitude = 0.20;
constexpr double lns_start_temperature = 0.70;
constexpr double lns_end_temperature = 0.12;
constexpr int dependency_interval = 3;
constexpr double regular_cooldown_fraction = 0.75;
static_assert(lns_end_temperature < lns_start_temperature);

// LOCALでは時間を補正し、集計を有効にする。
#ifdef LOCAL
constexpr double JUDGE_TIME_LIMIT_SEC = 1.90;
constexpr double LOCAL_TIME_RATIO = 1.90 / 1.930; // Match the fixed cloud v311 LOCAL budget only.
constexpr double PROGRAM_TIME_LIMIT_SEC = JUDGE_TIME_LIMIT_SEC * LOCAL_TIME_RATIO;
struct TraceStats {
    map<string, int64_t> counts;
    map<string, double> times_ms;
    void count_by(const string& key, int64_t delta) { counts[key] += delta; }
    void add_time_ms(const string& key, double ms) { times_ms[key] += ms; }
    void summary() const {
        for (const auto& [key, value] : counts)
            cerr << "[summary.count] " << key << '=' << value << '\n';
        const auto flags = cerr.flags();
        const auto precision = cerr.precision();
        cerr << fixed << setprecision(3);
        for (const auto& [key, value] : times_ms)
            cerr << "[summary.time_ms] " << key << '=' << value << '\n';
        cerr.flags(flags); cerr.precision(precision);
    }
};
template<class F>
decltype(auto) local_time_impl(TraceStats& trace, const string& key, F&& body) {
    const auto start = chrono::steady_clock::now();
    if constexpr (is_void_v<invoke_result_t<F>>) {
        invoke(forward<F>(body));
        trace.add_time_ms(key, chrono::duration<double, milli>(chrono::steady_clock::now() - start).count());
    } else {
        auto result = invoke(forward<F>(body));
        trace.add_time_ms(key, chrono::duration<double, milli>(chrono::steady_clock::now() - start).count());
        return result;
    }
}
#define LOCAL_NOTE(...) __VA_ARGS__
#define LOCAL_ONLY(...) do { __VA_ARGS__; } while (false)
#define LOCAL_TIME(trace, key, ...) local_time_impl((trace), (key), (__VA_ARGS__))
// 既存版と同じLOCAL時間配分で比較する。非LOCALは持ち込み版の式を保持する。
#define LOCAL_SECONDS(value) (PROGRAM_TIME_LIMIT_SEC * ((value) / JUDGE_TIME_LIMIT_SEC))
#else
constexpr double JUDGE_TIME_LIMIT_SEC = 1.90;
constexpr double LOCAL_TIME_RATIO = 1.0;
constexpr double PROGRAM_TIME_LIMIT_SEC = JUDGE_TIME_LIMIT_SEC;
#define LOCAL_NOTE(...)
#define LOCAL_ONLY(...) do { } while (false)
#define LOCAL_TIME(trace, key, ...) (__VA_ARGS__)()
#define LOCAL_SECONDS(value) (PROGRAM_TIME_LIMIT_SEC * ((value) / 1.930) * (1.880 / 1.900))
#endif

#ifdef LOCAL
TraceStats trace;
// 頻出処理では整数を加算し、文字列への変換と出力は探索後に行う。
int64_t local_event_layers = 0, local_event_reopens = 0;
int64_t local_single_insert_calls = 0, local_packet_insert_calls = 0;
int64_t local_run_flexible_calls=0,local_run_paired_calls=0;
int64_t local_run_reinsert_calls=0,local_run_reinserted_slimes=0;
int64_t local_run_multi_calls=0,local_run_multi_completed=0;
int64_t local_run_completed=0,local_run_completed_slimes=0;
int64_t local_shortcut_support_states = 0, local_backward_accepted = 0;
struct DependencyStats {
    int64_t selected=0, generated=0, multistep=0, added=0, cooldown=0;
    int64_t attempts=0, extracted=0, extract_failed=0, insert_failed=0, completed=0;
    int64_t accepted=0, improvements=0, saved=0, current_improvements=0, current_saved=0;
    int64_t gross_removed=0, net_removed=0, repaired_jumps=0, repair_extra_commands=0;
    double seconds=0;
    void summary() const {
        auto count=[&](const char* key,int64_t value){trace.count_by(string("lns_dependency_")+key,value);};
        count("selected",selected);count("generated",generated);count("multistep",multistep);
        count("added",added);count("cooldown",cooldown);count("attempts",attempts);
        count("extracted",extracted);count("extract_failed",extract_failed);
        count("insert_failed",insert_failed);count("completed",completed);count("accepted",accepted);
        count("improvements",improvements);count("saved",saved);
        count("current_improvements",current_improvements);count("current_saved",current_saved);
        count("gross_removed",gross_removed);count("net_removed",net_removed);
        count("repaired_jumps",repaired_jumps);count("repair_extra_commands",repair_extra_commands);
        trace.add_time_ms("lns_dependency",seconds*1000.0);
    }
} local_dependency;
// 開始時刻の追加を、束のまま・個体へ分解・2塔の再構築に分けて集計する。
struct LateStartStats {
    int64_t builds=0,primary=0,generated=0,split_generated=0,delay_sum=0;
    array<int64_t,3> attempts{},completed{},accepted{},improvements{},saved{};
    array<int64_t,3> current_improvements{},current_saved{};
    array<double,3> seconds{};
    void summary() const {
        auto count=[&](const string& key,int64_t value){trace.count_by("lns_late_start_"+key,value);};
        count("builds",builds);count("primary",primary);count("generated",generated);
        count("split_generated",split_generated);count("delay_sum",delay_sum);
        const char* kinds[]={"packet","flexible","paired"};
        for(int i=0;i<3;i++) {
            const string prefix=string(kinds[i])+"_";
            count(prefix+"attempts",attempts[i]);count(prefix+"completed",completed[i]);
            count(prefix+"accepted",accepted[i]);count(prefix+"improvements",improvements[i]);
            count(prefix+"saved",saved[i]);count(prefix+"current_improvements",current_improvements[i]);
            count(prefix+"current_saved",current_saved[i]);
            trace.add_time_ms("lns_late_start_"+string(kinds[i]),seconds[i]*1000.0);
        }
    }
} local_late_start;
bool local_late_paired_anchor=false;
struct TwoOrderStats {
    int64_t attempts=0,completed=0,alternate_selected=0,rescued=0,shorter=0,raw_saved=0;
    int64_t accepted=0,improvements=0,saved=0;
    int64_t alternate_accepted=0,alternate_improvements=0,alternate_saved=0;
    array<int64_t,5> sizes{};
    array<int64_t,2> started{},finished{},failed{},insert_calls{};
    array<double,2> seconds{};
    void summary() const {
        auto count=[&](const string& key,int64_t value){trace.count_by("lns_two_order_"+key,value);};
        count("attempts",attempts);count("completed",completed);
        count("alternate_selected",alternate_selected);count("rescued",rescued);
        count("shorter",shorter);count("raw_saved",raw_saved);
        count("accepted",accepted);count("improvements",improvements);count("saved",saved);
        count("alternate_accepted",alternate_accepted);
        count("alternate_improvements",alternate_improvements);count("alternate_saved",alternate_saved);
        for(int n=2;n<=4;n++)count("size_"+to_string(n),sizes[n]);
        for(int branch=0;branch<2;branch++) {
            const string prefix=branch?"alternate_":"primary_";
            count(prefix+"started",started[branch]);count(prefix+"finished",finished[branch]);
            count(prefix+"failed",failed[branch]);count(prefix+"insert_calls",insert_calls[branch]);
            trace.add_time_ms("lns_two_order_"+prefix+"search",seconds[branch]*1000.0);
        }
    }
} local_two_order;
bool local_two_order_alternate=false;
// 失敗と期限到達による中断も、追加順序の費用へ含める。
struct TwoOrderTimer {
    int branch;
    chrono::steady_clock::time_point begin=chrono::steady_clock::now();
    explicit TwoOrderTimer(int index):branch(index){}
    ~TwoOrderTimer() {
        local_two_order.seconds[branch]+=chrono::duration<double>(chrono::steady_clock::now()-begin).count();
    }
};
// 不採用と期限到達による中断も、依存拡張の費用へ含める。
struct DependencyTimer {
    bool active;
    chrono::steady_clock::time_point begin;
    explicit DependencyTimer(bool enabled):active(enabled) {
        if(active)begin=chrono::steady_clock::now();
    }
    ~DependencyTimer() {
        if(active)local_dependency.seconds+=chrono::duration<double>(chrono::steady_clock::now()-begin).count();
    }
};
#endif

// 塔は下から4 bitずつ色c+1を詰める。空は0。色符号は1..K、巣なしは0。
using TowerBits = uint32_t;
constexpr int max_cells = 400, infinite_cost = 30000;
// 盤面は床数分の領域を借りる。2塔の再構築3枚と再挿入1枚で最大4枚を同時に使う。
struct StatePool {
    static constexpr int slots = 4;
    unique_ptr<TowerBits[]> storage;
    TowerBits* free_slot[slots];
    size_t bytes = 0;
    int free_count = 0;
    void prepare(int floors) {
        storage.reset(new TowerBits[size_t(floors) * slots]);
        bytes = size_t(floors) * sizeof(TowerBits);
        free_count = slots;
        for(int i=0;i<slots;i++)free_slot[i]=storage.get()+size_t(i)*floors;
    }
    TowerBits* take() { return free_slot[--free_count]; }
    void give(TowerBits* cell) { free_slot[free_count++]=cell; }
} state_pool;

class State {
    TowerBits* cell;
public:
    // 引数なしでは領域だけ取得する。利用前にIdentityState::wordsで全床を書き込む。
    State():cell(state_pool.take()) {}
    State(const array<TowerBits,max_cells>& other):State() {
        memcpy(cell,other.data(),state_pool.bytes);
    }
    State(const State& other):State() {
        memcpy(cell,other.cell,state_pool.bytes);
    }
    State(State&& other) noexcept:cell(exchange(other.cell,nullptr)) {}
    ~State() { if(cell)state_pool.give(cell); }
    State& operator=(const State& other) {
        if(this!=&other) {
            if(!cell)cell=state_pool.take();
            memcpy(cell,other.cell,state_pool.bytes);
        }
        return *this;
    }
    State& operator=(const array<TowerBits,max_cells>& other) {
        if(!cell)cell=state_pool.take();
        memcpy(cell,other.data(),state_pool.bytes);
        return *this;
    }
    State& operator=(State&& other) noexcept {
        swap(cell,other.cell);
        return *this;
    }
    TowerBits& operator[](int p) { return cell[p]; }
    const TowerBits& operator[](int p) const { return cell[p]; }
    bool operator==(const State& other) const {
        return memcmp(cell,other.cell,state_pool.bytes)==0;
    }
};

struct Deadline {};
// 非LOCALは起動時、LOCALはmain先頭から計時する。各照会で時計を読む。
struct TimeKeeper {
    double time_limit_sec = LOCAL_SECONDS(1.89);
#ifdef LOCAL
    chrono::steady_clock::time_point start_;
#else
    chrono::steady_clock::time_point start_ = chrono::steady_clock::now();
#endif
    double exact_elapsed_sec() const {
        return chrono::duration<double>(chrono::steady_clock::now()-start_).count();
    }
    void check() const { if (exact_elapsed_sec() > time_limit_sec) throw Deadline(); }
} time_keeper;
struct Rng {
    uint64_t x = 0x123456789abcdefULL;
    uint64_t next() { x ^= x<<7; x ^= x>>9; return x; }
    // 64 bit積の上位を使い、整数除算なしで[0,n)へ写す。
    int operator()(int n) { return int((__uint128_t(next())*uint64_t(n))>>64); }
    double unit() { return (next()>>11)*0x1.0p-53; }
} rng;

constexpr TowerBits tower_mask[9]={0u,0xfu,0xffu,0xfffu,0xffffu,0xfffffu,0xffffffu,0xfffffffu,0xffffffffu};
inline int height(TowerBits a) { return a ? (32-__builtin_clz(a)+3)/4 : 0; }
inline TowerBits prefix(TowerBits a,int k) { return a & tower_mask[k]; }
inline TowerBits reverse_tower(TowerBits a) {
    if(!a)return 0;
    int shift=(8-height(a))*4;
    a=((a>>4)&0x0f0f0f0fu)|((a&0x0f0f0f0fu)<<4);
    return __builtin_bswap32(a)>>shift;
}
inline TowerBits append_tower(TowerBits lower,TowerBits upper) {
    int h=height(lower);
    if(h==8) {if(upper)throw logic_error("tower overflow");return lower;}
    return lower|(upper<<(4*h));
}
inline int top_color_code(TowerBits a) {return a ? a>>(4*(height(a)-1)) : 0;}
inline int mono_color_code(TowerBits a) {
    if(!a)return 0;
    int current_code=a&15;
    return ((a^(0x11111111u*current_code))&tower_mask[height(a)]) ? -1 : current_code;
}

// 単位費用の探索用。費用別の連結リストを使い、古い候補の検査は呼び出し側で行う。
class IntegerQueue {
    struct Node {int id,next;};
    vector<int> head;
    vector<Node> node;
    int count=0,lowest=infinite_cost;
public:
    IntegerQueue():head(128,-1) {node.reserve(1600);}
    bool empty()const{return count==0;}
    void emplace(int cost,int id) {
        if(cost>=int(head.size()))head.resize(cost+128,-1);
        node.push_back({id,head[cost]});head[cost]=int(node.size())-1;
        lowest=min(lowest,cost);++count;
    }
    pair<int,int> top() {
        while(head[lowest]<0)++lowest;
        return {lowest,node[head[lowest]].id};
    }
    void pop(){head[lowest]=node[head[lowest]].next;--count;}
};

inline int color_mask(TowerBits a) {
    int m=0;
    for(;a;a>>=4) m|=1<<((a&15)-1);
    return m;
}
inline int runs(TowerBits a) {
    int r=0, last=-1;
    for(;a;a>>=4) { int current_code=a&15; r+=current_code!=last; last=current_code; }
    return r;
}

// pは床ID、dはU/D/L/Rの0..3。地形のrayは飛距離lをそのまま添字にする。
struct Move { int16_t p; uint8_t k,d,l; };
// 地形と初期入力。nest_codeは色符号、nest_pos_by_codeは符号から巣への逆引き。
struct Board {
    int N,K,cell_count=0,M=0;
    string C[20];
    int cell_id[20][20], row[max_cells], col[max_cells], parity[max_cells], nest_code[max_cells], nest_pos_by_code[13];
    int16_t adj[max_cells][4], ray[max_cells][4][9];
    uint8_t ray_count[max_cells][4]{};
    uint16_t floor_dist[max_cells][max_cells];
    array<TowerBits,max_cells> initial{};
    const int di[4]={-1,1,0,0}, dj[4]={0,0,-1,1};
    const char dirs[5]="UDLR";
    void read() {
        cin>>N>>K;
        memset(cell_id,-1,sizeof(cell_id)); memset(nest_pos_by_code,-1,sizeof(nest_pos_by_code));
        for(int i=0;i<N;i++) cin>>C[i];
        for(int i=0;i<N;i++) for(int j=0;j<N;j++) if(C[i][j]!='#') {
            int v=cell_id[i][j]=cell_count++; row[v]=i; col[v]=j; parity[v]=(i+j)&1;
            char input_char=C[i][j]; nest_code[v]=0;
            if(input_char>='A'&&input_char<='L') { nest_code[v]=input_char-'A'+1; nest_pos_by_code[nest_code[v]]=v; }
            if(input_char>='a'&&input_char<='l') { initial[v]=input_char-'a'+1; M++; }
        }
        for(int v=0;v<cell_count;v++) for(int d=0;d<4;d++) {
            fill(ray[v][d],ray[v][d]+9,-1);
            for(int l=1;l<=8;l++) {
                int i=row[v]+di[d]*l,j=col[v]+dj[d]*l;
                if(i<0||j<0||i>=N||j>=N||cell_id[i][j]<0) break;
                ray[v][d][l]=cell_id[i][j];ray_count[v][d]=uint8_t(l);
            }
            adj[v][d]=ray[v][d][1];
        }
        for(int s=0;s<cell_count;s++) {
            fill(floor_dist[s],floor_dist[s]+cell_count,uint16_t(infinite_cost));
            int q[max_cells],a=0,b=0; q[b++]=s; floor_dist[s][s]=0;
            while(a<b) {
                int v=q[a++];
                for(int d=0;d<4;d++) {
                    int w=adj[v][d];
                    if(w>=0&&floor_dist[s][w]==infinite_cost) { floor_dist[s][w]=floor_dist[s][v]+1; q[b++]=w; }
                }
            }
        }
    }
    TowerBits normalize(TowerBits a,int p) const {
        int code=nest_code[p];
        if(!code||!a)return a;
        TowerBits different=(a^(0x11111111u*code))&tower_mask[height(a)];
        return prefix(a,height(different));
    }
    // 帰巣する前の着地容量を含め、操作の合法性を検査する。
    int apply(State &b,Move m) const {
        int p=m.p;
        if(p<0||p>=cell_count)throw logic_error("invalid departure cell");
        int h=height(b[p]);
        if(m.k>=h||m.l<1||m.l>8||m.l>m.k+1||m.d>=4)
            throw logic_error("invalid departure");
        int q=ray[p][m.d][m.l];
        if(q<0) throw logic_error("wall or boundary");
        int g=height(b[q]);
        if(g+h-m.k>8) throw logic_error("landing capacity");
        TowerBits flight=reverse_tower(b[p]>>(4*m.k));
        TowerBits left=prefix(b[p],m.k), land=append_tower(b[q],flight);
        b[p]=normalize(left,p); b[q]=normalize(land,q);
        return h+g-height(b[p])-height(b[q]);
    }
    int count(const State &b) const {
        int ans=0; for(int p=0;p<cell_count;p++) ans+=height(b[p]); return ans;
    }
} board_info;

// 未使用500件の5分割比較で決めた入力条件。NNの重みと探索時間は親から保持する。
// 特徴の順序: floors。最終200件の結果による条件調整はしない。
static array<double,1> nn_selector_features() {
    [[maybe_unused]] const Board &b=board_info;
    return {double(b.cell_count)};
}
static bool nn_selector_choice([[maybe_unused]] const array<double,1> &f) {
    return (f[0]<=192.5 ? false : true);
}

class PortionRouter {
    int bg[max_cells], source, keep, amount;
    TowerBits packet;
    int16_t ds[2*max_cells], parent[2*max_cells];
    uint8_t dir[2*max_cells], len[2*max_cells];
public:
    void run(const State& b,int s,int k,int goal,int max_length=infinite_cost) {
        source=s;keep=k;packet=b[s]>>(4*k);amount=height(packet);
        for(int p=0;p<board_info.cell_count;p++) bg[p]=height(b[p]);
        bg[s]=height(board_info.normalize(prefix(b[s],k),s));
        fill(ds,ds+2*board_info.cell_count,int16_t(-1));
        int que[2*max_cells],head=0,tail=0;
        ds[s*2]=0;parent[s*2]=-1;que[tail++]=s*2;
        int top[2]={top_color_code(packet),int(packet&15)};
        while(head<tail) {
            int z=que[head++],p=z/2,o=z&1;
            if(ds[z]>=max_length)continue;
            if(ds[goal*2]>=0&&ds[goal*2+1]>=0)break;
            if(z!=s*2&&board_info.nest_code[p]==top[o]) continue;
            int reach=(z==s*2?keep:bg[p])+1;
            for(int d=0;d<4;d++) for(int l=1;l<=min(8,reach);l++) {
                int q=board_info.ray[p][d][l];if(q<0)break;
                if(bg[q]+amount>8)continue;
                int no=o^1,nz=q*2+no;
                if(q!=goal&&board_info.nest_code[q]==top[no])continue;
                if(ds[nz]>=0)continue;
                ds[nz]=ds[z]+1;parent[nz]=z;dir[nz]=d;len[nz]=l;
                que[tail++]=nz;
            }
        }
    }
    int cost(int goal,int o) const {return ds[goal*2+o];}
    vector<Move> path(int goal,int o) const {
        vector<Move> a;
        int z=goal*2+o;if(ds[z]<0)return a;
        while(parent[z]>=0) {
            int v=parent[z],p=v/2;
            a.push_back({int16_t(p),uint8_t(v==source*2?keep:bg[p]),dir[z],len[z]});
            z=v;
        }
        reverse(a.begin(),a.end());return a;
    }
};

// 連続した輸送を、終了時の全盤面が等しい短い経路へ置き換える。
vector<Move> smooth_routes(const vector<Move>& answer) {
    State b=board_info.initial;vector<Move> out;out.reserve(answer.size());
    for(int i=0;i<int(answer.size());) {
        if((i&31)==0)time_keeper.check();
        Move first=answer[i];
        int p=first.p,k=first.k,h=height(b[p])-k;
        TowerBits word=b[p]>>(4*k);State end=b;
        int q=p,j=i;TowerBits traveling=word;
        for(;j<int(answer.size())&&j<i+64;j++) {
            Move m=answer[j];
            if(m.p!=q||height(end[q])-m.k!=h||end[q]>>(4*m.k)!=traveling)break;
            int dest=board_info.ray[q][m.d][m.l];
            board_info.apply(end,m);q=dest;traveling=reverse_tower(traveling);
            if(board_info.normalize(traveling,q)!=traveling){j++;break;}
        }
        if(j==i) { // Defensive only: the first operation necessarily qualifies.
            board_info.apply(b,first);out.push_back(first);i++;continue;
        }
        vector<Move> replacement;
        int best_length_value=j-i;
        if(best_length_value>=2) {
            PortionRouter router;router.run(b,p,k,q,best_length_value-1);
            for(int o=0;o<2;o++) {
                int d=router.cost(q,o);if(d<0||d>=best_length_value)continue;
                auto path=router.path(q,o);State check=b;bool ok=true;
                try {for(auto m:path)board_info.apply(check,m);}catch(const exception&){ok=false;}
                if(ok&&check==end){best_length_value=d;replacement=move(path);}
            }
        }
        if(best_length_value<j-i)out.insert(out.end(),replacement.begin(),replacement.end());
        else out.insert(out.end(),answer.begin()+i,answer.begin()+j);
        b=end;i=j;
    }
    if(board_info.count(b))throw logic_error("smoothing incomplete");
    return out;
}

// 帰巣のない2マス間の転送では、一方を下から、他方を上から連結した列が不変。
// 両端へ触れない操作をまたいで正味の転送をまとめ、最初の転送位置へ置く。
vector<Move> compress_pair_transfers(const vector<Move>& answer) {
    struct Entry {
        Move op;
        int p,q,previous_p,previous_q,last_input,last_amount;
        TowerBits before_p,before_q;
        bool active,no_return;
    };
    vector<Entry> entries;entries.reserve(answer.size());
    array<int,max_cells> last_touch;last_touch.fill(-1);
    State board=board_info.initial;
    LOCAL_NOTE(int64_t merges=0,cancellations=0,changed_amount=0,separated=0,long_merges=0;)
    for(int i=0;i<int(answer.size());i++) {
        const Move m=answer[i];
        // 着地点を使う前に、元の操作の合法性を検査する。
        const State before=board;
        const int returned=board_info.apply(board,m);
        const int p=m.p,q=board_info.ray[p][m.d][m.l];
        const int amount=height(before[p])-m.k;
        const int previous=last_touch[p];
        if(!returned&&previous>=0&&previous==last_touch[q]&&entries[previous].no_return) {
            Entry& entry=entries[previous];
            State check=board;
            check[entry.p]=entry.before_p;check[entry.q]=entry.before_q;
            const int delta=height(entry.before_p)-height(board[entry.p]);
            if(delta) {
                const int source=delta>0?entry.p:entry.q;
                // 元の最後の出発で下段がl-1匹以上残るため、正味の向きが反転しても直接転送できる。
                const Move replacement{int16_t(source),uint8_t(height(board[source])),
                                       uint8_t(m.d^(source==p?0:1)),m.l};
                board_info.apply(check,replacement);
                entry.op=replacement;
            } else {
                entry.active=false;
                // 相殺された往復より前の最終接触を戻し、さらに前の転送とも相殺できるようにする。
                last_touch[entry.p]=entry.previous_p;
                last_touch[entry.q]=entry.previous_q;
            }
            // 不変条件の破れは、入力をそのまま返して隠さず例外にする。
            if(check!=board)throw logic_error("pair transfer board mismatch");
            LOCAL_NOTE(
                ++merges;cancellations+=delta==0;
                changed_amount+=entry.last_amount!=amount;
                separated+=i>entry.last_input+1;long_merges+=m.l>1;
            )
            entry.last_input=i;entry.last_amount=amount;
        } else {
            entries.push_back({m,p,q,last_touch[p],last_touch[q],i,amount,
                               before[p],before[q],true,returned==0});
            last_touch[p]=last_touch[q]=int(entries.size())-1;
        }
    }
    vector<Move> out;out.reserve(entries.size());
    for(const Entry& entry:entries)if(entry.active)out.push_back(entry.op);
    LOCAL_NOTE(
        trace.count_by("pair_transfer_merges",merges);
        trace.count_by("pair_transfer_cancellations",cancellations);
        trace.count_by("pair_transfer_changed_amount_merges",changed_amount);
        trace.count_by("pair_transfer_separated_merges",separated);
        trace.count_by("pair_transfer_long_merges",long_merges);
        trace.count_by("pair_transfer_saved",int64_t(answer.size())-int64_t(out.size()));
    )
    return out;
}

// 区間の入口と出口だけを固定し、途中の分割・合流を探索する。
// 各塔は8匹まで。参加総数の増加は状態数上限と期限で抑える。
using JointState = array<TowerBits,4>;
struct JointWindowStats {
    int64_t candidates=0,searches=0,expanded=0,state_caps=0,deadlines=0;
    int64_t replacements=0,saved=0,independent=0,changed_first_split=0;
    int64_t large_candidates=0,large_searches=0,large_replacements=0,large_saved=0;
    void summary() const {
        LOCAL_NOTE(
            trace.count_by("joint_window_candidates",candidates);
            trace.count_by("joint_window_searches",searches);
            trace.count_by("joint_window_expanded",expanded);
            trace.count_by("joint_window_state_caps",state_caps);
            trace.count_by("joint_window_deadlines",deadlines);
            trace.count_by("joint_window_replacements",replacements);
            trace.count_by("joint_window_saved",saved);
            trace.count_by("joint_window_independent",independent);
            trace.count_by("joint_window_changed_first_split",changed_first_split);
            trace.count_by("joint_window_large_candidates",large_candidates);
            trace.count_by("joint_window_large_searches",large_searches);
            trace.count_by("joint_window_large_replacements",large_replacements);
            trace.count_by("joint_window_large_saved",large_saved);
        )
    }
};
struct JointStateHash {
    size_t operator()(const JointState& s) const {
        uint64_t h=0x9e3779b97f4a7c15ULL;
        for(TowerBits w:s)h=(h^w)*0xbf58476d1ce4e5b9ULL;
        return h^(h>>32);
    }
};
class JointWindowRouter {
    struct Edge {int a,b,d,l;};
    struct Node {JointState state;int parent;Move move;};
    vector<Edge> edges;
    array<int,4> cells;
    array<vector<Node>,2> nodes;
    array<unordered_map<JointState,int,JointStateHash>,2> visited;
public:
    static constexpr int state_cap=16384;
    JointWindowRouter() {
        for(int side=0;side<2;side++) {
            nodes[side].reserve(state_cap);
            visited[side].reserve(state_cap);
        }
    }
    void prepare(const array<int,4>& positions,int count) {
        cells=positions;edges.clear();
        for(int a=0;a<count;a++)for(int b=0;b<count;b++)if(a!=b)
            for(int d=0;d<4;d++)for(int l=1;l<=8;l++)
                if(board_info.ray[cells[a]][d][l]==cells[b])edges.push_back({a,b,d,l});
    }
    template<class Emit>
    bool transitions(const JointState& s,bool backward,Emit emit) const {
        for(auto [a,b,d,l]:edges) {
            int ha=height(s[a]),hb=height(s[b]);
            if(!backward) {
                for(int k=max(l-1,ha+hb-8);k<ha;k++) {
                    JointState next=s;
                    next[a]=prefix(s[a],k);
                    next[b]=append_tower(s[b],reverse_tower(s[a]>>(4*k)));
                    if(!emit(next,Move{int16_t(cells[a]),uint8_t(k),uint8_t(d),uint8_t(l)}))return false;
                }
            } else if(ha>=l-1) {
                // 逆探索では順方向に合法な出発の直前を列挙する。物理的な逆ジャンプの支持は要求しない。
                for(int amount=1;amount<=min(hb,8-ha);amount++) {
                    JointState previous=s;
                    previous[a]=append_tower(s[a],reverse_tower(s[b]>>(4*(hb-amount))));
                    previous[b]=prefix(s[b],hb-amount);
                    if(!emit(previous,Move{int16_t(cells[a]),uint8_t(ha),uint8_t(d),uint8_t(l)}))return false;
                }
            }
        }
        return true;
    }
    bool search(const JointState& begin,const JointState& end,int max_moves,
                double deadline,JointWindowStats& stats,vector<Move>& result) {
        ++stats.searches;result.clear();
        if(begin==end)return true;
        for(int side=0;side<2;side++){nodes[side].clear();visited[side].clear();}
        nodes[0].push_back({begin,-1,{}});visited[0].emplace(begin,0);
        nodes[1].push_back({end,-1,{}});visited[1].emplace(end,0);
        array<vector<int>,2> frontier;frontier[0]={0};frontier[1]={0};
        int depth[2]={0,0},meeting[2]={-1,-1};
        while(depth[0]+depth[1]<max_moves&&!frontier[0].empty()&&!frontier[1].empty()) {
            int side=frontier[0].size()<=frontier[1].size()?0:1;
            vector<int> next;
            for(int parent:frontier[side]) {
                if((stats.expanded&127)==0&&time_keeper.exact_elapsed_sec()>=deadline){++stats.deadlines;return false;}
                ++stats.expanded;
                const JointState s=nodes[side][parent].state;
                bool completed=transitions(s,side!=0,[&](const JointState& state,Move move) {
                    if(visited[side].contains(state))return true;
                    if(nodes[0].size()+nodes[1].size()>=state_cap){++stats.state_caps;return false;}
                    int index=int(nodes[side].size());
                    nodes[side].push_back({state,parent,move});visited[side].emplace(state,index);
                    auto other=visited[side^1].find(state);
                    if(other!=visited[side^1].end()) {
                        meeting[side]=index;meeting[side^1]=other->second;return false;
                    }
                    next.push_back(index);return true;
                });
                if(meeting[0]>=0) {
                    for(int at=meeting[0];nodes[0][at].parent>=0;at=nodes[0][at].parent)
                        result.push_back(nodes[0][at].move);
                    reverse(result.begin(),result.end());
                    for(int at=meeting[1];nodes[1][at].parent>=0;at=nodes[1][at].parent)
                        result.push_back(nodes[1][at].move);
                    return true;
                }
                if(!completed)return false;
            }
            frontier[side]=move(next);++depth[side];
        }
        return false;
    }
};

struct JointWindow {
    int first,last,count=0,pieces=0,priority=0;
    array<int,4> cells{};
    JointState begin{},end{};
    vector<int> operations;
};
struct JointPatch {JointWindow window;vector<Move> replacement;};

vector<JointWindow> collect_joint_windows(const vector<Move>& answer,double deadline,
                                      JointWindowStats& stats,int first_begin=0,int first_end=INT_MAX) {
    vector<JointWindow> windows;State boundary=board_info.initial;
    for(int first=0;first<int(answer.size());first++) {
        if((first&15)==0&&time_keeper.exact_elapsed_sec()>=deadline){++stats.deadlines;break;}
        if(first<first_begin||first>=first_end){board_info.apply(boundary,answer[first]);continue;}
        array<int16_t,max_cells> local;local.fill(-1);
        array<bool,max_cells> blocked{};
        JointWindow w;w.first=w.last=first;
        for(int at=first;at<min(int(answer.size()),first+64);at++) {
            Move m=answer[at];int p=m.p,q=board_info.ray[p][m.d][m.l];
            if(at!=first&&local[p]<0&&local[q]<0) {
                blocked[p]=blocked[q]=true;continue;
            }
            bool allowed=true;int new_cells=0;
            for(int cell:{p,q})if(local[cell]<0) {
                if(blocked[cell]||board_info.nest_code[cell])allowed=false;
                ++new_cells;
            }
            if(!allowed||w.count+new_cells>4)break;
            for(int cell:{p,q})if(local[cell]<0) {
                int index=w.count++;local[cell]=int16_t(index);w.cells[index]=cell;
                w.begin[index]=w.end[index]=boundary[cell];
                w.pieces+=height(boundary[cell]);
            }
            int a=local[p],b=local[q];
            TowerBits parcel=w.end[a]>>(4*m.k);
            w.end[a]=prefix(w.end[a],m.k);
            w.end[b]=append_tower(w.end[b],reverse_tower(parcel));
            w.operations.push_back(at);w.last=at;
            if(w.operations.size()==8)break;
        }
        if(w.count>=3&&w.operations.size()>=3&&w.pieces>=2) {
            int changed=0;for(int j=0;j<w.count;j++)changed+=w.begin[j]!=w.end[j];
            w.priority=int(w.operations.size())-changed+(w.begin==w.end?16:0);
            stats.large_candidates+=w.pieces>8;
            windows.push_back(move(w));
        }
        board_info.apply(boundary,answer[first]);
    }
    stats.candidates+=windows.size();
    stable_sort(windows.begin(),windows.end(),[](const JointWindow& a,const JointWindow& b) {
        if(a.priority!=b.priority)return a.priority>b.priority;
        if(a.pieces!=b.pieces)return a.pieces<b.pieces;
        return a.operations.size()>b.operations.size();
    });
    return windows;
}

vector<Move> compress_joint_windows(const vector<Move>& answer,double deadline,
                                 JointWindowStats& stats,
                                 int first_begin=0,int first_end=INT_MAX) {
    auto windows=collect_joint_windows(answer,deadline,stats,first_begin,first_end);
    JointWindowRouter router;
    vector<JointPatch> patches;
    vector<bool> occupied(answer.size(),false);
    for(const auto& w:windows) {
        if(time_keeper.exact_elapsed_sec()>=deadline){++stats.deadlines;break;}
        bool overlap=false;for(int at=w.first;at<=w.last;at++)overlap|=occupied[at];
        if(overlap)continue;
        router.prepare(w.cells,w.count);vector<Move> replacement;
        stats.large_searches+=w.pieces>8;
        if(!router.search(w.begin,w.end,int(w.operations.size())-1,deadline,stats,replacement))continue;
        JointState check=w.begin;
        for(Move m:replacement) {
            int a=int(find(w.cells.begin(),w.cells.begin()+w.count,m.p)-w.cells.begin());
            int q=board_info.ray[m.p][m.d][m.l];
            int b=int(find(w.cells.begin(),w.cells.begin()+w.count,q)-w.cells.begin());
            if(a==w.count||b==w.count||m.k>=height(check[a])||m.l>m.k+1||
               height(check[b])+height(check[a])-m.k>8)throw logic_error("joint window illegal move");
            check[b]=append_tower(check[b],reverse_tower(check[a]>>(4*m.k)));
            check[a]=prefix(check[a],m.k);
        }
        if(check!=w.end||replacement.size()>=w.operations.size())throw logic_error("joint window endpoint mismatch");
        ++stats.replacements;stats.saved+=w.operations.size()-replacement.size();
        if(w.pieces>8){++stats.large_replacements;stats.large_saved+=w.operations.size()-replacement.size();}
        stats.independent+=w.last-w.first+1-int(w.operations.size());
        if(!replacement.empty())stats.changed_first_split+=replacement.front().k!=answer[w.first].k;
        for(int at=w.first;at<=w.last;at++)occupied[at]=true;
        patches.push_back({w,move(replacement)});
    }
    sort(patches.begin(),patches.end(),[](const JointPatch& a,const JointPatch& b){return a.window.first<b.window.first;});
    vector<Move> result;result.reserve(answer.size());int position=0;
    for(const auto& patch:patches) {
        const auto& w=patch.window;
        result.insert(result.end(),answer.begin()+position,answer.begin()+w.first);
        result.insert(result.end(),patch.replacement.begin(),patch.replacement.end());
        // 省略した操作の接触先はblockedで窓への追加を禁止したため、置換全体と交換できる。
        size_t related=0;
        for(int at=w.first;at<=w.last;at++) {
            if(related<w.operations.size()&&w.operations[related]==at)++related;
            else result.push_back(answer[at]);
        }
        position=w.last+1;
    }
    result.insert(result.end(),answer.begin()+position,answer.end());
    State original=board_info.initial,checked=board_info.initial;
    for(Move m:answer)board_info.apply(original,m);
    for(Move m:result)board_info.apply(checked,m);
    if(checked!=original)throw logic_error("joint window full board mismatch");
    return result;
}

#ifdef LOCAL
struct MonoDispatchStats {
    int64_t scans=0,windows=0,routes=0,replacements=0,saved=0,independent=0;
    void summary() const {
        auto count=[&](const char* key,int64_t value){trace.count_by(string("mono_dispatch_")+key,value);};
        count("scans",scans);count("windows",windows);count("routes",routes);
        count("replacements",replacements);count("saved",saved);count("independent",independent);
    }
} local_mono_dispatch;
#endif

// 同色のp→q、p→r、r→qを、踏み台部分もまとめて輸送する。
// p/q/rへ触れない操作は交換し、それ以外の接触で区間を閉じる。
int consolidate_mono_dispatch(const vector<Move>& answer,int begin,State& board,
                            vector<Move>& out,int& saved) {
    saved=0;
    const Move first=answer[begin];const int p=first.p;
    if(first.k==0)return begin;
    const TowerBits first_word=board[p]>>(4*first.k);
    const int color_code=mono_color_code(first_word);
    if(color_code<=0||top_color_code(prefix(board[p],first.k))!=color_code)return begin;
    LOCAL_NOTE(++local_mono_dispatch.scans;)
    const int q=board_info.ray[p][first.d][first.l];
    const int stop=min(int(answer.size()),begin+64);
    auto dest=[&](int i){const Move m=answer[i];return board_info.ray[m.p][m.d][m.l];};
    auto touches=[&](int i,int cell){return answer[i].p==cell||dest(i)==cell;};
    int second=begin+1;
    while(second<stop&&!touches(second,p)&&!touches(second,q))++second;
    if(second==stop||answer[second].p!=p)return begin;
    const int r=dest(second);
    if(r==p||r==q)return begin;
    // 置換を最初の出発へ移すため、中継塔に変更がないことを積み順まで確認する。
    for(int i=begin+1;i<second;i++)if(touches(i,r))return begin;
    int third=second+1;
    while(third<stop&&!touches(third,p)&&!touches(third,q)&&!touches(third,r))++third;
    if(third==stop||answer[third].p!=r||dest(third)!=q)return begin;
    LOCAL_NOTE(++local_mono_dispatch.windows;)
    State end=board;
    TowerBits second_word=0;
    for(int i=begin;i<=third;i++) {
        const Move m=answer[i];
        if(i==second) {
            second_word=end[p]>>(4*m.k);
            if(mono_color_code(second_word)!=color_code)return begin;
        }
        if(i==third&&(m.k!=height(board[r])||end[r]>>(4*m.k)!=second_word))return begin;
        board_info.apply(end,m);
    }
    const int keep=answer[second].k;
    if(keep>=first.k||mono_color_code(board[p]>>(4*keep))!=color_code)return begin;
    LOCAL_NOTE(++local_mono_dispatch.routes;)
    PortionRouter router;router.run(board,p,keep,q,2);
    for(int orientation=0;orientation<2;orientation++) {
        const int length=router.cost(q,orientation);
        if(length<0||length>=3)continue;
        const auto path=router.path(q,orientation);
        State check=board;bool legal=true;
        try {
            for(const Move m:path)board_info.apply(check,m);
            for(int i=begin+1;i<third;i++)if(i!=second)board_info.apply(check,answer[i]);
        }catch(const exception&){legal=false;}
        // 容量は帰巣前に検査する。全盤面の一致で、踏み台や中継巣の帰巣も確認する。
        if(!legal||!(check==end))continue;
        out.insert(out.end(),path.begin(),path.end());
        for(int i=begin+1;i<third;i++)if(i!=second)out.push_back(answer[i]);
        saved=3-length;board=end;
        LOCAL_NOTE(++local_mono_dispatch.replacements;local_mono_dispatch.saved+=saved;
                   local_mono_dispatch.independent+=third-begin-2;)
        return third+1;
    }
    return begin;
}

vector<Move> compress_mono_dispatch(const vector<Move>& answer,double deadline) {
    State board=board_info.initial;vector<Move> result;result.reserve(answer.size());
    for(int i=0;i<int(answer.size());) {
        if(time_keeper.exact_elapsed_sec()>=deadline) {
            result.insert(result.end(),answer.begin()+i,answer.end());return result;
        }
        int saved=0;int next=consolidate_mono_dispatch(answer,i,board,result,saved);
        if(next>i)i=next;
        else{board_info.apply(board,answer[i]);result.push_back(answer[i++]);}
    }
    if(board_info.count(board))throw logic_error("mono dispatch incomplete");
    return result;
}

struct CoupledRoutesStats {
    int64_t calls=0,seeds=0,routes=0,branches=0,replacements=0,saved=0;
    int64_t independent=0,deadlines=0,beam_caps=0,depth_caps=0;
    int64_t overrun_seeds=0,relaxed_branches=0,relaxed_replacements=0,relaxed_saved=0;
    int64_t overrun_replacements=0,overrun_saved=0;
    double seconds=0;
#ifdef LOCAL
    void summary() const {
        auto count=[&](const char* key,int64_t value){trace.count_by(string("coupled_routes_")+key,value);};
        count("calls",calls);count("seeds",seeds);count("routes",routes);count("branches",branches);
        count("replacements",replacements);count("saved",saved);count("independent",independent);
        count("deadlines",deadlines);count("beam_caps",beam_caps);count("depth_caps",depth_caps);
        count("overrun_seeds",overrun_seeds);count("relaxed_branches",relaxed_branches);
        count("relaxed_replacements",relaxed_replacements);count("relaxed_saved",relaxed_saved);
        count("overrun_replacements",overrun_replacements);count("overrun_saved",overrun_saved);
        trace.add_time_ms("coupled_routes",seconds*1000.0);
    }
#endif
} coupled_routes;
struct CoupledRoutesTimer {
    double begin=time_keeper.exact_elapsed_sec();
    ~CoupledRoutesTimer(){coupled_routes.seconds+=time_keeper.exact_elapsed_sec()-begin;}
};
struct RouteVariant {
    array<TowerBits,max_cells> words{};
    vector<Move> moves;
    int peak_excess=0;
    bool relaxed=false;
};

// 合流・分割・帰巣までを1輸送として読む。次の輸送では束の構成が変わり得る。
int consume_transfer(const vector<Move>& answer,int begin,int stop,State& board,int& goal) {
    const Move first=answer[begin];
    const int amount=height(board[first.p])-first.k;
    TowerBits traveling=board[first.p]>>(4*first.k);goal=first.p;
    int end=begin;
    for(;end<stop;end++) {
        const Move m=answer[end];
        if(m.p!=goal||height(board[goal])-m.k!=amount||board[goal]>>(4*m.k)!=traveling)break;
        board_info.apply(board,m);goal=board_info.ray[m.p][m.d][m.l];traveling=reverse_tower(traveling);
        if(board_info.normalize(traveling,goal)!=traveling){++end;break;}
    }
    if(end==begin)throw logic_error("empty transfer segment");
    return end;
}

// 区間境界で高さを保ち、最大2塔の積み順の差を後の輸送まで引き継ぐ。
int route_difference(const State& candidate,const State& original) {
    int different=0;
    for(int p=0;p<board_info.cell_count;p++)if(candidate[p]!=original[p]) {
        if(height(candidate[p])!=height(original[p])||++different>2)return -1;
    }
    return different;
}
RouteVariant route_variant(const State& board,vector<Move> moves) {
    RouteVariant result;
    for(int p=0;p<board_info.cell_count;p++)result.words[p]=board[p];
    result.moves=move(moves);return result;
}

int couple_transfer_window(const vector<Move>& answer,int begin,State& board,
                         vector<Move>& output,int& saved,double deadline,bool allow_slack=true) {
    saved=0;
    const int stop=min(int(answer.size()),begin+64);
    State original=board;int goal=-1;
    int end=consume_transfer(answer,begin,stop,original,goal);
    if(!allow_slack&&end-begin<2)return begin;
    const Move first=answer[begin];
    // 上下対称な束には、後の輸送まで引き継ぐ向きの差がない。
    const TowerBits packet=board[first.p]>>(4*first.k);
    if(packet==reverse_tower(packet))return begin;
    // 厳密側は最初から短縮する経路を残す。緩和側は1手の超過を許し、候補4本で追跡する。
    const int first_cap=end-begin+(allow_slack?1:-1);
    PortionRouter router;router.run(board,first.p,first.k,goal,first_cap);++coupled_routes.routes;
    vector<RouteVariant> active;
    for(int o=0;o<2;o++) {
        int length=router.cost(goal,o);if(length<0||length>first_cap)continue;
        State candidate=board;auto path=router.path(goal,o);bool legal=true;
        try{for(auto m:path)board_info.apply(candidate,m);}catch(const exception&){legal=false;}
        if(legal&&route_difference(candidate,original)>0) {
            auto variant=route_variant(candidate,move(path));
            variant.peak_excess=max(0,length-(end-begin));
            variant.relaxed=length>=end-begin;
            coupled_routes.overrun_seeds+=variant.peak_excess>0;
            active.push_back(move(variant));
        }
    }
    if(active.empty())return begin;
    ++coupled_routes.seeds;
    for(int depth=1;depth<8&&end<stop;depth++) {
        if(time_keeper.exact_elapsed_sec()>=deadline){++coupled_routes.deadlines;return begin;}
        array<TowerBits,max_cells> before{};for(int p=0;p<board_info.cell_count;p++)before[p]=original[p];
        const int start=end;const Move next=answer[start];
        end=consume_transfer(answer,start,stop,original,goal);
        vector<RouteVariant> children;
        for(const auto& variant:active) {
            if(time_keeper.exact_elapsed_sec()>=deadline){++coupled_routes.deadlines;return begin;}
            State working=variant.words;
            bool touches=false;
            for(int i=start;i<end;i++) {
                const Move m=answer[i];const int q=board_info.ray[m.p][m.d][m.l];
                touches|=before[m.p]!=variant.words[m.p]||before[q]!=variant.words[q];
            }
            // 無関係な操作は順序を保って再生し、経路を探索し直さない。
            if(!touches) {
                auto path=variant.moves;
                for(int i=start;i<end;i++){board_info.apply(working,answer[i]);path.push_back(answer[i]);}
                auto child=route_variant(working,move(path));
                child.peak_excess=variant.peak_excess;child.relaxed=variant.relaxed;
                children.push_back(move(child));++coupled_routes.independent;
                continue;
            }
            // 先の短縮を後の輸送に使えるよう、手数上限は区間全体へ適用する。
            const int budget=allow_slack?end-begin+1-int(variant.moves.size()):end-start;
            router.run(working,next.p,next.k,goal,budget);++coupled_routes.routes;
            for(int o=0;o<2;o++) {
                const int length=router.cost(goal,o);if(length<0||length>budget)continue;
                auto path=router.path(goal,o);State candidate=working;bool legal=true;
                try{for(auto m:path)board_info.apply(candidate,m);}catch(const exception&){legal=false;}
                if(!legal)continue;
                const int difference=route_difference(candidate,original);
                if(difference<0)continue;
                vector<Move> complete=variant.moves;
                complete.insert(complete.end(),path.begin(),path.end());++coupled_routes.branches;
                auto child=route_variant(candidate,move(complete));
                child.peak_excess=max(variant.peak_excess,int(child.moves.size())-(end-begin));
                child.relaxed=variant.relaxed||length>end-start;
                coupled_routes.relaxed_branches+=length>end-start;
                if(difference==0&&int(child.moves.size())<end-begin) {
                    saved=end-begin-int(child.moves.size());
                    board=original;output.insert(output.end(),child.moves.begin(),child.moves.end());
                    ++coupled_routes.replacements;coupled_routes.saved+=saved;
                    coupled_routes.relaxed_replacements+=child.relaxed;
                    coupled_routes.relaxed_saved+=child.relaxed?saved:0;
                    coupled_routes.overrun_replacements+=child.peak_excess>0;
                    coupled_routes.overrun_saved+=child.peak_excess>0?saved:0;
                    return end;
                }
                children.push_back(move(child));
            }
        }
        if(children.empty())return begin;
        stable_sort(children.begin(),children.end(),[](const auto& a,const auto& b){return a.moves.size()<b.moves.size();});
        active.clear();
        for(auto& child:children) {
            bool duplicate=false;for(const auto& kept:active)duplicate|=child.words==kept.words;
            if(duplicate)continue;
            if(active.size()==4){++coupled_routes.beam_caps;break;}
            active.push_back(move(child));
        }
    }
    ++coupled_routes.depth_caps;return begin;
}

vector<Move> polish_coupled_routes(const vector<Move>& answer,double deadline,int& saved,bool allow_slack=true,
                                 int first_begin=0,int first_end=INT_MAX) {
    CoupledRoutesTimer timer;++coupled_routes.calls;saved=0;
    State board=board_info.initial;vector<Move> output;output.reserve(answer.size());
    for(int i=0;i<int(answer.size());) {
        // 置換後の全盤面が一致しているため、期限到達時は残りの操作をそのままつなげられる。
        if(time_keeper.exact_elapsed_sec()>=deadline) {
            ++coupled_routes.deadlines;
            output.insert(output.end(),answer.begin()+i,answer.end());return output;
        }
        if(i<first_begin||i>=first_end){board_info.apply(board,answer[i]);output.push_back(answer[i++]);continue;}
        int shorter=0;const int end=couple_transfer_window(answer,i,board,output,shorter,deadline,allow_slack);
        if(end>i){saved+=shorter;i=end;}
        else{board_info.apply(board,answer[i]);output.push_back(answer[i++]);}
    }
    if(board_info.count(board))throw logic_error("coupled routes incomplete");
    return output;
}

// 1回のBFSで全着地点を調べる。帰巣が起きた着地で輸送を切り、変化後の盤面から再探索する。
class FiniteRouter {
    int source,keep,bg[max_cells];
    int16_t distance[2*max_cells],previous[2*max_cells];
    uint8_t direction[2*max_cells],length[2*max_cells];
public:
    void run(const State& b,int p,int k,int cap) {
        source=p;keep=k;TowerBits packet=b[p]>>(4*k);int amount=height(packet);
        for(int v=0;v<board_info.cell_count;v++)bg[v]=height(b[v]);
        bg[p]=height(board_info.normalize(prefix(b[p],k),p));
        fill(distance,distance+2*board_info.cell_count,int16_t(-1));
        int queue[2*max_cells],head=0,tail=0;queue[tail++]=p*2;distance[p*2]=0;previous[p*2]=-1;
        int top[2]={top_color_code(packet),int(packet&15)};
        while(head<tail) {
            int at=queue[head++],v=at/2,o=at&1;
            if(distance[at]>=cap||(at!=p*2&&board_info.nest_code[v]==top[o]))continue;
            int reach=(at==p*2?keep:bg[v])+1;
            for(int d=0;d<4;d++)for(int l=1;l<=min(reach,int(board_info.ray_count[v][d]));l++) {
                int q=board_info.ray[v][d][l],next=q*2+(o^1);
                if(bg[q]+amount>8||distance[next]>=0)continue;
                distance[next]=distance[at]+1;previous[next]=at;direction[next]=d;length[next]=l;
                queue[tail++]=next;
            }
        }
    }
    int cost(int q,int o) const {return distance[q*2+o];}
    vector<Move> path(int q,int o) const {
        vector<Move> moves;int at=q*2+o;
        if(distance[at]<0)return moves;
        while(previous[at]>=0) {
            int prev=previous[at],p=prev/2;
            moves.push_back({int16_t(p),uint8_t(prev==source*2?keep:bg[p]),direction[at],length[at]});
            at=prev;
        }
        reverse(moves.begin(),moves.end());return moves;
    }
};

// 固定背景上の全可動塔をマスと色順で表す。個体IDは区別せず、積み順と容量を保つ。
using FiniteState=array<uint64_t,16>;
struct FiniteHash {
    size_t operator()(const FiniteState& s) const {
        uint64_t h=0x9e3779b97f4a7c15ULL;
        for(uint64_t x:s)h=(h^x)*0xbf58476d1ce4e5b9ULL;
        return h^(h>>32);
    }
};
int common_tower_prefix(TowerBits a,TowerBits b) {
    int n=0;while(a&&b&&(a&15)==(b&15)){++n;a>>=4;b>>=4;}return n;
}
struct FiniteWindow {
    int first=0,last=0,count=0,pieces=0,towers=0,priority=0;
    bool has_nest=false;
    array<int,8> cells{};
    array<TowerBits,8> begin{},end{};
    vector<int> operations;
};
struct FinitePatch {FiniteWindow window;vector<Move> replacement;};
struct FiniteStats {
    int64_t candidates=0,eligible=0,attempts=0,searches=0,expanded=0,generated=0;
    int64_t bound_prunes=0,returned_prunes=0,beam_pruned=0,completed=0,capped=0,deadlines=0,global_deadlines=0;
    int64_t replacements=0,saved=0,nonempty_replacements=0,nonempty_saved=0,nest_saved=0;
    int64_t merges=0,split_moves=0,source_returns=0,independent=0;
    void summary() const {
        LOCAL_NOTE(
            auto count=[&](const char* key,int64_t value){trace.count_by(string("finite_")+key,value);};
            count("candidates",candidates);count("eligible",eligible);count("attempts",attempts);
            count("searches",searches);count("expanded",expanded);count("generated",generated);
            count("bound_prunes",bound_prunes);count("returned_prunes",returned_prunes);count("beam_pruned",beam_pruned);
            count("completed",completed);count("capped",capped);count("deadlines",deadlines);
            count("global_deadlines",global_deadlines);count("replacements",replacements);count("saved",saved);
            count("nonempty_replacements",nonempty_replacements);count("nonempty_saved",nonempty_saved);
            count("nest_saved",nest_saved);count("merges",merges);count("split_moves",split_moves);
            count("source_returns",source_returns);count("independent",independent);
        )
    }
};

vector<FiniteWindow> collect_finite_windows(const vector<Move>& answer,double deadline,FiniteStats& stats,
                                            int first_begin=0,int first_end=INT_MAX) {
    vector<FiniteWindow> windows;State boundary=board_info.initial;
    for(int first=0;first<int(answer.size());first++) {
        if((first&15)==0&&time_keeper.exact_elapsed_sec()>=deadline){++stats.global_deadlines;break;}
        if(first<first_begin||first>=first_end){board_info.apply(boundary,answer[first]);continue;}
        array<int16_t,max_cells> local;local.fill(-1);array<bool,max_cells> blocked{};
        FiniteWindow w;w.first=w.last=first;
        for(int at=first;at<min(int(answer.size()),first+64);at++) {
            Move m=answer[at];int p=m.p,q=board_info.ray[p][m.d][m.l];
            if(at!=first&&local[p]<0&&local[q]<0){blocked[p]=blocked[q]=true;continue;}
            bool allowed=true;int cells=0,pieces=0,towers=0;
            for(int v:{p,q})if(local[v]<0) {
                allowed&=!blocked[v];++cells;pieces+=height(boundary[v]);towers+=boundary[v]!=0;
            }
            if(!allowed||w.count+cells>8||w.pieces+pieces>16||w.towers+towers>6)break;
            w.pieces+=pieces;w.towers+=towers;
            for(int v:{p,q})if(local[v]<0) {
                int i=w.count++;local[v]=int16_t(i);w.cells[i]=v;
                w.begin[i]=w.end[i]=boundary[v];w.has_nest|=board_info.nest_code[v]!=0;
            }
            const int a=local[p],b=local[q];TowerBits packet=w.end[a]>>(4*m.k);
            w.end[a]=board_info.normalize(prefix(w.end[a],m.k),p);
            w.end[b]=board_info.normalize(append_tower(w.end[b],reverse_tower(packet)),q);
            w.operations.push_back(at);w.last=at;
            if(w.operations.size()>=3&&w.pieces>=2) {
                int sources=0,destinations=0;
                for(int i=0;i<w.count;i++) {
                    int matched=common_tower_prefix(w.begin[i],w.end[i]);
                    sources+=height(w.begin[i])>matched;destinations+=height(w.end[i])>matched;
                }
                w.priority=int(w.operations.size())-max(sources,destinations);
                windows.push_back(w);stats.eligible+=w.has_nest||w.count>4;
            }
            if(w.operations.size()==12)break;
        }
        board_info.apply(boundary,answer[first]);
    }
    stats.candidates+=windows.size();
    stable_sort(windows.begin(),windows.end(),[](const FiniteWindow& a,const FiniteWindow& b) {
        if(a.priority!=b.priority)return a.priority>b.priority;
        if(a.operations.size()!=b.operations.size())return a.operations.size()<b.operations.size();
        if(a.pieces!=b.pieces)return a.pieces<b.pieces;
        return a.first<b.first;
    });
    return windows;
}

class FinitePlanner {
    friend struct FiniteProbe;
    struct Node {
        FiniteState state{};
        int cost=0,parent=-1,source=-1,keep=0,destination=-1,orientation=0;
        double priority=0;
    };
    array<TowerBits,max_cells> goal_word{};
    array<int,13> required{};
    array<array<int,max_cells>,13> target_distance{};
    FiniteState target{};
    int jump=1;
    static TowerBits word(uint64_t x){return TowerBits(x);}
    static int cell(uint64_t x){return int(x>>32);}
    static FiniteState encode(const State& b,const State& background) {
        FiniteState s{};int n=0;
        for(int p=0;p<board_info.cell_count;p++) {
            int h=height(background[p]);
            if(prefix(b[p],h)!=background[p])throw logic_error("finite background changed");
            TowerBits w=h==8?0:b[p]>>(4*h);
            if(w){if(n==16)throw logic_error("finite capacity");s[n++]=(uint64_t(p)<<32)|w;}
        }
        return s;
    }
    static void decode(const FiniteState& s,const State& background,State& b) {
        b=background;for(uint64_t x:s)if(x)b[cell(x)]=append_tower(b[cell(x)],word(x));
    }
    int assess(const FiniteState& s,double& estimate) const {
        array<int,13> actual{};array<TowerBits,max_cells> current{};
        int sources=0,destinations=0,unsettled=0;double distance=0;
        for(uint64_t x:s)if(x) {
            int p=cell(x);TowerBits w=word(x);current[p]=w;
            for(TowerBits a=w;a;a>>=4)++actual[a&15];
            int matched=common_tower_prefix(w,goal_word[p]);
            sources+=height(w)>matched;unsettled+=height(w)-matched;
            TowerBits suffix=matched==8?0:w>>(4*matched);
            for(unsigned mask=color_mask(suffix);mask;mask&=mask-1)
                distance+=target_distance[1+__builtin_ctz(mask)][p];
        }
        // 帰巣した個体は戻せないため、出口で必要な匹数を下回った状態を捨てる。
        for(int current_code=1;current_code<=board_info.K;current_code++)if(actual[current_code]<required[current_code])return -1;
        for(uint64_t x:target)if(x)
            destinations+=height(word(x))>common_tower_prefix(current[cell(x)],word(x));
        const int lower=max(sources,destinations);
        // 枝刈りは下界だけで行う。距離と積み順は、出口に塔を残す場合も含めた探索順位に使う。
        estimate=lower+0.5*distance/jump+0.125*unsettled;
        return lower;
    }
public:
    bool plan(const State& initial,const FiniteWindow& window,int cap,double deadline,
              vector<Move>& answer,FiniteStats& stats) {
        ++stats.searches;answer.clear();State background=initial;
        goal_word.fill(0);required.fill(0);target.fill(0);
        array<int,13> initial_counts{};unsigned colors=0;vector<int> start_cells;
        for(int i=0;i<window.count;i++) {
            int p=window.cells[i];background[p]=0;goal_word[p]=window.end[i];
            if(initial[p])start_cells.push_back(p);
            colors|=color_mask(initial[p]);
            for(TowerBits w=initial[p];w;w>>=4)++initial_counts[w&15];
            for(TowerBits w=window.end[i];w;w>>=4)++required[w&15];
        }
        int next_target=0;
        for(int p=0;p<board_info.cell_count;p++)if(goal_word[p])target[next_target++]=(uint64_t(p)<<32)|goal_word[p];
        for(int current_code=1;current_code<=board_info.K;current_code++)for(int p=0;p<board_info.cell_count;p++) {
            int distance=initial_counts[current_code]>required[current_code]?board_info.floor_dist[p][board_info.nest_pos_by_code[current_code]]:infinite_cost;
            for(uint64_t x:target)if(x&&(color_mask(word(x))&(1u<<(current_code-1))))
                distance=min(distance,int(board_info.floor_dist[p][cell(x)]));
            target_distance[current_code][p]=distance;
        }
        array<bool,max_cells> destination{};
        for(int i=0;i<window.count;i++)destination[window.cells[i]]=true;
        for(unsigned mask=colors;mask;mask&=mask-1) {
            int nest_pos_by_code=board_info.nest_pos_by_code[1+__builtin_ctz(mask)];destination[nest_pos_by_code]=true;
            for(int d=0;d<4;d++)if(board_info.adj[nest_pos_by_code][d]>=0)destination[board_info.adj[nest_pos_by_code][d]]=true;
        }
        vector<pair<int,int>> meeting;
        if(start_cells.size()>=2)for(int p=0;p<board_info.cell_count;p++) {
            int a=infinite_cost,b=infinite_cost;
            for(int q:start_cells){int d=board_info.floor_dist[p][q];if(d<a){b=a;a=d;}else b=min(b,d);}
            meeting.push_back({a+b,p});
        }
        sort(meeting.begin(),meeting.end());
        for(int i=0;i<min(4,int(meeting.size()));i++)destination[meeting[i].second]=true;
        int max_background=0;for(int p=0;p<board_info.cell_count;p++)max_background=max(max_background,height(background[p]));
        jump=min(8,1+max_background+min(3,window.pieces-1));
        vector<Node> history(1);history[0].state=encode(initial,background);
        if(history[0].state==target){++stats.completed;return true;}
        double estimate=0;const int root_lower=assess(history[0].state,estimate);
        if(root_lower<0||root_lower>cap){++stats.bound_prunes;return false;}
        vector<int> beam={0};Node goal;int best=cap+1,expanded=0;
        unordered_map<FiniteState,int,FiniteHash> settled;settled.reserve(256);
        State board=initial;FiniteRouter router;bool stop=false;
        for(int depth=0;depth<cap&&!beam.empty()&&!stop;depth++) {
            vector<Node> next;unordered_map<FiniteState,int,FiniteHash> index;index.reserve(2048);
            for(int id:beam) {
                if(time_keeper.exact_elapsed_sec()>=deadline){++stats.deadlines;stop=true;break;}
                if(expanded==192){++stats.capped;stop=true;break;}
                Node from=history[id];
                auto done=settled.find(from.state);
                if(done!=settled.end()&&done->second<=from.cost)continue;
                settled[from.state]=from.cost;++expanded;++stats.expanded;
                decode(from.state,background,board);
                auto targets=destination;for(uint64_t x:from.state)if(x)targets[cell(x)]=true;
                for(uint64_t x:from.state)if(x) {
                    int p=cell(x),base=height(background[p]);TowerBits w=word(x);
                    for(int k=0;k<height(w);k++) {
                        if(time_keeper.exact_elapsed_sec()>=deadline){++stats.deadlines;stop=true;break;}
                        const int keep=base+k,limit=best-1-from.cost;
                        if(limit<=0)continue;
                        router.run(board,p,keep,limit);
                        TowerBits packet=board[p]>>(4*keep);bool mono=mono_color_code(packet)>0;
                        for(int q=0;q<board_info.cell_count;q++)if(targets[q])for(int o=0;o<2;o++) {
                            int d=router.cost(q,o);if(d<=0||d>limit)continue;
                            if(mono&&router.cost(q,o^1)>0&&
                               (router.cost(q,o^1)<d||(router.cost(q,o^1)==d&&o==1)))continue;
                            State after=board;auto path=router.path(q,o);for(Move m:path)board_info.apply(after,m);
                            Node child;child.state=encode(after,background);child.cost=from.cost+d;
                            child.parent=id;child.source=p;child.keep=keep;child.destination=q;child.orientation=o;
                            ++stats.generated;
                            if(child.state==target){if(child.cost<best){best=child.cost;goal=child;}continue;}
                            int lower=assess(child.state,estimate);
                            if(lower<0){++stats.returned_prunes;continue;}
                            if(child.cost+lower>=best){++stats.bound_prunes;continue;}
                            auto old=settled.find(child.state);
                            if(old!=settled.end()&&old->second<=child.cost)continue;
                            child.priority=child.cost+estimate;
                            auto [it,fresh]=index.emplace(child.state,int(next.size()));
                            if(fresh)next.push_back(child);
                            else if(child.cost<next[it->second].cost)next[it->second]=child;
                        }
                        if(best==root_lower){stop=true;break;}
                    }
                    if(stop)break;
                }
                if(stop)break;
            }
            auto order=[](const Node& a,const Node& b) {
                if(a.priority!=b.priority)return a.priority<b.priority;
                if(a.cost!=b.cost)return a.cost<b.cost;
                return a.state<b.state;
            };
            int width=min(12,int(next.size()));stats.beam_pruned+=int(next.size())-width;
            partial_sort(next.begin(),next.begin()+width,next.end(),order);
            beam.clear();for(int i=0;i<width;i++){beam.push_back(int(history.size()));history.push_back(move(next[i]));}
        }
        if(best>cap)return false;
        vector<Node> path;for(Node n=goal;n.parent>=0;n=history[n.parent])path.push_back(n);
        reverse(path.begin(),path.end());board=initial;
        for(const Node& n:path) {
            router.run(board,n.source,n.keep,n.cost);
            for(Move m:router.path(n.destination,n.orientation)) {
                int q=board_info.ray[m.p][m.d][m.l];
                stats.merges+=height(board[q])>height(background[q]);
                stats.split_moves+=m.k>height(background[m.p]);
                stats.source_returns+=height(prefix(board[m.p],m.k))-height(board_info.normalize(prefix(board[m.p],m.k),m.p));
                board_info.apply(board,m);answer.push_back(m);
            }
        }
        if(encode(board,background)!=target||int(answer.size())!=best)throw logic_error("finite reconstruction mismatch");
        ++stats.completed;return true;
    }
};

vector<Move> compress_finite_windows(const vector<Move>& answer,double deadline,FiniteStats& stats,
                                    int first_begin=0,int first_end=INT_MAX) {
    auto windows=collect_finite_windows(answer,deadline,stats,first_begin,first_end);
    vector<bool> occupied(answer.size(),false),attempted(answer.size(),false);
    vector<FinitePatch> patches;FinitePlanner planner;int trials=0;
    for(const auto& w:windows) {
        if(time_keeper.exact_elapsed_sec()>=deadline){++stats.global_deadlines;break;}
        if(!(w.has_nest||w.count>4)||w.priority<=0||attempted[w.first])continue;
        bool overlap=false;for(int t=w.first;t<=w.last;t++)overlap|=occupied[t];
        if(overlap)continue;
        if(trials==32)break;
        attempted[w.first]=true;++trials;++stats.attempts;
        State boundary=board_info.initial;for(int t=0;t<w.first;t++)board_info.apply(boundary,answer[t]);
        // 1回の探索予算を全体の期限内に収める。無限の期限は固定仕事量の診断だけで使う。
        const double trial_deadline=isfinite(deadline)?min(deadline,time_keeper.exact_elapsed_sec()+PROGRAM_TIME_LIMIT_SEC*0.003):deadline;
        vector<Move> replacement;
        if(!planner.plan(boundary,w,int(w.operations.size())-1,trial_deadline,replacement,stats))continue;
        ++stats.replacements;const int saved=int(w.operations.size()-replacement.size());stats.saved+=saved;
        bool nonempty=any_of(w.end.begin(),w.end.begin()+w.count,[](TowerBits x){return x!=0;});
        stats.nonempty_replacements+=nonempty;stats.nonempty_saved+=nonempty?saved:0;
        stats.nest_saved+=w.has_nest?saved:0;stats.independent+=w.last-w.first+1-int(w.operations.size());
        for(int t=w.first;t<=w.last;t++)occupied[t]=true;
        patches.push_back({w,move(replacement)});
    }
    sort(patches.begin(),patches.end(),[](const FinitePatch& a,const FinitePatch& b){return a.window.first<b.window.first;});
    vector<Move> result;result.reserve(answer.size());int position=0;
    for(const auto& patch:patches) {
        const auto& w=patch.window;
        result.insert(result.end(),answer.begin()+position,answer.begin()+w.first);
        result.insert(result.end(),patch.replacement.begin(),patch.replacement.end());
        size_t related=0;
        for(int t=w.first;t<=w.last;t++) {
            if(related<w.operations.size()&&w.operations[related]==t)++related;
            else result.push_back(answer[t]);
        }
        position=w.last+1;
    }
    result.insert(result.end(),answer.begin()+position,answer.end());
    State original=board_info.initial,checked=board_info.initial;
    for(Move m:answer)board_info.apply(original,m);
    for(Move m:result)board_info.apply(checked,m);
    if(checked!=original)throw logic_error("finite full board mismatch");
    return result;
}

enum FinalReduction { FINAL_ROUTE,FINAL_PAIR,FINAL_JOINT,FINAL_MONO,FINAL_STRICT,FINAL_SLACK,FINAL_FINITE,FINAL_KINDS };
constexpr const char* final_reduction_names[]={"route","pair","joint","mono","strict","slack","finite"};
struct FinalReductionStats {
    array<int64_t,FINAL_KINDS> calls{},saved{};
    array<double,FINAL_KINDS> seconds{};
    int64_t cheap_rounds=0,finite_rounds=0,deadlines=0,finite_budget_stops=0,stable=0;
    JointWindowStats joint;
    FiniteStats finite;
    int64_t total_saved() const {return accumulate(saved.begin(),saved.end(),int64_t(0));}
    void summary() const {
        LOCAL_NOTE(
            auto count=[&](const string& key,int64_t n){trace.count_by("final_reductions_"+key,n);};
            count("saved",total_saved());count("cheap_rounds",cheap_rounds);count("finite_rounds",finite_rounds);
            count("deadlines",deadlines);count("finite_budget_stops",finite_budget_stops);count("stable",stable);
            for(int kind=0;kind<FINAL_KINDS;kind++) {
                const string name=final_reduction_names[kind];count(name+"_calls",calls[kind]);count(name+"_saved",saved[kind]);
                trace.add_time_ms("final_reductions_"+name,seconds[kind]*1000.0);
            }
            count("joint_searches",joint.searches);count("joint_expanded",joint.expanded);
            count("joint_state_caps",joint.state_caps);count("joint_deadlines",joint.deadlines);
            count("joint_replacements",joint.replacements);count("joint_large_saved",joint.large_saved);
            local_mono_dispatch.summary();coupled_routes.summary();finite.summary();
        )
    }
};

template<class Reduce>
void apply_final_reduction(vector<Move>& answer,int kind,FinalReductionStats& stats,Reduce reduce) {
    const double begin=time_keeper.exact_elapsed_sec();
    auto reduced=reduce();
    if(reduced.size()>answer.size())throw logic_error("final reduction increased moves");
    ++stats.calls[kind];stats.saved[kind]+=answer.size()-reduced.size();
    stats.seconds[kind]+=time_keeper.exact_elapsed_sec()-begin;answer=move(reduced);
}

// 短縮で分割・接触順が変わるため、各巡で短くなる間は再適用する。
// 有限区間の探索後にも安い短縮を行えるよう、終了予算を少し残す。
void polish_final_reductions(vector<Move>& answer,FinalReductionStats& stats) {
    const double deadline=time_keeper.time_limit_sec;
    const double finite_deadline=isfinite(deadline)?deadline-0.001*PROGRAM_TIME_LIMIT_SEC:deadline;
    auto check=[&]{if(time_keeper.exact_elapsed_sec()>=deadline)throw Deadline();};
    auto route_deadline=[&]{return isfinite(deadline)?min(deadline,time_keeper.exact_elapsed_sec()+0.003*PROGRAM_TIME_LIMIT_SEC):deadline;};
    try {
        while(true) {
            while(true) {
                const size_t before=answer.size();
                check();apply_final_reduction(answer,FINAL_ROUTE,stats,[&]{return smooth_routes(answer);});
                check();apply_final_reduction(answer,FINAL_PAIR,stats,[&]{return compress_pair_transfers(answer);});
                check();apply_final_reduction(answer,FINAL_JOINT,stats,[&]{return compress_joint_windows(answer,deadline,stats.joint);});
                check();apply_final_reduction(answer,FINAL_MONO,stats,[&]{return compress_mono_dispatch(answer,deadline);});
                check();apply_final_reduction(answer,FINAL_STRICT,stats,[&]{int saved;return polish_coupled_routes(answer,route_deadline(),saved,false);});
                check();apply_final_reduction(answer,FINAL_SLACK,stats,[&]{int saved;return polish_coupled_routes(answer,route_deadline(),saved,true);});
                ++stats.cheap_rounds;
                if(answer.size()==before)break;
            }
            check();
            if(time_keeper.exact_elapsed_sec()>=finite_deadline){++stats.finite_budget_stops;break;}
            const size_t before=answer.size();
            apply_final_reduction(answer,FINAL_FINITE,stats,[&]{return compress_finite_windows(answer,finite_deadline,stats.finite);});
            ++stats.finite_rounds;
            if(answer.size()==before){stats.stable=1;break;}
        }
    } catch(const Deadline&) {
        // 期限到達までに完了した短縮は残す。その他の例外は呼び出し側へ伝える。
        ++stats.deadlines;
    }
}

// 受理判定前に候補を短縮する。変更付近への重点化は選択基準であり、境界一致の保証ではない。
struct SearchFocus {
    int first=0,last=0;
    static bool same(Move a,Move b) {
        return a.p==b.p&&a.k==b.k&&a.d==b.d&&a.l==b.l;
    }
    static SearchFocus between(const vector<Move>& current,const vector<Move>& candidate) {
        int prefix=0,old_end=int(current.size()),new_end=int(candidate.size());
        while(prefix<min(old_end,new_end)&&same(current[prefix],candidate[prefix]))++prefix;
        if(prefix==old_end&&prefix==new_end)return {};
        while(old_end>prefix&&new_end>prefix&&same(current[old_end-1],candidate[new_end-1])){--old_end;--new_end;}
        return {max(0,prefix-64),min(int(candidate.size()),new_end+64)};
    }
};
struct SearchReductions {
    array<int64_t,FINAL_KINDS> calls{},saved{},accepted_saved{};
    array<double,FINAL_KINDS> seconds{};
    int64_t candidates=0,shortened=0,initial_saved=0,initial_reorder_saved=0;
    int64_t nonworse_created=0,best_created=0,probability_changed=0,accepted_shortened=0;
    int64_t eligible=0,budget_skips=0,heavy_calls=0,focus_operations=0,cheap_rounds=0;
    int64_t interrupted=0,budget_overruns=0;
    double heavy_seconds=0;
    int next_heavy=0;
    JointWindowStats joint;
    FiniteStats finite;
    static constexpr array<int,4> heavy_kinds={FINAL_JOINT,FINAL_STRICT,FINAL_SLACK,FINAL_FINITE};

    template<class Reduce>
    void apply(vector<Move>& answer,int kind,Reduce reduce) {
        const double begin=time_keeper.exact_elapsed_sec();++calls[kind];
        try {
            auto result=reduce();
            if(result.size()>answer.size())throw logic_error("candidate reduction increased moves");
            saved[kind]+=answer.size()-result.size();answer=move(result);
        } catch(const Deadline&) {
            seconds[kind]+=time_keeper.exact_elapsed_sec()-begin;++interrupted;throw;
        }
        seconds[kind]+=time_keeper.exact_elapsed_sec()-begin;
    }
    void cheap(vector<Move>& answer,double deadline) {
        while(time_keeper.exact_elapsed_sec()<deadline) {
            const size_t before=answer.size();++cheap_rounds;
            apply(answer,FINAL_PAIR,[&]{return compress_pair_transfers(answer);});
            if(time_keeper.exact_elapsed_sec()<deadline)
                apply(answer,FINAL_MONO,[&]{return compress_mono_dispatch(answer,deadline);});
            if(answer.size()==before)break;
            if(time_keeper.exact_elapsed_sec()<deadline)
                apply(answer,FINAL_ROUTE,[&]{return smooth_routes(answer);});
        }
    }
    static bool near_best(int iteration,size_t candidate,size_t current,size_t best) {
        return iteration%4==0&&candidate<=current+2&&candidate<=best+4;
    }
    static double remaining_budget(double exact_elapsed_sec,double spent) {
        // LNS経過時間の一定割合を予算とし、開始直後にも少量の余裕を与える。
        return 0.03*max(PROGRAM_TIME_LIMIT_SEC*0.02,exact_elapsed_sec)-spent;
    }
    void heavy(vector<Move>& answer,int kind,double deadline,SearchFocus focus) {
        switch(kind) {
            case FINAL_JOINT:
                apply(answer,kind,[&]{return compress_joint_windows(answer,deadline,joint,focus.first,focus.last);});break;
            case FINAL_STRICT:case FINAL_SLACK:
                apply(answer,kind,[&]{int removed;return polish_coupled_routes(answer,deadline,removed,kind==FINAL_SLACK,focus.first,focus.last);});break;
            case FINAL_FINITE:
                apply(answer,kind,[&]{return compress_finite_windows(answer,deadline,finite,focus.first,focus.last);});break;
            default:throw logic_error("unknown candidate reduction");
        }
    }
    void candidate(vector<Move>& answer,const vector<Move>& current,size_t best,
                   int iteration,double started,double end) {
        cheap(answer,end);
        if(!near_best(iteration,answer.size(),current.size(),best))return;
        const SearchFocus focus=SearchFocus::between(current,answer);
        if(focus.first==focus.last)return;
        ++eligible;
        const double begin=time_keeper.exact_elapsed_sec(),allowance=remaining_budget(begin-started,heavy_seconds);
        if(allowance<PROGRAM_TIME_LIMIT_SEC*0.0005||begin>=end){++budget_skips;return;}
        const double deadline=min(end,begin+min(allowance,PROGRAM_TIME_LIMIT_SEC*0.0015));
        const int kind=heavy_kinds[next_heavy];next_heavy=(next_heavy+1)%int(heavy_kinds.size());
        ++heavy_calls;focus_operations+=focus.last-focus.first;
        const size_t before=answer.size();
        heavy(answer,kind,deadline,focus);
        const double finish=time_keeper.exact_elapsed_sec();heavy_seconds+=finish-begin;
        budget_overruns+=finish>deadline;
        if(answer.size()<before)cheap(answer,end);
    }
    void summary() const {
        LOCAL_NOTE(
            auto count=[&](const string& key,int64_t n){trace.count_by("search_reductions_"+key,n);};
            count("candidates",candidates);count("shortened",shortened);count("initial_saved",initial_saved);
            count("initial_reorder_saved",initial_reorder_saved);count("nonworse_created",nonworse_created);
            count("best_created",best_created);count("probability_changed",probability_changed);
            count("accepted_shortened",accepted_shortened);count("eligible",eligible);count("budget_skips",budget_skips);
            count("heavy_calls",heavy_calls);count("focus_operations",focus_operations);count("cheap_rounds",cheap_rounds);
            count("interrupted",interrupted);count("budget_overruns",budget_overruns);
            for(int kind=0;kind<FINAL_KINDS;kind++) {
                const string name=final_reduction_names[kind];
                count(name+"_calls",calls[kind]);count(name+"_saved",saved[kind]);count(name+"_accepted_saved",accepted_saved[kind]);
                trace.add_time_ms("search_reductions_"+name,seconds[kind]*1000.0);
            }
            trace.add_time_ms("search_reductions_heavy",heavy_seconds*1000.0);
            count("joint_searches",joint.searches);count("joint_caps",joint.state_caps);count("joint_deadlines",joint.deadlines);
            count("finite_attempts",finite.attempts);count("finite_deadlines",finite.deadlines);
            count("finite_global_deadlines",finite.global_deadlines);count("finite_caps",finite.capped);
        )
    }
} search_reductions;

// 個体IDは初期位置の床ID。同色の束の除去では、色順が同じなら個体IDの割り当てを交換できる。
struct IdentityState {
    array<array<int16_t,8>,max_cells> a{};
    array<uint8_t,max_cells> h{};
    array<uint8_t,max_cells> alive{};
    IdentityState(const vector<int>& deleted={}) {
        array<bool,max_cells> omit{};for(int id:deleted)omit[id]=true;
        for(int p=0;p<board_info.cell_count;p++)if(board_info.initial[p]&&!omit[p]){
            a[p][0]=p;h[p]=1;alive[p]=1;
        }
    }
    TowerBits word(int p) const {
        TowerBits w=0;
        for(int i=0;i<h[p];i++)w|=board_info.initial[a[p][i]]<<(4*i);
        return w;
    }
    State words() const {State b{};for(int p=0;p<board_info.cell_count;p++)b[p]=word(p);return b;}
    void apply(Move m) {
        int p=m.p,q=board_info.ray[p][m.d][m.l];
        if(m.k>=h[p]||m.l<1||m.l>m.k+1||q<0||h[q]+h[p]-m.k>8)
            throw logic_error("identity move invalid");
        for(int i=h[p]-1;i>=m.k;i--)a[q][h[q]++]=a[p][i];
        h[p]=m.k;
        for(int v:{p,q})while(h[v]&&board_info.initial[a[v][h[v]-1]]==TowerBits(board_info.nest_code[v])){
            alive[a[v][h[v]-1]]=0;h[v]--;
        }
    }
};

struct Removal {
    vector<int> ids;
    double priority=0;
    uint64_t hash=0;
    int broken_support_jumps=0;
    int gross_removed=0;
    double rank_noise=1.0,rank_divisor=1.0;
    uint64_t score_generation=0;
};

// v078 immediate、120 epochの固定重み。低い出力の候補を選ぶ。
namespace neural_rank {
constexpr float mean[32]={0x1.03b9460000000p+4f,0x1.fc4b340000000p+2f,0x1.52f24a0000000p+6f,0x1.b552f20000000p+7f,0x1.8a2d2a0000000p-2f,0x1.0438240000000p+8f,0x1.041b8c0000000p+8f,0x1.c98b280000000p-4f,0x1.e71fa20000000p-2f,0x1.4c91620000000p+8f,0x1.b9d2ae0000000p+1f,0x1.ae1f640000000p-5f,0x1.d711800000000p+0f,0x1.828c380000000p-1f,0x1.c7d5e80000000p-2f,0x1.55ad540000000p+2f,0x1.f22c0e0000000p+0f,0x1.51b6040000000p+0f,0x1.19ee960000000p-1f,0x1.1600920000000p+0f,0x1.b086860000000p+3f,0x1.113d8a0000000p+4f,0x1.3b4a8a0000000p+3f,0x1.304f560000000p+2f,0x1.e2349a0000000p+2f,0x1.76e8880000000p-3f,0x1.cafb0a0000000p-1f,0x1.6d40e80000000p-1f,0x1.db8b5e0000000p-4f,0x1.84909e0000000p+3f,0x1.25b8c80000000p+2f,0x1.3f565e0000000p+0f};
constexpr float scale[32]={0x1.4527020000000p+1f,0x1.48a48e0000000p+1f,0x1.63a1c60000000p+5f,0x1.23c4500000000p+6f,0x1.29c1640000000p-3f,0x1.1fa4640000000p+7f,0x1.1fadae0000000p+7f,0x1.940fa80000000p-2f,0x1.1e27160000000p-2f,0x1.4b699e0000000p+9f,0x1.1570280000000p+1f,0x1.6a0ce20000000p-5f,0x1.016a100000000p+0f,0x1.02b4020000000p-2f,0x1.dc330c0000000p-2f,0x1.5a9e8c0000000p+2f,0x1.0ce50a0000000p+1f,0x1.9eef4a0000000p-1f,0x1.1adc8c0000000p-1f,0x1.00cc940000000p+0f,0x1.a45aaa0000000p+2f,0x1.0ae0ce0000000p+3f,0x1.908c980000000p+2f,0x1.25ef420000000p+2f,0x1.0157700000000p+3f,0x1.907ede0000000p-3f,0x1.10876a0000000p-3f,0x1.ec422e0000000p-3f,0x1.59ce480000000p-4f,0x1.82bece0000000p+2f,0x1.da31b20000000p+0f,0x1.a685f80000000p-1f};
constexpr float w1[16][32]={{0x1.ee49840000000p-3f,0x1.b0650e0000000p-4f,0x1.583d300000000p-4f,-0x1.b987a40000000p-4f,0x1.ab1be20000000p-3f,0x1.3427660000000p-2f,0x1.2e70860000000p-2f,0x1.0da3a80000000p-4f,0x1.38ea200000000p-7f,0x1.3715980000000p-3f,0x1.51819c0000000p-3f,-0x1.e904a80000000p-2f,-0x1.19a3de0000000p-2f,-0x1.e2d7d80000000p-4f,-0x1.ac0a160000000p-5f,-0x1.5c62660000000p-3f,-0x1.ae02000000000p-2f,0x1.b8e7a40000000p-3f,-0x1.82d38c0000000p-3f,0x1.946dd20000000p-2f,-0x1.ec35da0000000p-4f,0x1.c270600000000p-3f,-0x1.1bb37e0000000p-3f,0x1.8bd0500000000p-4f,0x1.a69bfe0000000p-6f,0x1.92637a0000000p-5f,-0x1.fa248c0000000p-4f,-0x1.01b9cc0000000p-2f,0x1.fb56940000000p-6f,0x1.7feb940000000p-4f,-0x1.ebd7c00000000p-4f,0x1.32be280000000p-4f},{-0x1.6f51140000000p-3f,-0x1.85775e0000000p-3f,0x1.2f6a3c0000000p-2f,0x1.3f05f40000000p-2f,0x1.4c0d480000000p-2f,0x1.431c0c0000000p-7f,-0x1.c837ca0000000p-5f,0x1.9719f80000000p-4f,-0x1.08fd520000000p-2f,-0x1.a170100000000p-6f,0x1.fda2ce0000000p-3f,0x1.5b14580000000p-3f,0x1.088b8e0000000p-4f,-0x1.2092660000000p-4f,-0x1.3792260000000p-4f,0x1.248dba0000000p-4f,-0x1.6ab7540000000p-4f,-0x1.2890100000000p-2f,-0x1.f60b580000000p-5f,-0x1.5a21520000000p-2f,-0x1.aff99a0000000p-3f,0x1.9cd1e00000000p-5f,-0x1.c88b020000000p-4f,0x1.5d80d00000000p-4f,-0x1.128ba20000000p-3f,-0x1.1376a60000000p-2f,-0x1.f59a840000000p-4f,-0x1.4eccae0000000p-6f,0x1.13add60000000p-3f,-0x1.3d7ce80000000p-3f,-0x1.bce8bc0000000p-3f,-0x1.df4aca0000000p-4f},{-0x1.b3cf9a0000000p-7f,0x1.2373720000000p-2f,-0x1.01e85a0000000p-2f,-0x1.5ee2380000000p-4f,0x1.1cd2060000000p-2f,0x1.0e21380000000p-3f,0x1.32a95e0000000p-2f,0x1.7188f00000000p-4f,0x1.db6f5a0000000p-5f,-0x1.25f5800000000p-3f,-0x1.2c80500000000p-4f,-0x1.2d385e0000000p-1f,-0x1.e21e760000000p-7f,-0x1.6054920000000p-3f,-0x1.061a020000000p-7f,-0x1.7f79d80000000p-4f,-0x1.a0a77e0000000p-4f,0x1.57e5440000000p-2f,0x1.d6c3da0000000p-5f,0x1.5270180000000p-2f,0x1.cd7d4c0000000p-6f,0x1.899c6a0000000p-5f,0x1.3bbbf20000000p-4f,-0x1.10cf060000000p-3f,-0x1.23a9c00000000p-2f,0x1.792cb20000000p-4f,0x1.165d120000000p-7f,0x1.88434c0000000p-3f,0x1.4fdf0a0000000p-4f,0x1.ca232c0000000p-4f,0x1.71af880000000p-2f,0x1.2813b20000000p-4f},{0x1.442af40000000p-5f,-0x1.085cc20000000p-2f,0x1.1cc35c0000000p-3f,-0x1.fc5fe40000000p-3f,-0x1.caae640000000p-3f,-0x1.8acec40000000p-6f,0x1.ea42d40000000p-6f,-0x1.68af560000000p-4f,-0x1.4bbba40000000p-3f,0x1.4276e60000000p-4f,0x1.50909a0000000p-3f,0x1.71dbf60000000p-3f,0x1.98fbdc0000000p-3f,-0x1.0b5a300000000p-3f,0x1.41f3100000000p-3f,-0x1.7dd90c0000000p-2f,-0x1.e531060000000p-4f,0x1.3726080000000p-7f,0x1.ce6b9c0000000p-3f,0x1.763f6c0000000p-5f,-0x1.4779c00000000p-4f,0x1.19b9e20000000p-2f,-0x1.8cc71a0000000p-2f,-0x1.9c87560000000p-4f,-0x1.8b0e0a0000000p-8f,0x1.cbe9d20000000p-5f,0x1.5050500000000p-2f,0x1.04211e0000000p-2f,0x1.5e20c00000000p-3f,-0x1.2d48ba0000000p-2f,0x1.883aee0000000p-3f,-0x1.9c07bc0000000p-3f},{-0x1.1b38800000000p-5f,-0x1.ce31c80000000p-3f,-0x1.527c6e0000000p-3f,-0x1.408ad80000000p-3f,-0x1.3bdb880000000p-4f,-0x1.ef5f780000000p-4f,0x1.2bf5a80000000p-3f,-0x1.7c22b60000000p-6f,-0x1.4aeac40000000p-2f,0x1.1e18ec0000000p-4f,-0x1.0b62360000000p-3f,-0x1.4cf4cc0000000p-2f,0x1.04c1e60000000p-2f,0x1.6336840000000p-3f,-0x1.34bad20000000p-3f,0x1.0d6ba20000000p-1f,0x1.1875da0000000p-1f,-0x1.afd3b20000000p-4f,-0x1.00068c0000000p-1f,0x1.69fd8c0000000p-3f,-0x1.26ccc20000000p-2f,-0x1.697faa0000000p-4f,-0x1.784df60000000p-3f,-0x1.1c24e60000000p-4f,-0x1.ee62b00000000p-5f,-0x1.6470140000000p-6f,0x1.02e0680000000p-4f,0x1.316e160000000p-6f,-0x1.1c52be0000000p-5f,-0x1.1563be0000000p-3f,0x1.0dd4ea0000000p-3f,-0x1.52cc840000000p-4f},{0x1.3581b00000000p-2f,0x1.e2c0a60000000p-3f,-0x1.9be9620000000p-3f,-0x1.767b780000000p-4f,0x1.6ec6cc0000000p-7f,0x1.e58e8e0000000p-4f,0x1.3c29640000000p-3f,0x1.d410380000000p-5f,0x1.42eadc0000000p-2f,0x1.5b39920000000p-2f,-0x1.138d560000000p-3f,-0x1.a909d00000000p-4f,-0x1.0a40140000000p-4f,-0x1.552be20000000p-4f,0x1.80cdee0000000p-6f,-0x1.23b6d60000000p-4f,-0x1.83bb760000000p-2f,0x1.c90c7a0000000p-2f,0x1.de55000000000p-3f,0x1.0e11f60000000p-3f,-0x1.1aa28a0000000p-2f,0x1.ca49d60000000p-4f,0x1.ed76c60000000p-4f,0x1.4131180000000p-2f,-0x1.6e3c5c0000000p-3f,-0x1.b1c7ce0000000p-6f,0x1.3c81c60000000p-3f,0x1.1c25060000000p-3f,-0x1.62eb560000000p-3f,-0x1.a05a660000000p-5f,-0x1.0b5eda0000000p-5f,-0x1.d8816c0000000p-4f},{0x1.0644640000000p-2f,0x1.47e13e0000000p-4f,-0x1.494b600000000p-6f,-0x1.9c1d3a0000000p-4f,0x1.c0b03a0000000p-7f,-0x1.d734240000000p-4f,0x1.7c83c00000000p-3f,0x1.0c4a460000000p-4f,0x1.0ae3600000000p-3f,-0x1.d076ee0000000p-4f,-0x1.1b69a60000000p+0f,-0x1.4f76f40000000p-2f,0x1.3c34140000000p-2f,0x1.f8bb5e0000000p-4f,0x1.66fe300000000p-5f,-0x1.3f20000000000p-2f,0x1.38b47a0000000p-4f,-0x1.de420c0000000p-3f,-0x1.50038a0000000p-6f,0x1.95592e0000000p-3f,-0x1.dadf7c0000000p-6f,-0x1.3d7c780000000p-3f,-0x1.25c4340000000p-5f,-0x1.3ae8c80000000p-4f,0x1.0748c00000000p-2f,-0x1.93846e0000000p-4f,0x1.5c67000000000p-6f,0x1.19c1000000000p-5f,-0x1.103c420000000p-2f,0x1.65dc540000000p-3f,0x1.c09c920000000p-5f,0x1.c4e8240000000p-6f},{0x1.0484000000000p-2f,-0x1.56db120000000p-8f,0x1.8138360000000p-3f,0x1.ba08300000000p-4f,0x1.45b0020000000p-2f,0x1.1766b00000000p-4f,-0x1.78d43c0000000p-4f,0x1.4106f00000000p-1f,-0x1.1f7dc00000000p-2f,-0x1.5c080c0000000p-3f,-0x1.bb6cdc0000000p-4f,-0x1.3556640000000p-5f,0x1.1b0f2a0000000p-4f,-0x1.0b20180000000p-5f,0x1.d77b7c0000000p-3f,0x1.f423e00000000p-3f,-0x1.47188a0000000p-4f,-0x1.108b7c0000000p-1f,0x1.29b0b00000000p-3f,-0x1.7640d80000000p-4f,0x1.2bfe660000000p-3f,0x1.4a435c0000000p-8f,0x1.191df00000000p-5f,-0x1.d34cb40000000p-5f,0x1.6e93980000000p-3f,0x1.35eb700000000p-2f,0x1.a048b00000000p-4f,0x1.2ce6100000000p-6f,0x1.712b580000000p-3f,0x1.1a9df40000000p-4f,0x1.c9fe6e0000000p-3f,0x1.429ff00000000p-5f},{0x1.6ca87e0000000p-2f,-0x1.4ca4480000000p-4f,-0x1.e329960000000p-5f,-0x1.7dbf9c0000000p-4f,0x1.4e0b100000000p-3f,0x1.fbf7ee0000000p-3f,0x1.aaddc20000000p-3f,0x1.1e65a40000000p-6f,0x1.5a1f0e0000000p-3f,0x1.d7dab80000000p-4f,0x1.402dea0000000p-5f,-0x1.5a50e00000000p-3f,-0x1.e6f9260000000p-4f,-0x1.a361520000000p-5f,0x1.979e300000000p-4f,0x1.59f6120000000p-4f,0x1.9443d40000000p-3f,0x1.33431c0000000p-1f,-0x1.1cee0e0000000p-4f,0x1.66f81e0000000p-3f,0x1.11c75a0000000p-3f,-0x1.9f71980000000p-3f,-0x1.de61da0000000p-3f,0x1.92a3b60000000p-4f,0x1.181d8e0000000p-2f,-0x1.1b69ba0000000p-1f,0x1.90dc800000000p-4f,0x1.fd1c680000000p-3f,0x1.c0971a0000000p-3f,0x1.e1ab420000000p-3f,0x1.7a71960000000p-3f,0x1.40c0200000000p-4f},{0x1.8586400000000p-3f,0x1.cc23260000000p-5f,-0x1.0ae7b00000000p-3f,-0x1.6b93540000000p-9f,0x1.2da7940000000p-3f,-0x1.2562f00000000p-3f,0x1.110ca00000000p-4f,0x1.51e3ee0000000p-2f,0x1.2ed0080000000p-3f,-0x1.bb57b00000000p-4f,0x1.2de1500000000p-1f,-0x1.cfcef80000000p-3f,-0x1.d811940000000p-4f,-0x1.badf640000000p-3f,-0x1.7b8f220000000p-5f,0x1.92866c0000000p-3f,0x1.9bb1420000000p-1f,-0x1.8e22a40000000p-4f,0x1.5167ba0000000p-5f,0x1.282ff00000000p-3f,0x1.53ce7e0000000p-4f,-0x1.2711900000000p-3f,-0x1.d9c1260000000p-4f,0x1.18169e0000000p-3f,0x1.16d72c0000000p-6f,-0x1.8813ea0000000p-11f,-0x1.4fe6a40000000p-5f,-0x1.2575c00000000p-3f,-0x1.696f5a0000000p-3f,0x1.64e54e0000000p-3f,0x1.d0c80c0000000p-5f,-0x1.c2a0b60000000p-8f},{-0x1.058aa20000000p-2f,0x1.e37f4c0000000p-4f,0x1.8aaf580000000p-3f,-0x1.11a9800000000p-3f,-0x1.ae26680000000p-3f,-0x1.f9769a0000000p-9f,0x1.faaea20000000p-6f,-0x1.33d50c0000000p-4f,-0x1.98a6ee0000000p-3f,-0x1.06a1ec0000000p-2f,0x1.248bb20000000p-4f,0x1.5efb540000000p-2f,0x1.d255aa0000000p-8f,-0x1.d335600000000p-6f,-0x1.4f6b140000000p-6f,-0x1.d632060000000p-5f,-0x1.b3d6dc0000000p-2f,0x1.1e24b00000000p-1f,0x1.72175a0000000p-2f,0x1.7aef760000000p-2f,0x1.f397080000000p-5f,0x1.c3d8d20000000p-4f,0x1.8d05160000000p-4f,-0x1.bee8660000000p-6f,0x1.1064a80000000p-5f,-0x1.7ef6300000000p-4f,0x1.fbf3f40000000p-10f,-0x1.5d2fe20000000p-6f,-0x1.3460c60000000p-2f,-0x1.9bf8f80000000p-2f,0x1.5cc9760000000p-4f,-0x1.a180640000000p-4f},{-0x1.d4adf40000000p-5f,0x1.64f66e0000000p-5f,0x1.824aea0000000p-4f,0x1.bebd3a0000000p-2f,0x1.e9a28e0000000p-2f,-0x1.3cef340000000p-2f,-0x1.4328da0000000p-2f,0x1.f970a20000000p-4f,0x1.3023ca0000000p-3f,0x1.d0748a0000000p-2f,0x1.f4b9f60000000p-3f,-0x1.47b8f80000000p-4f,-0x1.f9e7c40000000p-5f,0x1.a1bd780000000p-5f,-0x1.39eaae0000000p-5f,0x1.69001c0000000p-3f,-0x1.5764240000000p-3f,-0x1.dfc0dc0000000p-2f,-0x1.434c980000000p-2f,-0x1.7ebe3e0000000p-5f,0x1.306a400000000p-2f,0x1.26b0940000000p-3f,-0x1.b8be3a0000000p-5f,-0x1.2697580000000p-3f,-0x1.d8109e0000000p-8f,-0x1.6368900000000p-8f,-0x1.084b100000000p-6f,0x1.7044760000000p-6f,0x1.026a5e0000000p-3f,-0x1.c28a600000000p-3f,0x1.0b47440000000p-3f,-0x1.211dda0000000p-3f},{0x1.42f0660000000p-2f,-0x1.60f7cc0000000p-5f,0x1.1cc0c80000000p-3f,0x1.614c9a0000000p-4f,0x1.5718be0000000p-4f,0x1.362bd60000000p-4f,-0x1.1dcc4c0000000p-3f,0x1.d26c9a0000000p-4f,0x1.04996a0000000p-2f,0x1.a0b4f20000000p-6f,-0x1.fb99c60000000p-4f,-0x1.616af40000000p-3f,0x1.13e4bc0000000p-2f,0x1.c0f0f80000000p-4f,0x1.8cc9280000000p-4f,0x1.b21a500000000p-3f,0x1.a5c5240000000p-4f,-0x1.82de220000000p-7f,-0x1.f78dbe0000000p-4f,0x1.c6727c0000000p-3f,-0x1.26f92e0000000p-4f,0x1.f742d80000000p-4f,0x1.16efd80000000p-6f,-0x1.5c52fc0000000p-7f,-0x1.42e8260000000p-4f,0x1.f9ec900000000p-3f,-0x1.049d6e0000000p-4f,-0x1.b15dfc0000000p-3f,-0x1.596f500000000p-1f,0x1.9675300000000p-4f,0x1.56e0ba0000000p-3f,0x1.981ac20000000p-9f},{-0x1.2e57dc0000000p-3f,-0x1.8b05960000000p-5f,0x1.ef13600000000p-6f,-0x1.59a1c20000000p-4f,-0x1.6dae1c0000000p-5f,0x1.b85ed80000000p-5f,0x1.7bca100000000p-3f,0x1.dbc5ce0000000p-3f,-0x1.acb10e0000000p-2f,0x1.53c5e00000000p-2f,0x1.9ed7520000000p-2f,0x1.5d8b320000000p-2f,0x1.5047340000000p-6f,-0x1.fe53160000000p-4f,0x1.067fa00000000p-3f,0x1.ccaa740000000p-3f,0x1.fbcb480000000p-2f,0x1.a3f6f00000000p-4f,0x1.1b647e0000000p-4f,-0x1.ff92e80000000p-5f,-0x1.142c300000000p-2f,0x1.2502220000000p-3f,-0x1.487fa80000000p-3f,0x1.9a25220000000p-4f,0x1.76fbb80000000p-2f,-0x1.11b88c0000000p-3f,0x1.7ee3a60000000p-8f,-0x1.65b5680000000p-8f,-0x1.ee1f280000000p-5f,0x1.11a7400000000p-5f,0x1.8d8fee0000000p-4f,0x1.b4903c0000000p-7f},{0x1.6760760000000p-7f,-0x1.6307200000000p-2f,-0x1.272c3c0000000p-5f,-0x1.533f720000000p-4f,-0x1.91e07e0000000p-3f,0x1.ec58940000000p-2f,0x1.33fa9e0000000p-2f,0x1.b6ca9e0000000p-5f,-0x1.40083e0000000p-3f,0x1.f5f5980000000p-4f,0x1.4a8e4a0000000p-5f,0x1.b29ab00000000p-3f,-0x1.8efdba0000000p-4f,0x1.ce2cd00000000p-6f,-0x1.0653700000000p-3f,0x1.1d1dce0000000p-4f,0x1.57f4900000000p-2f,-0x1.31ffa40000000p-4f,-0x1.87c7c80000000p-3f,-0x1.ea09f80000000p-4f,-0x1.ac0a6e0000000p-6f,0x1.02f6ec0000000p-3f,0x1.27d7de0000000p-3f,0x1.19ff8c0000000p-3f,0x1.d443d60000000p-5f,-0x1.f88b460000000p-4f,0x1.3014fc0000000p-3f,-0x1.5886440000000p-4f,-0x1.c950c80000000p-2f,-0x1.f9b1f80000000p-2f,-0x1.6247560000000p-5f,-0x1.6e0c020000000p-4f},{0x1.91926e0000000p-3f,-0x1.76d2ba0000000p-5f,-0x1.1501fa0000000p-2f,0x1.5a71a60000000p-3f,0x1.4d9c520000000p-2f,0x1.0336e20000000p-3f,0x1.682e640000000p-3f,-0x1.3a65020000000p-4f,0x1.426ed00000000p-2f,-0x1.14ac2e0000000p-3f,0x1.62c4b40000000p-4f,-0x1.c90be00000000p-3f,-0x1.11e38c0000000p-3f,-0x1.6528800000000p-3f,0x1.3d6d740000000p-4f,-0x1.ee0ee20000000p-2f,-0x1.4cec020000000p-2f,0x1.c42c140000000p-3f,0x1.984f4a0000000p-3f,0x1.5b00ee0000000p-3f,-0x1.26a2000000000p-3f,-0x1.12453a0000000p-2f,0x1.cf82560000000p-7f,0x1.f358540000000p-4f,0x1.5dc82e0000000p-3f,0x1.0f1aea0000000p-5f,0x1.8e3bd80000000p-7f,-0x1.ba90120000000p-4f,0x1.f9adf20000000p-4f,-0x1.cbfa400000000p-7f,0x1.0fd1ea0000000p-4f,-0x1.a408320000000p-7f}};
constexpr float b1[16]={0x1.a7008e0000000p-4f,0x1.0968300000000p-3f,0x1.a17d0e0000000p-2f,-0x1.297f2c0000000p-2f,0x1.63bba20000000p-6f,0x1.299f7e0000000p-2f,-0x1.c67a640000000p-1f,0x1.34ec2c0000000p-2f,-0x1.f47b220000000p-4f,-0x1.0f76980000000p-2f,0x1.3491620000000p-1f,0x1.48caca0000000p-4f,-0x1.26d02c0000000p-2f,-0x1.ed40a20000000p-2f,-0x1.59e1080000000p-3f,-0x1.24dad80000000p-5f};
constexpr float w2[16]={-0x1.a57ff00000000p-2f,0x1.091da60000000p-2f,-0x1.ca0d480000000p-2f,0x1.5575be0000000p-2f,-0x1.f118cc0000000p-2f,-0x1.f48c4a0000000p-2f,0x1.2572860000000p+0f,0x1.bc2d260000000p-2f,0x1.527eac0000000p-2f,0x1.9dc2d20000000p-1f,0x1.6a9b960000000p-1f,0x1.104ae00000000p-1f,0x1.021f880000000p-1f,-0x1.52c99e0000000p-1f,0x1.d19cd40000000p-2f,-0x1.32af3e0000000p-1f};
constexpr float b2[1]={0x1.11cbd40000000p-8f};
float predict(const array<double,32>& raw) {
    array<float,32> x;
    // 学習時と同じく、rawをfloat32へ丸めてから正規化する。
    for(int j=0;j<32;j++)x[j]=(float(raw[j])-mean[j])/scale[j];
    float answer=b2[0];
    for(int i=0;i<16;i++){
        float value=b1[i];
        for(int j=0;j<32;j++)value+=w1[i][j]*x[j];
        answer+=w2[i]*max(0.0f,value);
    }
    return answer;
}
}
#ifdef LOCAL
struct NeuralRankStats {
    int64_t calls=0,scored=0,changed=0,rank_sum=0;
    double feature_ms=0,inference_ms=0,total_ms=0;
    void summary() const {
        trace.count_by("nn_calls",calls);trace.count_by("nn_candidates_scored",scored);
        trace.count_by("nn_changed_choices",changed);trace.count_by("nn_selected_original_rank_sum",rank_sum);
        trace.add_time_ms("nn_features",feature_ms);trace.add_time_ms("nn_inference",inference_ms);
        trace.add_time_ms("nn_selection",total_ms);
    }
} local_nn;
#endif

class TemporalLNS {
#ifdef AHC072_NN_PROBE
    friend struct NeuralRankProbe;
#endif
    // 候補の索引を再利用する。世代番号で初期化し、候補ごとの要素確保・解放を避ける。
    class EpochIndex {
        struct Slot {uint64_t key=0;int value=0;uint32_t epoch=0;};
        vector<Slot> table;
        uint32_t epoch=0;
        static uint64_t hash(uint64_t x) {
            x^=x>>30;x*=0xbf58476d1ce4e5b9ULL;x^=x>>27;x*=0x94d049bb133111ebULL;return x^(x>>31);
        }
    public:
        void reset(size_t expected) {
            size_t n=16;while(n<expected*2+16)n<<=1;
            if(table.size()<n){table.assign(n,Slot{});epoch=0;}
            if(++epoch==0){for(auto& e:table)e.epoch=0;epoch=1;}
        }
        pair<int,bool> put(uint64_t key,int value) {
            size_t at=hash(key)&(table.size()-1);
            while(table[at].epoch==epoch) {
                if(table[at].key==key)return {table[at].value,false};
                at=(at+1)&(table.size()-1);
            }
            table[at]={key,value,epoch};return {value,true};
        }
    } build_seen,build_packets,build_patterns;
    struct Pattern {array<int16_t,8> ids{};int n=0;vector<int> times;};
    vector<Pattern> pattern_buffer;
    vector<int> pattern_anchors[max_cells];
    vector<array<int16_t,8>> cut_ids;

    struct Link {int previous,time;Move move;bool extra;};
    struct Label {
        int cost=infinite_cost,bonus=-1000000,path=-1;
    };
    // 同じ予定時刻の空間探索。費用の小さい順に確定し、同費用では補助評価だけを更新する。
    class SpatialQueue {
        struct Item {int state,next;};
        vector<int> head;
        // 上位を世代、下位を待機費用に使う。各時刻の初期化を費用桶の数に抑える。
        vector<uint64_t> queued;
        vector<Item> nodes;
        uint32_t epoch=0;
        int low=infinite_cost;
    public:
        void prepare(int states) {
            if(int(queued.size())<states)queued.resize(states,0);
            if(nodes.capacity()<size_t(states)*2)nodes.reserve(size_t(states)*2);
        }
        void reset(int cap) {
            if(++epoch==0){fill(queued.begin(),queued.end(),0);epoch=1;}
            head.assign(max(1,cap+1),-1);nodes.clear();low=infinite_cost;
        }
        void push(int state,int cost) {
            if(cost<0||cost>=int(head.size()))return;
            uint64_t tag=(uint64_t(epoch)<<32)|uint32_t(cost);
            if(queued[state]==tag)return;
            queued[state]=tag;
            nodes.push_back({state,head[cost]});head[cost]=int(nodes.size())-1;
            low=min(low,cost);
        }
        bool pop(int ceiling,int &state,int &cost) {
            while(low<=ceiling&&low<int(head.size())&&head[low]<0)++low;
            if(low>ceiling||low>=int(head.size()))return false;
            int id=head[low];head[low]=nodes[id].next;
            state=nodes[id].state;cost=low;return true;
        }
    } small_queue,packet_queue;
    vector<Label> small_labels,packet_labels;
    vector<array<Label,8>> packet_from_p,packet_from_q;
    static constexpr int CHECKPOINT=16;
    vector<IdentityState> checkpoints;
    struct Flight {array<int16_t,8> id{};uint8_t n=0;};
    // 下段の個体は複数の便を支え得る。slack匹までなら失ってもそのジャンプは成立する。
    struct SupportUse {Flight lower;int time,slack;};
    struct PacketCut {
        int time=-1,keep=0,size=0,saved=0;
        uint64_t hash=0;
        double priority=0;
        bool later=false,before_split=false;
    };
    vector<Flight> flights;
    vector<SupportUse> support_uses;
    vector<PacketCut> packet_cuts;
    vector<PacketCut> later_cuts;
    vector<vector<int>> spatial_cuts;
    vector<Link> links;
    vector<Removal> candidates;
    unordered_map<uint64_t,int> last_tried;
    int iteration=0;
    int regular_selections=0;
#ifdef LOCAL
    friend struct DependencyProbe;
    bool local_dependency_extract=false;
#endif
    int support_weight=5,ride_weight=1;
    double lns_start=0;
    vector<Move> current;
    int stagnant=0;
    bool initialized=false;
    double active_seconds=0;
    uint64_t trajectory_generation=1,history_generation=0,packet_generation=0;
    int candidate_age=4;
    static constexpr int candidate_refresh_interval=4;
    void trajectory_changed() {
        ++candidate_age;
        if(++trajectory_generation==0) {
            trajectory_generation=1;history_generation=packet_generation=0;
            for(auto& c:candidates)c.score_generation=0;
            candidate_age=candidate_refresh_interval;
        }
    }
    // These histories are correctness-critical. They may never refer to an older
    // move sequence, even when the heuristic nomination order is reused.
    void refresh_history(const vector<Move>& answer) {
        flights.clear();support_uses.clear();checkpoints.clear();
        flights.reserve(answer.size());checkpoints.reserve((answer.size()+CHECKPOINT-1)/CHECKPOINT);
        IdentityState board;
        for(int t=0;t<int(answer.size());t++) {
            if((t&127)==0)time_keeper.check();
            if(t%CHECKPOINT==0)checkpoints.push_back(board);
            const Move m=answer[t];Flight flight;
            for(int i=m.k;i<board.h[m.p];i++)flight.id[flight.n++]=board.a[m.p][i];
            flights.push_back(flight);
            if(m.l>1) {
                SupportUse use{{},t,int(m.k)+1-int(m.l)};
                for(int i=0;i<m.k;i++)use.lower.id[use.lower.n++]=board.a[m.p][i];
                support_uses.push_back(use);
            }
            board.apply(m);
        }
        history_generation=trajectory_generation;++history_only_builds;
    }
    void ensure_history(const vector<Move>& answer) {
        if(history_generation==trajectory_generation)return;
        const double begin=time_keeper.exact_elapsed_sec();
        refresh_history(answer);
        const double duration=time_keeper.exact_elapsed_sec()-begin;
        build_seconds+=duration;history_only_seconds+=duration;
    }
    void ensure_packets(const vector<Move>& answer) {
        if(packet_generation==trajectory_generation)return;
        const double begin=time_keeper.exact_elapsed_sec();
        make_candidates(answer,false);
        const double duration=time_keeper.exact_elapsed_sec()-begin;
        build_seconds+=duration;packet_only_seconds+=duration;
    }
    void rebuild_all(const vector<Move>& answer) {
        const double begin=time_keeper.exact_elapsed_sec();
        make_candidates(answer,true);
        const double duration=time_keeper.exact_elapsed_sec()-begin;
        build_seconds+=duration;full_build_seconds+=duration;
    }
    void refresh_regular_score(Removal& c) {
        if(c.score_generation==trajectory_generation)return;
        assert(history_generation==trajectory_generation);
        c.gross_removed=removed_commands(c.ids);
        c.broken_support_jumps=broken_support_jumps_value(c.ids);
        c.priority=(c.gross_removed-repair_weight*c.broken_support_jumps+0.25)/c.rank_divisor*c.rank_noise;
        c.score_generation=trajectory_generation;++score_refreshes;
    }
    // 支持不足になる残存便を数える。修復負担の代理値であり、追加手数の下界ではない。
    int broken_support_jumps_value(const vector<int>& ids) const {
        array<bool,max_cells> removed{};
        for(int id:ids)removed[id]=true;
        int broken=0;
        for(const auto& use:support_uses) {
            int lost=0;
            for(int j=0;j<use.lower.n;j++)lost+=removed[use.lower.id[j]];
            if(lost<=use.slack)continue;
            const auto& flight=flights[use.time];
            for(int j=0;j<flight.n;j++)if(!removed[flight.id[j]]){++broken;break;}
        }
        return broken;
    }
    // 壊れる便の乗客を除去集合へ追加し、最大8匹まで依存を追う。
    int grow_dependency(Removal& cand) const {
        if(cand.ids.size()>=8)return 0;
        array<bool,max_cells> removed{};
        for(int id:cand.ids)removed[id]=true;
        int rounds=0;
        while(cand.ids.size()<8) {
            int chosen=-1,best_added=9,best_length=-1;
            for(int i=0;i<int(support_uses.size());i++) {
                const auto& use=support_uses[i];
                int lost=0;
                for(int j=0;j<use.lower.n;j++)lost+=removed[use.lower.id[j]];
                if(lost<=use.slack)continue;
                const auto& flight=flights[use.time];
                int added=0;
                for(int j=0;j<flight.n;j++)added+=!removed[flight.id[j]];
                if(!added||cand.ids.size()+added>8)continue;
                const int length=int(use.lower.n)+1-use.slack;
                if(added<best_added||(added==best_added&&length>best_length)) {
                    chosen=i;best_added=added;best_length=length;
                }
            }
            if(chosen<0)break;
            const auto& flight=flights[support_uses[chosen].time];
            for(int j=0;j<flight.n;j++)if(!removed[flight.id[j]]) {
                removed[flight.id[j]]=true;cand.ids.push_back(flight.id[j]);
            }
            ++rounds;
        }
        if(rounds) {
            sort(cand.ids.begin(),cand.ids.end());
            cand.hash=0x51ed270b3a4dc107ULL;
            for(int id:cand.ids)cand.hash=(cand.hash^(id+1))*0x9e3779b97f4a7c15ULL;
        }
        return rounds;
    }
// NN特徴にも使うため、提出ビルドでも有効にする。
    int removed_commands(const vector<int>& ids) const {
        array<bool,max_cells> removed{};for(int id:ids)removed[id]=true;
        int count=0;
        for(const auto& flight:flights) {
            bool all=true;
            for(int j=0;j<flight.n;j++)all&=removed[flight.id[j]];
            count+=all;
        }
        return count;
    }

    static bool better(int cost,int bonus,const Label& b) {
        return cost<b.cost||(cost==b.cost&&bonus>b.bonus);
    }
    // Gaps at the two sides of a background slime of color_code yield the
    // same physical tower. Transitivity holds only through consecutive equal
    // colors; it must NOT cross a differently colored slime. A copied path is
    // valid because its entire colored board, not merely the multiset, agrees.
    // At event boundaries all gaps matter. Between events only the top gap
    // can make an extra move, so promoting that representative is sufficient.
    void close_color_gaps(int p,TowerBits word,int h,int color_code,bool top_only) {
        ++alias_closures;
        if(h==0||h>=8)return;
        Label* labels=small_labels.data()+8*p;
        if(top_only) {
            if(int((word>>(4*(h-1)))&15)!=color_code)return;
            int first=h-1;
            while(first>0&&int((word>>(4*(first-1)))&15)==color_code)--first;
            Label best=labels[h];
            for(int g=first;g<h;g++)if(better(labels[g].cost,labels[g].bonus,best))best=labels[g];
            if(better(best.cost,best.bonus,labels[h])) {
                alias_cost_relaxations+=best.cost<labels[h].cost;
                ++alias_top_relaxations;labels[h]=best;
            }
            return;
        }
        // Each nibble is independent: (d & 7)+7 has no carry into its next
        // nibble. A high bit is zero iff the original nibble was zero.
        const TowerBits diff=word^(0x11111111u*unsigned(color_code));
        TowerBits matches=~(((diff&0x77777777u)+0x77777777u)|diff)&0x88888888u;
        while(matches) {
            const int first=__builtin_ctz(matches)/4;
            int last=first+1;
            while(last<h&&int((word>>(4*last))&15)==color_code)++last;
            Label best=labels[first];
            for(int g=first+1;g<=last;g++)if(better(labels[g].cost,labels[g].bonus,best))best=labels[g];
            for(int g=first;g<=last;g++)if(better(best.cost,best.bonus,labels[g])) {
                alias_cost_relaxations+=best.cost<labels[g].cost;
                ++alias_gap_relaxations;labels[g]=best;
            }
            matches&=~tower_mask[last];
        }
    }

    // 元の段と匹数を保持する。背景へ同色で接触してもこの単位へ取り込まない。
    struct RunMember {int16_t source;uint8_t rank,shade,count;};
    static int append_runs(array<RunMember,8>& members,int n,TowerBits word,int source,int rank) {
        while(word) {
            const int shade=word&15;int count=0;
            do {++count;word>>=4;} while(word&&int(word&15)==shade);
            members[n++]={int16_t(source),uint8_t(rank),uint8_t(shade),uint8_t(count)};
            rank+=count;
        }
        return n;
    }
    static TowerBits run_word(const RunMember& m) {
        return prefix(0x11111111u*m.shade,m.count);
    }
    static TowerBits insert_run_word(TowerBits w,int gap,const RunMember& m) {
        // 上端が8段のときも、32 bit幅のシフトを避けて元の順序を復元する。
        const uint64_t upper=(uint64_t(w)>>(4*gap))<<(4*(gap+m.count));
        return TowerBits(prefix(w,gap)|(uint64_t(run_word(m))<<(4*gap))|upper);
    }
    int link(int prev,int time,Move m,bool extra) {
        links.push_back({prev,time,m,extra});return int(links.size())-1;
    }
    vector<Move> reconstruct(const vector<Move>& base,int ptr) const {
        vector<int> path;
        while(ptr>=0){path.push_back(ptr);ptr=links[ptr].previous;}
        reverse(path.begin(),path.end());
        vector<Move> out;out.reserve(base.size()+path.size());
        int j=0;
        for(int t=0;t<=int(base.size());t++) {
            while(j<int(path.size())&&links[path[j]].time==t&&links[path[j]].extra)
                out.push_back(links[path[j++]].move);
            if(t<int(base.size())) {
                if(j<int(path.size())&&links[path[j]].time==t&&!links[path[j]].extra)
                    out.push_back(links[path[j++]].move);
                else out.push_back(base[t]);
            }
        }
        if(j!=int(path.size()))throw logic_error("reinsertion chronology");
        return out;
    }

    // 個体の除去で壊れたジャンプを修復し、残存便の色順を保つ。露出した巣上の個体は先に帰巣できる。
    bool extract(const vector<Move>& original,const vector<int>& removed,
                 vector<Move>& base,State& initial) {
        IdentityState cur(removed);initial=cur.words();
        return extract_from(original,cur,0,base);
    }
    bool extract_from(const vector<Move>& original,IdentityState& cur,int start,
                     vector<Move>& base) {
        base.clear();base.reserve(original.size());
        for(int t=start;t<int(original.size());t++) {
            if((t&63)==0)time_keeper.check();
            Move m=original[t];int p=m.p,q=board_info.ray[p][m.d][m.l];
            array<int,8> flight;int take=0;
            for(int i=0;i<flights[t].n;i++) {
                int id=flights[t].id[i];if(cur.alive[id])flight[take++]=id;
            }
            if(take) {
                int keep=int(cur.h[p])-take;
                if(keep<0)return false;
                for(int i=0;i<take;i++)if(cur.a[p][keep+i]!=flight[i])return false;
                Move adjusted=m;adjusted.k=keep;
                if(m.l<=keep+1&&cur.h[q]+take<=8) {
                    cur.apply(adjusted);base.push_back(adjusted);
                }else {
                    State before=cur.words();PortionRouter rt;rt.run(before,p,keep,q);
                    TowerBits moving=before[p]>>(4*keep);bool mono=mono_color_code(moving)>0;
                    int orientation=1;
                    if(mono&&rt.cost(q,0)>=0&&(rt.cost(q,1)<0||rt.cost(q,0)<rt.cost(q,1)))orientation=0;
                    if(rt.cost(q,orientation)<0)return false;
                    auto path=rt.path(q,orientation);
                    LOCAL_NOTE(if(local_dependency_extract){
                        ++local_dependency.repaired_jumps;
                        local_dependency.repair_extra_commands+=int(path.size())-1;
                    })
                    for(auto z:path){cur.apply(z);base.push_back(z);}
                    if(mono&&orientation==0) {
                        // 同色の個体を交換し、後の分割で使うIDの割り当てを保つ。
                        bool all_alive=true;for(int i=0;i<take;i++)all_alive&=cur.alive[flight[i]];
                        if(all_alive) {
                            if(cur.h[q]<take)return false;
                            for(int i=0;i<take;i++)cur.a[q][cur.h[q]-take+i]=flight[take-1-i];
                        }
                    }
                }
                if(base.size()>original.size()-start+4)return false;
            }
        }
        for(int p=0;p<board_info.cell_count;p++)if(cur.h[p])return false;
        return true;
    }

    // 同費用なら、次の同色2便を1操作へまとめられる支持を優先する。
    // 短縮後に操作の合法性と境界の全盤面一致を検査する。
    static int shortcut_support_need(const State& b,const vector<Move>& base,int t,int q,int hq) {
        if(t+1>=int(base.size()))return infinite_cost;
        const Move& a=base[t];const Move& z=base[t+1];
        if(z.p!=q||z.d!=a.d||z.k!=hq)return infinite_cost;
        const int shade=mono_color_code(b[a.p]>>(4*a.k));
        if(shade<=0||board_info.nest_code[q]==shade)return infinite_cost;
        return max(1,int(a.l)+z.l-a.k-1);
    }

    // 固定した予定への1匹の再挿入。状態はマスと塔内の隙間で、追加移動は費用1、予定操作は費用0。
    // 同費用では同乗と踏み台の利用を優先する。
    bool insert_at(const State& initial,const vector<Move>& base,int source,int color_code,
                  int initial_gap,int cap,vector<Move>& result) {
        LOCAL_NOTE(++local_single_insert_calls;)
        if(cap<0||source<0||source>=board_info.cell_count)return false;
        int cell_count=board_info.cell_count,GOAL=8*cell_count,S=GOAL+1;
        State b=initial;
        if(height(b[source])>=8||initial_gap<0||initial_gap>height(b[source]))return false;
        // 初期の隙間を指定し、任意の挿入順から元の塔の積み順を復元する。
        small_labels.assign(S,Label());auto& label=small_labels;
        links.clear();links.reserve(32768);
        label[source*8+initial_gap]={0,0,-1};
        auto& queue=small_queue;queue.prepare(cell_count);queue.reset(cap);
        auto ceiling=[&](){return min(cap,label[GOAL].cost);};
        array<int,max_cells> h{};for(int p=0;p<cell_count;p++)h[p]=height(b[p]);
        auto seed=[&](int p) {
            if(p<0||h[p]>=8)return;
            int s=p*8+h[p];auto z=label[s];
            if(z.cost<=ceiling())queue.push(p,z.cost);
        };
        auto seed_neighborhood=[&](int p,bool changed) {
            seed(p);
            if(!changed)return;
            for(int d=0;d<4;d++)for(int l=1;l<=board_info.ray_count[p][d];l++) {
                int q=board_info.ray[p][d][l];
                if(h[q]<8&&l<=h[q]+1)seed(q);
            }
        };
        close_color_gaps(source,b[source],h[source],color_code,true);
        seed(source);
        for(int t=0;t<=int(base.size());t++) {
            if((t&31)==0)time_keeper.check();
            int pops=0,queued_position,queued_cost;
            while(queue.pop(ceiling(),queued_position,queued_cost)) {
                int p=queued_position,s=p*8+h[p];
                Label at=label[s];
                if(at.cost!=queued_cost||h[p]>=8)continue;
                if(at.cost>=ceiling())continue;
                int next_cost=at.cost+1;
                for(int d=0;d<4;d++)for(int l=1,far=min(h[p]+1,int(board_info.ray_count[p][d]));l<=far;l++) {
                    int q=board_info.ray[p][d][l];
                    if(h[q]>=8)continue;
                    int ns=board_info.nest_code[q]==color_code?GOAL:q*8+h[q];
                    if(better(next_cost,at.bonus,label[ns])) {
                        Move m={int16_t(p),uint8_t(h[p]),uint8_t(d),uint8_t(l)};
                        int ptr=link(at.path,t,m,true);
                        label[ns]={next_cost,at.bonus,ptr};
                        if(ns!=GOAL)queue.push(q,next_cost);
                    }
                }
                if((++pops&1023)==0)time_keeper.check();
            }
            if(t==int(base.size()))break;
            queue.reset(ceiling());
            Move m=base[t];int p=m.p,q=board_info.ray[p][m.d][m.l];
            int hp=h[p],hq=h[q];
            const int support_need=support_weight?shortcut_support_need(b,base,t,q,hq):infinite_cost;
            close_color_gaps(p,b[p],hp,color_code,false);
            close_color_gaps(q,b[q],hq,color_code,false);
            array<Label,8> from_p,from_q;
            for(int g=0;g<8;g++) {
                from_p[g]=label[p*8+g];from_q[g]=label[q*8+g];
                label[p*8+g]=Label();label[q*8+g]=Label();
            }
            board_info.apply(b,m);h[p]=height(b[p]);h[q]=height(b[q]);
            // 追加個体が帰巣へ影響するのは、残る背景の最上段以上にいる場合だけ。
            // 位置を式で求め、各隙間での塔の再構築を省く。容量は帰巣前の高さで判定する。
            auto transition=[&](int location,int gap,int added_keep,const Label& at) {
                if(at.cost>ceiling())return;
                const bool held=location==p&&added_keep;
                if(!held&&hq+hp-m.k+1>8)return;
                const int tag_cell=held?p:q;
                const int tag_index=location==p&&!held?hq+hp-gap:gap;
                const bool gone=board_info.nest_code[tag_cell]==color_code&&tag_index>=h[tag_cell];
                int bonus=at.bonus;
                if(location==p)bonus+=held?support_weight:ride_weight;
                if(held&&support_need<=1)bonus+=3*support_weight;
                LOCAL_NOTE(local_shortcut_support_states += held && support_need <= 1;)
                Move adjusted=m;adjusted.k+=added_keep;
                if(gone||tag_index<=h[tag_cell]) {
                    const int ns=gone?GOAL:tag_cell*8+tag_index;
                    if(!gone&&h[tag_cell]>=8)return;
                    if(better(at.cost,bonus,label[ns])) {
                        int ptr=at.path;
                        if(added_keep)ptr=link(ptr,t,adjusted,false);
                        label[ns]={at.cost,bonus,ptr};
                    }
                }else if(at.cost<ceiling()) {
                    // 背景の帰巣を止める異色の追加個体は、即座に出発すれば予定を復元でき、下段も支持に使える。
                    const int keep=tag_index,new_cost=at.cost+1;
                    const int nb=bonus+3*keep;
                    int ptr=at.path;
                    if(added_keep)ptr=link(ptr,t,adjusted,false);
                    for(int d=0;d<4;d++)for(int l=1,far=min(keep+1,int(board_info.ray_count[tag_cell][d]));l<=far;l++) {
                        const int dest=board_info.ray[tag_cell][d][l];
                        if(h[dest]>=8)continue;
                        const int ns=board_info.nest_code[dest]==color_code?GOAL:dest*8+h[dest];
                        if(!better(new_cost,nb,label[ns]))continue;
                        Move escape={int16_t(tag_cell),uint8_t(keep),uint8_t(d),uint8_t(l)};
                        int np=link(ptr,t+1,escape,true);
                        label[ns]={new_cost,nb,np};
                        if(ns!=GOAL)queue.push(dest,new_cost);
                    }
                }
            };
            if(hp<8)for(int g=0;g<=hp;g++) {
                if(g>=m.k)transition(p,g,0,from_p[g]);
                if(g<=m.k)transition(p,g,1,from_p[g]);
            }
            if(hq<8)for(int g=0;g<=hq;g++)transition(q,g,0,from_q[g]);
            close_color_gaps(p,b[p],h[p],color_code,true);
            close_color_gaps(q,b[q],h[q],color_code,true);
            // 変更された2マスとそこへ入る辺を開き直す。巣の帰巣で最上段の状態が悪化した場合は、
            // 高さが同じでも再探索が必要。他の状態はそのまま待機できる。
            bool reopen_p=h[p]!=hp,reopen_q=h[q]!=hq;
            if(hp<8&&!reopen_p)reopen_p=better(from_p[hp].cost,from_p[hp].bonus,label[p*8+hp]);
            if(hq<8&&!reopen_q)reopen_q=better(from_q[hq].cost,from_q[hq].bonus,label[q*8+hq]);
            LOCAL_NOTE(++local_event_layers; local_event_reopens += reopen_p + reopen_q;)
            seed_neighborhood(p,reopen_p);seed_neighborhood(q,reopen_q);
        }
        if(label[GOAL].cost>cap)return false;
        result=reconstruct(base,label[GOAL].path);
        if(int(result.size())!=int(base.size())+label[GOAL].cost)
            throw logic_error("reinsertion cost mismatch");
        return true;
    }

    bool insert(const State& initial,const vector<Move>& base,int token,int cap,
                vector<Move>& result) {
        if(initial[token])throw logic_error("insertion initial cell occupied");
        return insert_at(initial,base,token,int(board_info.initial[token]),0,cap,result);
    }

    // 第2順序では先頭2匹だけを交換する。後続の個体は、それぞれで作られた経路へ挿入する。
    bool insert_two_orders(const State& initial,const vector<Move>& base,
                         const vector<pair<double,int>>& order,int allowance,
                         vector<Move>& result) {
        const int n=int(order.size());assert(2<=n&&n<=4);
        LOCAL_NOTE(
            ++local_two_order.attempts;++local_two_order.sizes[n];
            local_two_order_alternate=false;
        )
        int best_length_value=allowance+1;
        for(int branch=0;branch<2;branch++) {
            LOCAL_NOTE(++local_two_order.started[branch];TwoOrderTimer timer(branch);)
            State restored=initial;vector<Move> tail=base;bool ok=true;
            for(int j=0;j<n;j++) {
                time_keeper.check();
                const int at=branch&&j<2?1-j:j,id=order[at].second;
                vector<Move> next;
                // 挿入では操作数が増えるため、完成済みの解より短くならない第2順序を枝刈りする。
                const int cap=min(allowance,best_length_value-1)-int(tail.size());
                LOCAL_NOTE(++local_two_order.insert_calls[branch];)
                if(!insert(restored,tail,id,cap,next)){ok=false;break;}
                ++insertions;tail=move(next);restored[id]=board_info.initial[id];
            }
            if(!ok){LOCAL_NOTE(++local_two_order.failed[branch];)continue;}
            LOCAL_NOTE(
                ++local_two_order.finished[branch];
                if(branch) {
                    ++local_two_order.alternate_selected;local_two_order_alternate=true;
                    if(best_length_value<=allowance) {
                        ++local_two_order.shorter;
                        local_two_order.raw_saved+=best_length_value-int(tail.size());
                    }else ++local_two_order.rescued;
                }
            )
            best_length_value=int(tail.size());result=move(tail);
        }
        const bool ok=best_length_value<=allowance;
        LOCAL_NOTE(local_two_order.completed+=ok;)
        return ok;
    }

    // 連続した束を一単位で再挿入する。状態は上下反転と最上段の帰巣で到達する列だけに絞る。
    bool insert_packet(const State& initial,const vector<Move>& base,int source,
                      TowerBits packet,int cap,vector<Move>& result,int initial_gap=-1) {
        LOCAL_NOTE(++local_packet_insert_calls;)
        if(cap<0||!packet)return false;
        vector<TowerBits> words;unordered_map<TowerBits,int> index;
        auto add_word=[&](TowerBits w) {
            if(!w||index.count(w))return;
            int id=words.size();index.emplace(w,id);words.push_back(w);
        };
        add_word(packet);
        for(int i=0;i<int(words.size());i++) {
            TowerBits w=words[i];add_word(reverse_tower(w));
            add_word(board_info.normalize(w,board_info.nest_pos_by_code[top_color_code(w)]));
        }
        int W=words.size(),cell_count=board_info.cell_count,stride=cell_count*8,GOAL=W*stride;
        vector<int> sz(W),rev(W);vector<array<int,13>> trimmed(W);
        for(int i=0;i<W;i++) {
            sz[i]=height(words[i]);rev[i]=index.at(reverse_tower(words[i]));
            for(int current_code=0;current_code<=board_info.K;current_code++) {
                TowerBits w=current_code?board_info.normalize(words[i],board_info.nest_pos_by_code[current_code]):words[i];
                trimmed[i][current_code]=w?index.at(w):-1;
            }
        }
        State b=initial;array<int,max_cells> h{};
        for(int p=0;p<cell_count;p++)h[p]=height(b[p]);
        if(h[source]+height(packet)>8||board_info.normalize(b[source],source)!=b[source])return false;
        packet_labels.assign(GOAL+1,Label());auto& labels=packet_labels;
        // 途中再構築では元の段順を保つため、既に戻した塊の下にも挿入する。
        const int gap=initial_gap<0?h[source]:initial_gap;
        if(gap>h[source])return false;
        labels[source*8+gap]={0,0,-1};
        links.clear();links.reserve(32768);
        auto& queue=packet_queue;queue.prepare(W*cell_count);queue.reset(cap);
        auto ceiling=[&](){return min(cap,labels[GOAL].cost);};
        auto seed=[&](int p) {
            if(p<0)return;
            for(int i=0;i<W;i++)if(h[p]+sz[i]<=8) {
                const Label& a=labels[i*stride+p*8+h[p]];
                if(a.cost<=ceiling())queue.push(i*cell_count+p,a.cost);
            }
        };
        auto seed_neighborhood=[&](int p,bool changed) {
            seed(p);if(!changed)return;
            for(int d=0;d<4;d++)for(int l=1;l<=8;l++) {
                int q=board_info.ray[p][d][l];if(q<0)break;
                if(l<=h[q]+1)seed(q);
            }
        };
        packet_from_p.resize(W);packet_from_q.resize(W);
        auto& from_p=packet_from_p;auto& from_q=packet_from_q;
        seed(source);
        for(int t=0;t<=int(base.size());t++) {
            if((t&15)==0)time_keeper.check();
            int state,queued_cost,pops=0;
            while(queue.pop(ceiling(),state,queued_cost)) {
                int i=state/cell_count,p=state%cell_count,n=sz[i];
                if(h[p]+n>8)continue;
                Label at=labels[i*stride+p*8+h[p]];
                if(at.cost!=queued_cost||at.cost>=ceiling())continue;
                int nc=at.cost+1,ri=rev[i];
                for(int d=0;d<4;d++)for(int l=1,far=min(h[p]+1,int(board_info.ray_count[p][d]));l<=far;l++) {
                    int q=board_info.ray[p][d][l];
                    if(h[q]+n>8)continue;
                    int ni=trimmed[ri][board_info.nest_code[q]];
                    int ns=ni<0?GOAL:ni*stride+q*8+h[q];
                    if(!better(nc,at.bonus,labels[ns]))continue;
                    Move m={int16_t(p),uint8_t(h[p]),uint8_t(d),uint8_t(l)};
                    labels[ns]={nc,at.bonus,link(at.path,t,m,true)};
                    if(ni>=0)queue.push(ni*cell_count+q,nc);
                }
                if((++pops&2047)==0)time_keeper.check();
            }
            if(t==int(base.size()))break;
            queue.reset(ceiling());
            Move m=base[t];int p=m.p,q=board_info.ray[p][m.d][m.l];
            int hp=h[p],hq=h[q];
            const int support_need=support_weight?shortcut_support_need(b,base,t,q,hq):infinite_cost;
            for(int i=0;i<W;i++)for(int g=0;g<8;g++) {
                from_p[i][g]=labels[i*stride+p*8+g];
                from_q[i][g]=labels[i*stride+q*8+g];
                labels[i*stride+p*8+g]=Label();
                labels[i*stride+q*8+g]=Label();
            }
            board_info.apply(b,m);h[p]=height(b[p]);h[q]=height(b[q]);
            auto transition=[&](int i,int location,int gap,bool retained,const Label& at) {
                if(at.cost>ceiling())return;
                const int n=sz[i];
                const bool held=location==p&&retained;
                if(!held&&hq+hp-m.k+n>8)return;
                const int add=held?n:0;
                const int tag_cell=held?p:q;
                const int tag_index=location==p&&!held?hq+hp-gap:gap;
                const int wi=location==p&&!held?rev[i]:i;
                // 束の上に背景の異色があれば帰巣を止める。なければ束の最上段の同色部分だけを帰す。
                const int ni=tag_index<h[tag_cell]?wi:trimmed[wi][board_info.nest_code[tag_cell]];
                const int remain=ni<0?0:sz[ni];
                int bonus=at.bonus;
                if(location==p)bonus+=(held?support_weight:ride_weight)*n;
                if(held&&support_need<=n)bonus+=3*support_weight;
                LOCAL_NOTE(local_shortcut_support_states += held && support_need <= n;)
                Move adj=m;adj.k+=add;
                if(!remain||tag_index<=h[tag_cell]) {
                    const int ns=ni<0?GOAL:ni*stride+tag_cell*8+tag_index;
                    if(ni>=0&&h[tag_cell]+remain>8)return;
                    if(better(at.cost,bonus,labels[ns])) {
                        int ptr=at.path;if(add)ptr=link(ptr,t,adj,false);
                        labels[ns]={at.cost,bonus,ptr};
                    }
                }else if(at.cost<ceiling()) {
                    const int nc=at.cost+1,nb=bonus+3*tag_index;
                    int ptr=at.path;if(add)ptr=link(ptr,t,adj,false);
                    const int ri=rev[ni];
                    for(int d=0;d<4;d++)for(int l=1,far=min(tag_index+1,int(board_info.ray_count[tag_cell][d]));l<=far;l++) {
                        const int dest=board_info.ray[tag_cell][d][l];
                        if(h[dest]+remain>8)continue;
                        const int next=trimmed[ri][board_info.nest_code[dest]];
                        const int ns=next<0?GOAL:next*stride+dest*8+h[dest];
                        if(!better(nc,nb,labels[ns]))continue;
                        Move escape={int16_t(tag_cell),uint8_t(tag_index),uint8_t(d),uint8_t(l)};
                        labels[ns]={nc,nb,link(ptr,t+1,escape,true)};
                        if(next>=0)queue.push(next*cell_count+dest,nc);
                    }
                }
            };
            for(int i=0;i<W;i++) {
                if(hp+sz[i]<=8)for(int g=0;g<=hp;g++) {
                    if(g>=m.k)transition(i,p,g,false,from_p[i][g]);
                    if(g<=m.k)transition(i,p,g,true,from_p[i][g]);
                }
                if(hq+sz[i]<=8)for(int g=0;g<=hq;g++)transition(i,q,g,false,from_q[i][g]);
            }
            bool reopen_p=h[p]!=hp,reopen_q=h[q]!=hq;
            for(int i=0;i<W;i++) {
                if(!reopen_p&&hp+sz[i]<=8)
                    reopen_p=better(from_p[i][hp].cost,from_p[i][hp].bonus,labels[i*stride+p*8+hp]);
                if(!reopen_q&&hq+sz[i]<=8)
                    reopen_q=better(from_q[i][hq].cost,from_q[i][hq].bonus,labels[i*stride+q*8+hq]);
            }
            LOCAL_NOTE(++local_event_layers; local_event_reopens += reopen_p + reopen_q;)
            seed_neighborhood(p,reopen_p);seed_neighborhood(q,reopen_q);
        }
        if(labels[GOAL].cost>cap)return false;
        result=reconstruct(base,labels[GOAL].path);
        if(int(result.size())!=int(base.size())+labels[GOAL].cost)
            throw logic_error("packet reinsertion cost mismatch");
        return true;
    }

    bool packet_neighbor(const vector<Move>& current,const PacketCut& cut,int slack,
                        vector<Move>& result) {
        IdentityState cur=checkpoint_at(current,cut.time);
        int source=current[cut.time].p;
        TowerBits before=cur.word(source),packet=before>>(4*cut.keep);
        if(height(packet)<2||board_info.normalize(prefix(before,cut.keep),source)!=prefix(before,cut.keep))return false;
        for(int i=cut.keep;i<cur.h[source];i++)cur.alive[cur.a[source][i]]=0;
        cur.h[source]=cut.keep;State initial=cur.words();
        vector<Move> base;
        if(!extract_from(current,cur,cut.time,base))return false;
        int cap=int(current.size())-cut.time+slack-int(base.size());
        vector<Move> tail;
        if(!insert_packet(initial,base,source,packet,cap,tail))return false;
        result.assign(current.begin(),current.begin()+cut.time);
        result.insert(result.end(),tail.begin(),tail.end());
        return true;
    }

    IdentityState checkpoint_at(const vector<Move>& current,int time) const {
        IdentityState b=checkpoints[time/CHECKPOINT];
        for(int t=time/CHECKPOINT*CHECKPOINT;t<time;t++)b.apply(current[t]);
        return b;
    }

    bool insert_run(const State& initial,const vector<Move>& base,const RunMember& m,
                    int gap,int cap,vector<Move>& result) {
        LOCAL_NOTE(
            ++local_run_reinsert_calls;local_run_reinserted_slimes+=m.count;
            local_run_multi_calls+=m.count>1;
        )
        const bool ok=m.count==1?insert_at(initial,base,m.source,m.shade,gap,cap,result):
            insert_packet(initial,base,m.source,run_word(m),cap,result,gap);
        LOCAL_NOTE(
            local_run_completed+=ok;local_run_completed_slimes+=ok?m.count:0;
            local_run_multi_completed+=ok&&m.count>1;
        )
        return ok;
    }

    // 選択した上側だけを同色の塊へまとめる。切出し位置と背景の分割は親と同じ自由度を持つ。
    bool flexible_neighbor(const vector<Move>& current,const PacketCut& cut,int slack,
                          vector<Move>& result) {
        LOCAL_NOTE(++local_run_flexible_calls;)
        IdentityState cur=checkpoint_at(current,cut.time);
        int source=current[cut.time].p;
        TowerBits before=cur.word(source),packet=before>>(4*cut.keep);
        const int slime_count=height(packet);
        if(slime_count<2||slime_count>8||board_info.normalize(prefix(before,cut.keep),source)!=prefix(before,cut.keep))return false;
        array<RunMember,8> members{};
        const int n=append_runs(members,0,packet,source,cut.keep);
        for(int i=cut.keep;i<cur.h[source];i++)cur.alive[cur.a[source][i]]=0;
        cur.h[source]=uint8_t(cut.keep);
        const State initial=cur.words();
        vector<Move> skeleton;
        if(!extract_from(current,cur,cut.time,skeleton))return false;
        const int allowance=int(current.size())-cut.time+slack;
        int best_length_value=allowance+1;
        vector<Move> best_tail;
        // 追加順序の匹数条件は親を維持する。1塊では同じ順序の再試行を省く。
        int mode=rng(4),rounds=n>1&&slime_count<=4?2:1;
        for(int round=0;round<rounds;round++) {
            time_keeper.check();
            array<int,8> order{};
            iota(order.begin(),order.begin()+n,0);
            int style=(mode+round)%4;
            if(style==0)reverse(order.begin(),order.begin()+n);
            else if(style==2) {
                stable_sort(order.begin(),order.begin()+n,[&](int a,int b){
                    return board_info.floor_dist[source][board_info.nest_pos_by_code[members[a].shade]]>
                           board_info.floor_dist[source][board_info.nest_pos_by_code[members[b].shade]];
                });
            }else if(style==3) {
                for(int j=n-1;j>0;j--)swap(order[j],order[rng(j+1)]);
            }
            // 巣では帰巣しない元の最上段の塊を先に戻す。
            if(board_info.nest_code[source]) {
                auto at=find(order.begin(),order.begin()+n,n-1);
                rotate(order.begin(),at,at+1);
            }
            State restored=initial;unsigned inserted=0;
            vector<Move> tail=skeleton;bool ok=true;
            for(int j=0;j<n;j++) {
                int rank=order[j],gap=cut.keep;
                for(int k=0;k<rank;k++)if(inserted>>k&1)gap+=members[k].count;
                TowerBits next_initial=insert_run_word(restored[source],gap,members[rank]);
                if(board_info.normalize(next_initial,source)!=next_initial){ok=false;break;}
                vector<Move> next;
                int cap=min(allowance,best_length_value-1)-int(tail.size());
                if(!insert_run(restored,tail,members[rank],gap,cap,next)){ok=false;break;}
                ++insertions;tail=move(next);restored[source]=next_initial;inserted|=1u<<rank;
            }
            if(ok&&restored[source]==before&&int(tail.size())<best_length_value) {
                best_length_value=int(tail.size());best_tail=move(tail);
            }
        }
        if(best_length_value>allowance)return false;
        result.assign(current.begin(),current.begin()+cut.time);
        result.insert(result.end(),best_tail.begin(),best_tail.end());
        return true;
    }

    // 同じ途中時点の2塔の上側を再構築する。各塊の出発点と元の段を保持し、
    // 開始盤面と既存の前半操作を保ったまま、その後の経路を作り直す。
    bool paired_neighbor(const vector<Move>& current,int slack,vector<Move>& result) {
        LOCAL_NOTE(local_late_paired_anchor=false;++local_run_paired_calls;)
        const int T=int(current.size());if(T<3)return false;
        int time;
        if(!packet_cuts.empty()&&rng(3)) {
            int z=rng(4)?min(rng(int(packet_cuts.size())),rng(int(packet_cuts.size()))):rng(int(packet_cuts.size()));
            time=packet_cuts[z].time;
            LOCAL_NOTE(
                local_late_paired_anchor=packet_cuts[z].later;
                local_late_start.attempts[2]+=local_late_paired_anchor;
            )
        } else {
            // 既に行った集荷を残しつつ、早い時点を優先する。
            time=min(rng(T),rng(T));
        }
        IdentityState cur=checkpoint_at(current,time);
        const State boundary=cur.words();
        int p=current[time].p,hp=cur.h[p];
        if(!hp)return false;
        const int total_limit=rng(4)?6:8;
        auto keep_for=[&](int cell,int maximum,bool randomize) {
            const int h=cur.h[cell];int ks[8],count=0;
            for(int k=max(0,h-maximum);k<h;k++)
                if(board_info.normalize(prefix(boundary[cell],k),cell)==prefix(boundary[cell],k))ks[count++]=k;
            if(!count)return -1;
            return ks[randomize?rng(count):0];
        };
        int keep_p=keep_for(p,min(hp,total_limit-1),rng(4)==0);
        if(keep_p<0)return false;
        int np=hp-keep_p;
        unsigned pc=unsigned(color_mask(boundary[p]>>(4*keep_p)));
        struct Partner {int cell,keep;double cost;};
        vector<Partner> partners;partners.reserve(board_info.M);
        int first_destination=board_info.ray[p][current[time].d][current[time].l];
        for(int q=0;q<board_info.cell_count;q++)if(q!=p&&cur.h[q]) {
            int distance=board_info.floor_dist[p][q];
            if(distance>10)continue;
            int k=keep_for(q,min(int(cur.h[q]),total_limit-np),false);
            if(k<0)continue;
            unsigned qc=unsigned(color_mask(boundary[q]>>(4*k)));
            int home_distance=infinite_cost;
            for(unsigned a=pc;a;a&=a-1)for(unsigned b=qc;b;b&=b-1) {
                int ca=1+__builtin_ctz(a),cb=1+__builtin_ctz(b);
                home_distance=min(home_distance,int(board_info.floor_dist[board_info.nest_pos_by_code[ca]][board_info.nest_pos_by_code[cb]]));
            }
            double score=distance+0.22*home_distance-0.45*(q==first_destination);
            partners.push_back({q,k,score});
        }
        if(partners.empty())return false;
        sort(partners.begin(),partners.end(),[](const Partner& a,const Partner& b){
            return a.cost<b.cost||(a.cost==b.cost&&a.cell<b.cell);
        });
        int pool=min(12,int(partners.size()));
        int at=rng(4)?min(rng(pool),rng(pool)):rng(int(partners.size()));
        int q=partners[at].cell,keep_q=partners[at].keep;
        if(rng(4)==0)keep_q=keep_for(q,total_limit-np,true);
        if(keep_q<0)return false;
        array<RunMember,8> members{};int n=0,slime_count=0;
        uint64_t key=0xb5ad4eceda1ce2a9ULL;
        for(auto [cell,keep]:{pair<int,int>{p,keep_p},pair<int,int>{q,keep_q}}) {
            n=append_runs(members,n,boundary[cell]>>(4*keep),cell,keep);
            slime_count+=cur.h[cell]-keep;
            for(int k=keep;k<cur.h[cell];k++) {
                int id=cur.a[cell][k];
                key=(key^uint64_t(id+1))*0x9e3779b97f4a7c15ULL;
                cur.alive[id]=0;
            }
            cur.h[cell]=uint8_t(keep);
        }
        auto seen=last_tried.find(key);
        if(seen!=last_tried.end()&&iteration-seen->second<24)return false;
        last_tried[key]=iteration;
        const State initial=cur.words();
        vector<Move> skeleton;
        if(!extract_from(current,cur,time,skeleton))return false;
        const int allowance=T-time+slack;
        int best_length_value=allowance+1;
        vector<Move> best_tail;
        const int mode=rng(5),rounds=slime_count<=3?2:1;
        for(int round=0;round<rounds;round++) {
            time_keeper.check();State restored=initial;
            vector<Move> tail=skeleton;
            unsigned inserted=0;bool ok=true;
            const int style=(mode+round)%5;
            array<double,8> priority{};
            for(int j=0;j<n;j++) {
                const auto& m=members[j];
                double d=board_info.floor_dist[m.source][board_info.nest_pos_by_code[m.shade]];
                if(style==0)priority[j]=d*(0.8+0.4*rng.unit());
                else if(style==1)priority[j]=-d+0.2*rng.unit();
                else if(style==2)priority[j]=rng.unit()*32;
                else if(style==3)priority[j]=(m.source==p?16:0)-m.rank;
                else priority[j]=(m.source==q?16:0)+m.rank;
            }
            for(int j=0;j<n;j++) {
                int who=-1;
                for(int k=0;k<n;k++)if(!(inserted>>k&1)) {
                    const auto& m=members[k];bool eligible=true;
                    // 巣では元の上側の塊から戻し、その下へ置く塊の帰巣を防ぐ。
                    if(board_info.nest_code[m.source])for(int z=0;z<n;z++)
                        if(members[z].source==m.source&&members[z].rank>m.rank&&!(inserted>>z&1))eligible=false;
                    if(eligible&&(who<0||priority[k]>priority[who]))who=k;
                }
                if(who<0){ok=false;break;}
                const auto& m=members[who];int gap=m.source==p?keep_p:keep_q;
                for(int k=0;k<n;k++)if((inserted>>k&1)&&members[k].source==m.source&&members[k].rank<m.rank)gap+=members[k].count;
                TowerBits next_initial=insert_run_word(restored[m.source],gap,m);
                if(board_info.normalize(next_initial,m.source)!=next_initial){ok=false;break;}
                vector<Move> next;
                const int cap=min(allowance,best_length_value-1)-int(tail.size());
                if(!insert_run(restored,tail,m,gap,cap,next)){ok=false;break;}
                ++insertions;restored[m.source]=next_initial;tail=move(next);inserted|=1u<<who;
            }
            if(ok&&restored==boundary&&int(tail.size())<best_length_value) {
                best_length_value=int(tail.size());best_tail=move(tail);
            }
        }
        if(best_length_value>allowance)return false;
        result.assign(current.begin(),current.begin()+time);
        result.insert(result.end(),best_tail.begin(),best_tail.end());
        return true;
    }

    static bool same_moves(const vector<Move>& a,const vector<Move>& b) {
        if(a.size()!=b.size())return false;
        for(size_t i=0;i<a.size();i++)
            if(a[i].p!=b[i].p||a[i].k!=b[i].k||a[i].d!=b[i].d||a[i].l!=b[i].l)return false;
        return true;
    }

    // 同じ端点へ触れる操作の順序を保つ。他の操作は交換できるため、
    // トポロジカル順序の変更で便をつなぎ、後の再挿入の同乗・支持機会を変える。
    vector<Move> causal_reorder(const vector<Move>& original,int style) {
        const int n=int(original.size());
        vector<array<int,2>> next(n,array<int,2>{-1,-1}),prev(n,array<int,2>{-1,-1});
        vector<uint8_t> degree(n),out_degree(n);
        vector<int> destination(n),ready;ready.reserve(n);
        array<int,max_cells> previous;previous.fill(-1);
        auto edge=[&](int a,int b) {
            if(a<0)return;
            next[a][out_degree[a]++]=b;prev[b][degree[b]++]=a;
        };
        for(int t=0;t<n;t++) {
            int p=original[t].p,q=destination[t]=board_info.ray[p][original[t].d][original[t].l];
            int a=previous[p],b=previous[q];edge(a,t);if(b!=a)edge(b,t);
            previous[p]=previous[q]=t;
        }
        const bool backward=style>=3;style%=3;
        vector<Move> out;out.reserve(n);
        State b=board_info.initial;
        if(backward) {
            vector<TowerBits> departing(n),landing(n);
            for(int t=0;t<n;t++) {
                const Move& m=original[t];departing[t]=b[m.p]>>(4*m.k);
                landing[t]=board_info.normalize(reverse_tower(departing[t]),destination[t]);
                board_info.apply(b,m);
                if(!out_degree[t])ready.push_back(t);
            }
            int next_cell=-1;TowerBits required=0;
            while(!ready.empty()) {
                if((out.size()&63)==0)time_keeper.check();
                int chosen=0;int64_t best_priority=LLONG_MIN;
                for(int j=0;j<int(ready.size());j++) {
                    int t=ready[j];
                    bool continuation=destination[t]==next_cell&&required&&landing[t]==required;
                    int64_t priority=continuation?1000000:0;
                    if(style==1)priority-=t;
                    else if(style==2)priority+=int(rng.next()&255)+2*t;
                    else priority+=t;
                    if(priority>best_priority){best_priority=priority;chosen=j;}
                }
                int t=ready[chosen];ready[chosen]=ready.back();ready.pop_back();
                out.push_back(original[t]);next_cell=original[t].p;required=departing[t];
                for(int j=0;j<degree[t];j++) {
                    int u=prev[t][j];if(--out_degree[u]==0)ready.push_back(u);
                }
            }
            reverse(out.begin(),out.end());b=board_info.initial;
            for(const Move& m:out)board_info.apply(b,m);
        } else {
            for(int t=0;t<n;t++)if(!degree[t])ready.push_back(t);
            int last_cell=-1;TowerBits travelling=0;
            while(!ready.empty()) {
                if((out.size()&63)==0)time_keeper.check();
                int chosen=0;int64_t best_priority=LLONG_MIN;
                for(int j=0;j<int(ready.size());j++) {
                    int t=ready[j];const Move& m=original[t];
                    bool continuation=m.p==last_cell&&travelling&&(b[m.p]>>(4*m.k))==travelling;
                    int64_t priority=continuation?1000000:0;
                    if(style==1)priority+=t;
                    else if(style==2)priority+=int(rng.next()&255)-2*t;
                    else priority-=t;
                    if(priority>best_priority){best_priority=priority;chosen=j;}
                }
                int t=ready[chosen];ready[chosen]=ready.back();ready.pop_back();
                Move m=original[t];TowerBits flying=b[m.p]>>(4*m.k);
                board_info.apply(b,m);out.push_back(m);
                last_cell=destination[t];travelling=board_info.normalize(reverse_tower(flying),last_cell);
                for(int j=0;j<out_degree[t];j++) {
                    int u=next[t][j];if(--degree[u]==0)ready.push_back(u);
                }
            }
        }
        if(int(out.size())!=n||board_info.count(b))throw logic_error("causal reorder invariant");
        return out;
    }

    void initialize_spatial_cuts() {
        vector<int> tokens;for(int p=0;p<board_info.cell_count;p++)if(board_info.initial[p])tokens.push_back(p);
        for(int p:tokens) {
            vector<pair<double,int>> near,same,different;
            for(int q:tokens)if(q!=p) {
                double d=board_info.floor_dist[p][q]+0.20*board_info.floor_dist[board_info.nest_pos_by_code[board_info.initial[p]]][board_info.nest_pos_by_code[board_info.initial[q]]];
                near.emplace_back(d,q);
                if(board_info.initial[p]==board_info.initial[q])same.emplace_back(d,q);
                else different.emplace_back(d,q);
            }
            for(auto* list:{&near,&same,&different}) {
                sort(list->begin(),list->end());vector<int> ids{p};
                int limit=list==&different?1:2;
                for(int j=0;j<min(limit,int(list->size()));j++) {
                    ids.push_back((*list)[j].second);spatial_cuts.push_back(ids);
                }
            }
        }
    }
    static uint64_t later_start_hash(uint64_t hash,int time) {
        // 開始時刻ごとに異なるキーを使い、別時刻の試行による再試行待ちを共有させない。
        return hash^((uint64_t(time)+1)*0x94d049bb133111ebULL);
    }
    void make_candidates(const vector<Move>& answer,bool refresh_regular=true) {
        if(refresh_regular)candidates.clear();
        packet_cuts.clear();flights.clear();checkpoints.clear();
        support_uses.clear();later_cuts.clear();
        flights.reserve(answer.size());checkpoints.reserve((answer.size()+CHECKPOINT-1)/CHECKPOINT);
        IdentityState board;
        // 各操作から最大8色列、便、下段、着地先との和集合を取り、空間・単独・同色候補を加える。
        if(refresh_regular)build_seen.reset(12*answer.size()+spatial_cuts.size()+board_info.M+board_info.K+64);
        build_packets.reset(3*answer.size()+16);build_patterns.reset(answer.size()+16);
        auto& patterns=pattern_buffer;int pattern_count=0;
        auto& anchored=pattern_anchors;
        for(int p=0;p<board_info.cell_count;p++)anchored[p].clear();
        cut_ids.clear();
        auto hash_of=[](const vector<int>& ids) {
            uint64_t hash=0x51ed270b3a4dc107ULL;
            for(int id:ids)hash=(hash^(id+1))*0x9e3779b97f4a7c15ULL;
            return hash;
        };
        auto add=[&](vector<int> ids) {
            if(!refresh_regular)return;
            if(ids.empty()||ids.size()>12)return;
            sort(ids.begin(),ids.end());ids.erase(unique(ids.begin(),ids.end()),ids.end());
            uint64_t hash=hash_of(ids);
            if(build_seen.put(hash,int(candidates.size())).second)candidates.push_back({move(ids),0,hash});
        };
        if(refresh_regular) {
        vector<int> colors[13];
        for(int p=0;p<board_info.cell_count;p++)if(board_info.initial[p]) {
            add({p});colors[board_info.initial[p]].push_back(p);
        }
        for(int current_code=1;current_code<=board_info.K;current_code++)add(colors[current_code]);
        for(const auto& ids:spatial_cuts)add(ids);
        }
        for(int t=0;t<int(answer.size());t++) {
            if((t&127)==0)time_keeper.check();
            if(t%CHECKPOINT==0)checkpoints.push_back(board);
            Move m=answer[t];int p=m.p;
            vector<int> flight;Flight f;
            flight.reserve(8);
            for(int i=m.k;i<board.h[p];i++) {
                int id=board.a[p][i];flight.push_back(id);f.id[f.n++]=id;
            }
            flights.push_back(f);if(refresh_regular)add(flight);
            if(m.l>1) {
                SupportUse use{{},t,int(m.k)+1-int(m.l)};
                for(int i=0;i<m.k;i++)use.lower.id[use.lower.n++]=board.a[p][i];
                support_uses.push_back(use);
            }
            sort(flight.begin(),flight.end());uint64_t fh=hash_of(flight);
            auto ins=build_patterns.put(fh,pattern_count);
            if(ins.second){
                const int at=pattern_count++;
                anchored[flight.front()].push_back(at);
                if(at==int(patterns.size()))patterns.emplace_back();
                auto& pat=patterns[at];pat.n=int(flight.size());
                copy(flight.begin(),flight.end(),pat.ids.begin());
                pat.times.clear();pat.times.push_back(t);
            }else patterns[ins.first].times.push_back(t);
            if(refresh_regular) {
            vector<int> run;
            for(int i=0;i<board.h[p];i++) {
                int id=board.a[p][i];
                if(!run.empty()&&board_info.initial[run.back()]!=board_info.initial[id]){add(run);run.clear();}
                run.push_back(id);
            }
            add(run);
            if(m.k){vector<int> lower;for(int i=0;i<m.k;i++)lower.push_back(board.a[p][i]);add(lower);}
            }
            // 塔全体、跳ぶ束、上側2匹を候補にする。再挿入時には個体へ分解できる。
            TowerBits word=board.word(p);
            for(int k:{0,int(m.k),int(board.h[p])-2}) {
                int n=int(board.h[p])-k;if(k<0||n<2)continue;
                if(board_info.normalize(prefix(word,k),p)!=prefix(word,k))continue;
                vector<int> ids;for(int i=k;i<board.h[p];i++)ids.push_back(board.a[p][i]);
                sort(ids.begin(),ids.end());uint64_t hash=hash_of(ids)^0xd1b54a32d192ed03ULL;
                const bool before_split=k<int(m.k);
                auto slot=build_packets.put(hash,int(packet_cuts.size()));
                if(slot.second){
                    packet_cuts.push_back({t,k,n,0,hash,0.0,false,before_split});
                    later_cuts.emplace_back();
                    array<int16_t,8> selected{};
                    for(int i=0;i<n;i++)selected[i]=int16_t(ids[i]);
                    cut_ids.push_back(selected);
                }else if(t>packet_cuts[slot.first].time) {
                    // 同じ個体集合に開始時刻を1枠追加する。分離する境界を優先し、同条件なら遅い時刻を選ぶ。
                    auto& late=later_cuts[slot.first];
                    if(late.time<0||before_split>late.before_split||
                       (before_split==late.before_split&&t>late.time))
                        late={t,k,n,0,later_start_hash(hash,t),0.0,true,before_split};
                }
            }
            // 同じ端点で相互作用した束の和集合を、位置の近さだけによらない除去候補にする。
            int dest=board_info.ray[p][m.d][m.l];
            if(refresh_regular&&board.h[dest]&&board.h[dest]+f.n<=8){
                vector<int> both=flight;
                for(int i=0;i<board.h[dest];i++)both.push_back(board.a[dest][i]);
                add(move(both));
            }
            board.apply(m);
        }
        // 最初の候補群を集めてから追加し、候補順と優先度の乱数消費順を固定する。
        const int primary_count=int(packet_cuts.size());
        LOCAL_NOTE(++local_late_start.builds;local_late_start.primary+=primary_count;)
        for(int i=0;i<primary_count;i++)if(later_cuts[i].time>=0) {
            LOCAL_NOTE(
                ++local_late_start.generated;
                local_late_start.split_generated+=later_cuts[i].before_split;
                local_late_start.delay_sum+=later_cuts[i].time-packet_cuts[i].time;
            )
            packet_cuts.push_back(later_cuts[i]);
            const auto ids=cut_ids[i];cut_ids.push_back(ids);
        }
        array<int,max_cells> member{};int stamp=0;
        // 各集合を最小IDへ登録する。除去対象に含まれる最小IDの集合だけを調べ、
        // 操作時刻の一覧から区間内の削除費用を求める。
        auto saved_by=[&](const auto& ids,int n,int start) {
            ++stamp;for(int j=0;j<n;j++)member[ids[j]]=stamp;
            int saved=0;
            for(int j=0;j<n;j++)for(int pi:anchored[ids[j]]) {
                const auto& p=patterns[pi];if(p.n>n)continue;
                bool all=true;
                for(int k=0;k<p.n;k++)if(member[p.ids[k]]!=stamp){all=false;break;}
                if(all)saved+=int(p.times.end()-lower_bound(p.times.begin(),p.times.end(),start));
            }
            return saved;
        };
        double divisor[13],packet_divisor[9];
        for(int n=1;n<=12;n++)divisor[n]=pow(double(n),removal_size_exponent);
        for(int n=1;n<=8;n++)packet_divisor[n]=pow(double(n),0.45);
        LOCAL_NOTE(const double repair_priority_start=time_keeper.exact_elapsed_sec();int repair_priority_penalized=0;)
        if(refresh_regular)for(auto& cand:candidates) {
            int saved=saved_by(cand.ids,int(cand.ids.size()),0);
            cand.broken_support_jumps=broken_support_jumps_value(cand.ids);
            // 候補ごとに乱数を1回引く。負の優先度も候補として保持する。
            const double noise=(1.0-priority_noise_amplitude)+2.0*priority_noise_amplitude*rng.unit();
            cand.priority=(saved-repair_weight*cand.broken_support_jumps+0.25)/divisor[cand.ids.size()]*noise;
            cand.gross_removed=saved;cand.rank_noise=noise;cand.rank_divisor=divisor[cand.ids.size()];
            cand.score_generation=trajectory_generation;
            LOCAL_NOTE(repair_priority_penalized+=cand.broken_support_jumps>0;)
        }
        LOCAL_NOTE(trace.count_by("lns_repair_priority_evaluated",int(candidates.size()));
                   trace.count_by("lns_repair_priority_penalized",repair_priority_penalized);
                   trace.add_time_ms("lns_repair_priority",(time_keeper.exact_elapsed_sec()-repair_priority_start)*1000.0);)
        for(size_t i=0;i<packet_cuts.size();i++) {
            auto& cut=packet_cuts[i];cut.saved=saved_by(cut_ids[i],cut.size,cut.time);
            cut.priority=(cut.saved+0.25)/packet_divisor[cut.size]*((1.0-priority_noise_amplitude)+2.0*priority_noise_amplitude*rng.unit());
        }
        if(refresh_regular)sort(candidates.begin(),candidates.end(),[](const Removal&a,const Removal&b){return a.priority>b.priority;});
        sort(packet_cuts.begin(),packet_cuts.end(),[](const PacketCut&a,const PacketCut&b){return a.priority>b.priority;});
        history_generation=packet_generation=trajectory_generation;
        if(refresh_regular){candidate_age=0;++full_builds;}else ++packet_only_builds;
    }

public:
    uint64_t full_builds=0,history_only_builds=0,packet_only_builds=0;
    uint64_t score_refreshes=0,stale_bank_selections=0;
    double full_build_seconds=0,history_only_seconds=0,packet_only_seconds=0;
    int attempts=0,insertions=0,accepted=0,improvements=0,shortcuts=0;
    int block_attempts=0,block_accepted=0,block_improvements=0,uphill=0,restarts=0;
    int flexible_attempts=0,flexible_accepted=0,flexible_improvements=0,flexible_saved=0;
    int reorder_attempts=0,reorder_improvements=0,reorder_saved=0,duplicates=0;
    int paired_attempts=0,paired_accepted=0,paired_improvements=0,paired_saved=0;
    int backward_attempts=0,backward_improvements=0,backward_saved=0;
    double paired_seconds=0;
    double block_seconds=0,build_seconds=0,started_at=0;
    array<double,32> nn_features(const Removal& c,const vector<Move>& current,const vector<Move>& best,
                                  int stagnant,double progress)const{
        array<double,32>x{};const double n=c.ids.size(),T=max<size_t>(1,current.size());
        x[0]=board_info.N;x[1]=board_info.K;x[2]=board_info.M;x[3]=board_info.cell_count;
        x[4]=double(board_info.M)/board_info.cell_count;x[5]=current.size();x[6]=best.size();
        x[7]=double(current.size())-double(best.size());x[8]=progress;x[9]=stagnant;
        x[10]=n;x[11]=n/max(1,board_info.M);
        array<int,13>colors{};array<bool,max_cells>selected{};
        double sum=0,lo=1e9,hi=0;
        for(int id:c.ids){
            selected[id]=true;int color=int(board_info.initial[id]);++colors[color];
            double d=board_info.floor_dist[id][board_info.nest_pos_by_code[color]];
            sum+=d;lo=min(lo,d);hi=max(hi,d);
        }
        for(int count:colors)if(count){++x[12];x[13]=max(x[13],count/n);x[14]-=(count/n)*log(count/n);}
        const bool fresh=c.score_generation==trajectory_generation;
        x[15]=fresh?c.gross_removed:removed_commands(c.ids);
        x[16]=fresh?c.broken_support_jumps:broken_support_jumps_value(c.ids);
        x[17]=x[15]/n;x[18]=x[16]/n;
        x[19]=fresh?c.priority:(x[15]-repair_weight*x[16]+0.25)/c.rank_divisor*c.rank_noise;x[20]=sum/n;x[21]=hi;x[22]=lo;
        int pairs=0;for(int a:c.ids)for(int b:c.ids)if(a<b){
            double d=board_info.floor_dist[a][b];x[23]+=d;x[24]=max(x[24],d);++pairs;
        }
        x[23]/=max(1,pairs);
        int first=-1,last=-1,used=0,passengers=0;
        for(int t=0;t<int(flights.size());t++){
            int count=0;for(int i=0;i<flights[t].n;i++)count+=selected[flights[t].id[i]];
            if(count){if(first<0)first=t;last=t;++used;passengers+=count;}
        }
        x[25]=first<0?0:first/T;x[26]=last<0?0:last/T;x[27]=first<0?0:(last-first)/T;
        x[28]=used/T;x[29]=passengers/n;x[30]=support_weight;x[31]=ride_weight;
        for(double value:x)if(!isfinite(value))throw logic_error("nonfinite teacher feature");
        return x;
    }
    vector<int> nn_eligible;
    array<int,32> nn_ranks{};
    int nn_sample(int cooldown) {
        nn_eligible.clear();
        for(int i=0;i<int(candidates.size());i++){
            auto it=last_tried.find(candidates[i].hash);
            if(it==last_tried.end()||iteration-it->second>cooldown)nn_eligible.push_back(i);
        }
        const int n=int(nn_eligible.size());
        if(n<=32){copy(nn_eligible.begin(),nn_eligible.end(),nn_ranks.begin());return n;}
        copy(nn_eligible.begin(),nn_eligible.begin()+16,nn_ranks.begin());
        const int rest=n-16;
        for(int band=0;band<16;band++){
            const int left=rest*band/16,right=rest*(band+1)/16;
            nn_ranks[16+band]=nn_eligible[16+(left+right-1)/2];
        }
        return 32;
    }
    int nn_choose(const vector<Move>& current,const vector<Move>& best,
                  int stagnant,double progress,int cooldown) {
        LOCAL_NOTE(const auto begin=chrono::steady_clock::now();)
        const int n=nn_sample(cooldown);
        if(n==0)throw logic_error("NN called without eligible candidates");
        array<array<double,32>,32> features;
        LOCAL_NOTE(const auto feature_begin=chrono::steady_clock::now();)
        for(int i=0;i<n;i++) {
            refresh_regular_score(candidates[nn_ranks[i]]);
            features[i]=nn_features(candidates[nn_ranks[i]],current,best,stagnant,progress);
        }
        LOCAL_NOTE(const auto inference_begin=chrono::steady_clock::now();)
        int choice=nn_ranks[0];float value=numeric_limits<float>::infinity();
        for(int i=0;i<n;i++){
            const float predicted=neural_rank::predict(features[i]);
            if(!isfinite(predicted))throw logic_error("nonfinite NN prediction");
            // ranksは元順位順。厳密な同点では最初の候補を保持する。
            if(predicted<value){value=predicted;choice=nn_ranks[i];}
        }
        LOCAL_NOTE(
            const auto finished=chrono::steady_clock::now();
            ++local_nn.calls;local_nn.scored+=n;local_nn.changed+=choice!=nn_ranks[0];local_nn.rank_sum+=choice;
            local_nn.feature_ms+=chrono::duration<double,milli>(inference_begin-feature_begin).count();
            local_nn.inference_ms+=chrono::duration<double,milli>(finished-inference_begin).count();
            local_nn.total_ms+=chrono::duration<double,milli>(finished-begin).count();
        )
        return choice;
    }

    uint64_t alias_closures=0,alias_gap_relaxations=0,alias_top_relaxations=0,alias_cost_relaxations=0;
    uint64_t random_state=1;
    void accumulate(const TemporalLNS& other) {
        alias_closures+=other.alias_closures;alias_gap_relaxations+=other.alias_gap_relaxations;
        alias_top_relaxations+=other.alias_top_relaxations;alias_cost_relaxations+=other.alias_cost_relaxations;
        attempts+=other.attempts;
        insertions+=other.insertions;
        accepted+=other.accepted;
        improvements+=other.improvements;
        shortcuts+=other.shortcuts;
        block_attempts+=other.block_attempts;
        block_accepted+=other.block_accepted;
        block_improvements+=other.block_improvements;
        uphill+=other.uphill;
        restarts+=other.restarts;
        flexible_attempts+=other.flexible_attempts;
        flexible_accepted+=other.flexible_accepted;
        flexible_improvements+=other.flexible_improvements;
        flexible_saved+=other.flexible_saved;
        reorder_attempts+=other.reorder_attempts;
        reorder_improvements+=other.reorder_improvements;
        reorder_saved+=other.reorder_saved;
        duplicates+=other.duplicates;
        paired_attempts+=other.paired_attempts;
        paired_accepted+=other.paired_accepted;
        paired_improvements+=other.paired_improvements;
        paired_saved+=other.paired_saved;
        backward_attempts+=other.backward_attempts;
        backward_improvements+=other.backward_improvements;
        backward_saved+=other.backward_saved;
        paired_seconds+=other.paired_seconds;
        block_seconds+=other.block_seconds;
        build_seconds+=other.build_seconds;
        full_builds+=other.full_builds;history_only_builds+=other.history_only_builds;packet_only_builds+=other.packet_only_builds;
        score_refreshes+=other.score_refreshes;stale_bank_selections+=other.stale_bank_selections;
        full_build_seconds+=other.full_build_seconds;history_only_seconds+=other.history_only_seconds;packet_only_seconds+=other.packet_only_seconds;
    }
    void optimize(vector<Move>& best,double slice_end,double search_start,double search_end) {
        const double slice_begin=time_keeper.exact_elapsed_sec();
        // 中断期間を候補自身の費用へ含めず、乱数も候補ごとに続きから使う。
        struct SliceScope {
            double& seconds;uint64_t& state;uint64_t previous;double begin;
            ~SliceScope(){seconds+=time_keeper.exact_elapsed_sec()-begin;state=rng.x;rng.x=previous;}
        } scope{active_seconds,random_state,rng.x,slice_begin};
        rng.x=random_state;
        lns_start=search_start;
        auto rebuild=[&](){rebuild_all(current);};
        LOCAL_ONLY(trace.count_by("race_resumes",initialized));
        const auto selector_values=nn_selector_features();
        const bool use_nn=nn_selector_choice(selector_values);
        if(!initialized) {
            started_at=time_keeper.exact_elapsed_sec();
            current=smooth_routes(best);
            const size_t before_initial_reductions=current.size();
            search_reductions.cheap(current,min(slice_end,search_end));
            search_reductions.initial_saved+=before_initial_reductions-current.size();
            LOCAL_NOTE(trace.count_by("lns_initial_shortcut_saved", int(best.size()) - int(current.size()));)
            shortcuts+=int(best.size())-int(current.size());
            if(current.size()<best.size())best=current;
            // 最初の並べ替えは短くなった場合に採用し、同手数の別順序は後の探索で扱う。
            auto reordered=causal_reorder(current,0);++reorder_attempts;
            if(!same_moves(reordered,current)) {
                auto polished=smooth_routes(reordered);
                const size_t before_initial_reductions=polished.size();
                search_reductions.cheap(polished,min(slice_end,search_end));
                search_reductions.initial_reorder_saved+=before_initial_reductions-polished.size();
                if(polished.size()<current.size()) {
                    LOCAL_NOTE(trace.count_by("lns_initial_reorder_saved", int(current.size()) - int(polished.size()));)
                    ++reorder_improvements;reorder_saved+=int(current.size()-polished.size());
                    current=move(polished);if(current.size()<best.size())best=current;
                }
            }
            initialize_spatial_cuts();
            rebuild();initialized=true;
        }
        const double end=search_end;
        // 切り替え時の再加熱を避け、全候補を同じ全体進捗で冷却する。
        const double initial_progress=clamp((time_keeper.exact_elapsed_sec()-lns_start)/max(PROGRAM_TIME_LIMIT_SEC*(0.02/1.90),end-lns_start),0.0,1.0);
        double temperature=lns_start_temperature*pow(lns_end_temperature/lns_start_temperature,initial_progress);
        while(time_keeper.exact_elapsed_sec()<min(slice_end,end)) {
            time_keeper.check();++iteration;++stagnant;
            if(stagnant>max(100,board_info.M*3)&&current.size()>best.size()) {
                current=best;trajectory_changed();stagnant=0;++restarts;rebuild();
            }
            if(candidate_age>=candidate_refresh_interval)rebuild();
            if((iteration&31)==1) {
                double progress=clamp((time_keeper.exact_elapsed_sec()-lns_start)/max(LOCAL_SECONDS(0.02),end-lns_start),0.0,1.0);
                temperature=lns_start_temperature*pow(lns_end_temperature/lns_start_temperature,progress);
            }
            // 支持の重みは近傍の種類と独立に抽選する。
            int tie_mode=rng(12);
            support_weight=tie_mode==0?0:tie_mode==1?2:tie_mode==2?8:5;
            ride_weight=tie_mode==3?4:1;
            vector<Move> trial;
            bool reorder=iteration%113==0;
            bool paired=!reorder&&iteration%17==0&&
                        paired_seconds<0.11*max(PROGRAM_TIME_LIMIT_SEC*(0.03/1.90),active_seconds+time_keeper.exact_elapsed_sec()-slice_begin);
            bool backward=false;
            const bool packet_slot=!reorder&&!paired&&iteration%7==0&&
                        block_seconds<0.22*max(PROGRAM_TIME_LIMIT_SEC*(0.03/1.90),active_seconds+time_keeper.exact_elapsed_sec()-slice_begin);
            if(paired||packet_slot)ensure_packets(current);
            else if(!reorder)ensure_history(current);
            bool packet=packet_slot&&!packet_cuts.empty();
            bool flexible=packet&&(rng(3)!=0);
            // 指定した通常選択の間隔で、最大8匹の依存拡張へ割り当てる。
            bool dependency=!reorder&&!paired&&!packet&&++regular_selections%dependency_interval==0;
            LOCAL_NOTE(DependencyTimer dependency_timer(dependency);)
            bool ok=true;
            LOCAL_NOTE(int late_kind=-1;bool two_order=false;int repair_priority_broken=-1;)
            if(reorder) {
                ++attempts;++reorder_attempts;
                int style=rng(6);backward=style>=3;backward_attempts+=backward;
                trial=causal_reorder(current,style);
            }else if(paired) {
                ++attempts;++paired_attempts;double begin=time_keeper.exact_elapsed_sec();
                LOCAL_NOTE(const double previous_paired_seconds=paired_seconds;)
                ok=paired_neighbor(current,3,trial);
                paired_seconds+=time_keeper.exact_elapsed_sec()-begin;
                LOCAL_NOTE(if(local_late_paired_anchor){
                    late_kind=2;local_late_start.completed[2]+=ok;
                    local_late_start.seconds[2]+=paired_seconds-previous_paired_seconds;
                })
            }else if(packet) {
                int choice=-1,cooldown=max(24,min(160,int(packet_cuts.size()/2)));
                uint64_t salt=flexible?0xa0761d6478bd642fULL:0;
                if(rng(4)==0)choice=rng(int(packet_cuts.size()));
                else for(int i=0;i<int(packet_cuts.size());i++) {
                    auto it=last_tried.find(packet_cuts[i].hash^salt);
                    if(it==last_tried.end()||iteration-it->second>cooldown){choice=i;break;}
                }
                if(choice<0)choice=rng(int(packet_cuts.size()));
                PacketCut cut=packet_cuts[choice];last_tried[cut.hash^salt]=iteration;
                ++attempts;++block_attempts;double begin=time_keeper.exact_elapsed_sec();
                LOCAL_NOTE(
                    const double previous_block_seconds=block_seconds;
                    if(cut.later){late_kind=flexible?1:0;++local_late_start.attempts[late_kind];}
                )
                if(flexible){++flexible_attempts;ok=flexible_neighbor(current,cut,3,trial);}
                else {ok=packet_neighbor(current,cut,3,trial);if(ok)++insertions;}
                block_seconds+=time_keeper.exact_elapsed_sec()-begin;
                LOCAL_NOTE(if(late_kind>=0){
                    local_late_start.completed[late_kind]+=ok;
                    local_late_start.seconds[late_kind]+=block_seconds-previous_block_seconds;
                })
            }else {
                if(candidates.empty())break;
                int choice=-1,cooldown=max(24,min(200,int(candidates.size()*regular_cooldown_fraction)));
                int mode=rng(10);
                if(mode==0)choice=rng(int(candidates.size()));
                else if(mode<=2)choice=rng(min(100,int(candidates.size())));
                else for(int i=0;i<int(candidates.size());i++) {
                    auto it=last_tried.find(candidates[i].hash);
                    if(it==last_tried.end()||iteration-it->second>cooldown){choice=i;break;}
                }
                // 元の順位選択で適格候補がある場合だけ、同じ待ち条件でNNを使う。
                const bool nn_eligible=use_nn&&!dependency&&mode>=3&&choice>=0;
                if(choice<0)choice=rng(int(candidates.size()));
                if(nn_eligible){
                    const double progress=clamp((time_keeper.exact_elapsed_sec()-lns_start)/max(LOCAL_SECONDS(0.02),end-lns_start),0.0,1.0);
                    choice=nn_choose(current,best,stagnant,progress,cooldown);
                }
                refresh_regular_score(candidates[choice]);
                stale_bank_selections+=candidate_age>0;
                Removal cand=candidates[choice];last_tried[cand.hash]=iteration;
                LOCAL_NOTE(repair_priority_broken=cand.broken_support_jumps;trace.count_by("lns_repair_priority_selected",1);
                           trace.count_by("lns_repair_priority_selected_broken_jumps",cand.broken_support_jumps);)
                if(dependency) {
                    LOCAL_NOTE(++local_dependency.selected;const int seed_size=int(cand.ids.size());)
                    const int rounds=grow_dependency(cand);
                    if(!rounds)continue;
                    LOCAL_NOTE(
                        ++local_dependency.generated;local_dependency.multistep+=rounds>1;
                        local_dependency.added+=int(cand.ids.size())-seed_size;
                    )
                    auto previous=last_tried.find(cand.hash);
                    if(previous!=last_tried.end()&&iteration-previous->second<24) {
                        LOCAL_NOTE(++local_dependency.cooldown;)
                        continue;
                    }
                    last_tried[cand.hash]=iteration;
                    LOCAL_NOTE(++local_dependency.attempts;)
                }
                ++attempts;
                vector<Move> base;State initial;
                LOCAL_NOTE(local_dependency_extract=dependency;)
                const bool extracted=extract(current,cand.ids,base,initial);
                LOCAL_NOTE(local_dependency_extract=false;)
                if(!extracted) {
                    LOCAL_NOTE(local_dependency.extract_failed+=dependency;)
                    continue;
                }
                LOCAL_NOTE(if(dependency){
                    ++local_dependency.extracted;
                    local_dependency.gross_removed+=removed_commands(cand.ids);
                    local_dependency.net_removed+=int(current.size())-int(base.size());
                })
                vector<pair<double,int>> order;order.reserve(cand.ids.size());
                for(int id:cand.ids) {
                    double weight=board_info.floor_dist[id][board_info.nest_pos_by_code[board_info.initial[id]]];
                    weight*=0.6+0.8*rng.unit();order.emplace_back(-weight,id);
                }
                sort(order.begin(),order.end());
                if(order.size()>=2&&order.size()<=4) {
                    LOCAL_NOTE(two_order=true;)
                    vector<Move> rebuilt;
                    ok=insert_two_orders(initial,base,order,int(current.size())+4,rebuilt);
                    if(ok)base=move(rebuilt);
                    else {LOCAL_NOTE(local_dependency.insert_failed+=dependency;)}
                }else {
                    for(auto [unused,id]:order) {
                        time_keeper.check();vector<Move> next;
                        int cap=int(current.size())+4-int(base.size());
                        if(!insert(initial,base,id,cap,next)){
                            LOCAL_NOTE(local_dependency.insert_failed+=dependency;)
                            ok=false;break;
                        }
                        ++insertions;base=move(next);initial[id]=board_info.initial[id];
                    }
                }
                if(ok){trial=move(base);LOCAL_NOTE(local_dependency.completed+=dependency;)}
            }
            if(!ok)continue;
            LOCAL_NOTE(if(repair_priority_broken>=0){
                trace.count_by("lns_repair_priority_completed",1);
                trace.count_by("lns_repair_priority_penalized_completed",repair_priority_broken>0);
            })
            if(same_moves(trial,current)){++duplicates;continue;}
            vector<Move> polished;
            // 経路短縮は操作を再生し、変更区間の全盤面一致と最後の全帰巣を確認する。
            try{polished=smooth_routes(trial);}catch(const exception&){LOCAL_NOTE(trace.count_by("lns_invalid_candidates", 1);)continue;}
            shortcuts+=int(trial.size())-int(polished.size());
            LOCAL_NOTE(const size_t before_reductions=polished.size();const auto savings_before=search_reductions.saved;)
            search_reductions.candidate(polished,current,best.size(),iteration,lns_start,end);
            LOCAL_NOTE(
                ++search_reductions.candidates;search_reductions.shortened+=polished.size()<before_reductions;
                search_reductions.nonworse_created+=before_reductions>current.size()&&polished.size()<=current.size();
                search_reductions.best_created+=before_reductions>=best.size()&&polished.size()<best.size();
                auto probability=[&](size_t n){int d=int(n)-int(current.size());return d<=0?1.0:(d<=2&&n<=best.size()+4?exp(-d/temperature):0.0);};
                search_reductions.probability_changed+=probability(before_reductions)!=probability(polished.size());
            )
            if(same_moves(polished,current)){++duplicates;continue;}
            int delta=int(polished.size())-int(current.size());
            LOCAL_NOTE(if(dependency&&delta<0){
                ++local_dependency.current_improvements;local_dependency.current_saved-=delta;
            })
            LOCAL_NOTE(if(late_kind>=0&&delta<0){
                ++local_late_start.current_improvements[late_kind];
                local_late_start.current_saved[late_kind]-=delta;
            })
            bool accept=delta<=0||(delta<=2&&polished.size()<=best.size()+4&&rng.unit()<exp(-delta/temperature));
            if(accept) {
                LOCAL_NOTE(
                    search_reductions.accepted_shortened+=polished.size()<before_reductions;
                    for(int kind=0;kind<FINAL_KINDS;kind++)search_reductions.accepted_saved[kind]+=search_reductions.saved[kind]-savings_before[kind];
                )
                LOCAL_NOTE(if(repair_priority_broken>=0){
                    trace.count_by("lns_repair_priority_accepted",1);
                    trace.count_by("lns_repair_priority_penalized_accepted",repair_priority_broken>0);
                })
                ++accepted;uphill+=delta>0;block_accepted+=packet;flexible_accepted+=flexible;paired_accepted+=paired;
                LOCAL_NOTE(local_backward_accepted += backward;)
                LOCAL_NOTE(local_dependency.accepted+=dependency;)
                LOCAL_NOTE(if(two_order){
                    ++local_two_order.accepted;
                    local_two_order.alternate_accepted+=local_two_order_alternate;
                })
                LOCAL_NOTE(if(late_kind>=0)++local_late_start.accepted[late_kind];)
                if(polished.size()<best.size()) {
                    int saved=int(best.size()-polished.size());
                    LOCAL_NOTE(if(repair_priority_broken>=0){
                        trace.count_by("lns_repair_priority_improvements",1);
                        trace.count_by("lns_repair_priority_saved",saved);
                        trace.count_by("lns_repair_priority_penalized_saved",repair_priority_broken>0?saved:0);
                    })
                    LOCAL_NOTE(if(two_order){
                        ++local_two_order.improvements;local_two_order.saved+=saved;
                        if(local_two_order_alternate){
                            ++local_two_order.alternate_improvements;local_two_order.alternate_saved+=saved;
                        }
                    })
                    LOCAL_NOTE(if(dependency){++local_dependency.improvements;local_dependency.saved+=saved;})
                    LOCAL_NOTE(if(late_kind>=0){
                        ++local_late_start.improvements[late_kind];local_late_start.saved[late_kind]+=saved;
                    })
                    LOCAL_NOTE(
                        trace.count_by("lns_best_saved", saved);
                        trace.count_by("lns_regular_saved", !packet && !reorder && !paired ? saved : 0);
                        trace.count_by("lns_packet_saved", packet && !flexible ? saved : 0);
                    )
                    ++improvements;block_improvements+=packet;
                    flexible_improvements+=flexible;flexible_saved+=flexible?saved:0;
                    reorder_improvements+=reorder;reorder_saved+=reorder?saved:0;
                    paired_improvements+=paired;paired_saved+=paired?saved:0;
                    backward_improvements+=backward;backward_saved+=backward?saved:0;
                    best=polished;stagnant=0;
                }
                current=move(polished);trajectory_changed();
            }
        }
    }

};

#ifdef LOCAL
// 個体IDと可変長の塔で独立再生し、ビット表現と再挿入器から独立に検証する。
void validate_output(const vector<Move>& answer) {
    array<vector<int>, max_cells> tower;
    array<bool, max_cells> returned{};
    int E = board_info.M, long_jumps = 0, mixed_moves = 0, max_height = 1, max_packet = 0;
    for (int p = 0; p < board_info.cell_count; ++p) if (board_info.initial[p]) tower[p].push_back(p);
    assert(answer.size() <= 100000);
    for (const auto& op : answer) {
        assert(0 <= op.p && op.p < board_info.cell_count && op.d < 4);
        const int p = op.p, h = int(tower[p].size()), k = op.k, l = op.l;
        assert(0 <= k && k < h && 1 <= l && l <= k + 1);
        int q = -1;
        for (int step = 1; step <= l; ++step) {
            const int row = board_info.row[p] + board_info.di[op.d] * step;
            const int col = board_info.col[p] + board_info.dj[op.d] * step;
            assert(0 <= row && row < board_info.N && 0 <= col && col < board_info.N);
            q = board_info.cell_id[row][col];
            assert(q >= 0);
        }
        const int g = int(tower[q].size());
        assert(g + h - k <= 8);
        bool mixed = false;
        for (int j = k + 1; j < h; ++j)
            mixed |= board_info.initial[tower[p][j]] != board_info.initial[tower[p][k]];
        mixed_moves += mixed;
        long_jumps += l > 1;
        max_height = max(max_height, g + h - k);
        max_packet = max(max_packet, h - k);
        while (int(tower[p].size()) > k) {
            tower[q].push_back(tower[p].back());
            tower[p].pop_back();
        }
        for (int v : {p, q}) {
            while (!tower[v].empty() && board_info.initial[tower[v].back()] == TowerBits(board_info.nest_code[v])) {
                const int id = tower[v].back();
                assert(!returned[id]);
                returned[id] = true;
                tower[v].pop_back();
                --E;
            }
        }
    }
    for (int p = 0; p < board_info.cell_count; ++p) {
        assert(tower[p].empty());
        if (board_info.initial[p]) assert(returned[p]);
    }
    assert(E == 0);
    trace.count_by("T", answer.size());
    trace.count_by("E", E);
    trace.count_by("validated_moves", answer.size());
    trace.count_by("delivered_slimes", board_info.M);
    trace.count_by("output_long_jumps", long_jumps);
    trace.count_by("output_mixed_moves", mixed_moves);
    trace.count_by("output_max_height", max_height);
    trace.count_by("output_max_packet", max_packet);
}
#endif


// 構築直後には同手数でも、その後の短縮余地が異なり得るため別の操作列を残す。
struct NeuralPortfolioStats {
    int attempted=1,completed=1,incomplete=0,retained=1,winner=-1;
    int first_ops=0;uint64_t first_hash=0;
    double first_seconds=0,extra_seconds=0;
    array<int,5> origin{},raw{},pilot{},final{};
} neural_portfolio;

struct InitialSolutions {
    struct Entry { vector<Move> moves; int origin; };
    vector<Entry> entries;
    void offer(const vector<Move>& moves,int origin) {
        LOCAL_ONLY(trace.count_by("race_offered",1));
        for(const auto& entry:entries) {
            if(entry.moves.size()!=moves.size())continue;
            bool same=true;
            for(size_t i=0;i<moves.size();i++) {
                const auto a=entry.moves[i],b=moves[i];
                if(a.p!=b.p||a.k!=b.k||a.d!=b.d||a.l!=b.l){same=false;break;}
            }
            if(same){LOCAL_ONLY(trace.count_by("race_duplicates",1));return;}
        }
        const auto at=upper_bound(entries.begin(),entries.end(),moves.size(),
            [](size_t size,const Entry& entry){return size<entry.moves.size();});
        if(at==entries.end()&&entries.size()==5)return;
        entries.insert(at,Entry{moves,origin});
        if(entries.size()>5)entries.pop_back();
        LOCAL_ONLY(trace.count_by("race_retained",1));
    }
    size_t construction_cap() const {
        // 最長候補と同じ手数まで完成させ、別の初期解を選抜へ渡せるようにする。
        return entries.back().moves.size()+1;
    }
};

void grow_initial_solutions(vector<Move>& best,InitialSolutions& pool,TemporalLNS& total) {
#ifdef LOCAL
    const double start=time_keeper.exact_elapsed_sec(),end=PROGRAM_TIME_LIMIT_SEC;
#else
    const double start=time_keeper.exact_elapsed_sec(),end=LOCAL_SECONDS(1.900);
#endif
    const double budget=max(0.0,end-start);
    const int count=int(pool.entries.size());
    neural_portfolio.retained=count;
    for(int i=0;i<count;++i){neural_portfolio.origin[i]=pool.entries[i].origin;neural_portfolio.raw[i]=int(pool.entries[i].moves.size());}
    if(count==0)throw logic_error("empty initial solution pool");
    vector<unique_ptr<TemporalLNS>> searches;
    vector<int> active(count);iota(active.begin(),active.end(),0);
    for(int id=0;id<count;id++) {
        searches.push_back(make_unique<TemporalLNS>());
        searches.back()->random_state=rng.next();
        LOCAL_ONLY(
            trace.count_by("race_seed_"+to_string(id)+"_initial_ops",pool.entries[id].moves.size());
            trace.count_by("race_seed_"+to_string(id)+"_origin",pool.entries[id].origin);
            trace.count_by("race_seed_"+to_string(id)+"_collection_plans",
                0);
        );
    }
    total.started_at=start;
    LOCAL_ONLY(trace.count_by("race_seed_count",count));
    auto grow=[&](int id,double until,[[maybe_unused]] int round) {
        LOCAL_NOTE(const double began=time_keeper.exact_elapsed_sec();const int previous_attempts=searches[id]->attempts;)
        auto record=[&]() {
            LOCAL_ONLY(
                const string prefix="race_round_"+to_string(round);
                trace.count_by(prefix+"_grown",1);
                trace.count_by(prefix+"_seed_"+to_string(id)+"_ops",pool.entries[id].moves.size());
                trace.count_by(prefix+"_seed_"+to_string(id)+"_attempts",searches[id]->attempts-previous_attempts);
                trace.add_time_ms(prefix,(time_keeper.exact_elapsed_sec()-began)*1000.0);
            );
        };
        try { searches[id]->optimize(pool.entries[id].moves,until,start,end); }
        catch(...) {
            if(pool.entries[id].moves.size()<best.size())best=pool.entries[id].moves;
            record();
            throw;
        }
        if(pool.entries[id].moves.size()<best.size())best=pool.entries[id].moves;
        record();
    };
    auto summarize=[&]() {
        for(int id=0;id<count;id++) {
            neural_portfolio.final[id]=int(pool.entries[id].moves.size());
            total.accumulate(*searches[id]);
            LOCAL_ONLY(trace.count_by("race_seed_"+to_string(id)+"_final_ops",pool.entries[id].moves.size()));
        }
    };
    try {
        // 最初の2段階に各15%を使い、最短候補の継続探索へ70%を残す。
        for(int round=0;round<2&&active.size()>1;round++) {
            const double round_end=start+budget*(0.15*(round+1));
            for(size_t pos=0;pos<active.size();pos++) {
                const double now=time_keeper.exact_elapsed_sec();
                const double until=now+max(0.0,round_end-now)/double(active.size()-pos);
                grow(active[pos],until,round);
            }
            sort(active.begin(),active.end(),[&](int a,int b) {
                const size_t left=pool.entries[a].moves.size(),right=pool.entries[b].moves.size();
                return left!=right?left<right:a<b;
            });
            active.resize(round==0?(active.size()+1)/2:1);
            LOCAL_ONLY(trace.count_by("race_round_"+to_string(round)+"_survivors",active.size()));
        }
        const int winner=active.front();
        neural_portfolio.winner=winner;
        for(int i=0;i<count;++i)neural_portfolio.pilot[i]=int(pool.entries[i].moves.size());
        LOCAL_ONLY(
            trace.count_by("race_winner_initial_rank",winner);
            trace.count_by("race_winner_changed",winner!=0);
            trace.count_by("race_selection_saved",int(pool.entries[0].moves.size())-int(pool.entries[winner].moves.size()));
        );
        grow(winner,end,2);
        // 終了後の処理にも、選ばれた探索の乱数列を引き継ぐ。
        rng.x=searches[winner]->random_state;
    } catch(...) {summarize();throw;}
    summarize();
}


// NNとLNSは同じ開始時刻を参照する。NNの準備と変換の費用も探索時間から引く。
struct NNSharedDeadline {
    double limit;
    bool step() const {return time_keeper.exact_elapsed_sec()<limit;}
};

// D4 transform: rotate clockwise by (sym&3)*90 degrees, then mirror columns.
// It changes the policy's view, never the problem's objective or color names.
static pair<int,int> neural_transform_cell(int i,int j,int N,int sym,bool inverse=false) {
    if(inverse) {
        if(sym&4)j=N-1-j;
        for(int n=0;n<(sym&3);++n){const int old=i;i=N-1-j;j=old;}
    } else {
        for(int n=0;n<(sym&3);++n){const int old=i;i=j;j=N-1-old;}
        if(sym&4)j=N-1-j;
    }
    return {i,j};
}
static nn::Input neural_transform_input(const nn::Input& input,int sym) {
    nn::Input transformed;transformed.N=input.N;transformed.K=input.K;
    transformed.C.assign(input.N,string(input.N,'#'));
    for(int i=0;i<input.N;++i)for(int j=0;j<input.N;++j) {
        const auto [r,c]=neural_transform_cell(i,j,input.N,sym);
        transformed.C[r][c]=input.C[i][j];
    }
    return transformed;
}
static vector<Move> neural_restore_path(const nn::Board& board,const nn::SearchResult& result,int sym) {
    vector<Move> moves;moves.reserve(result.path.size());State checked=board_info.initial;
    for(nn::Move m:result.path) {
        const auto [i,j]=board.coordinates[m.p()];
        const auto [r,c]=neural_transform_cell(i,j,board_info.N,sym,true);
        const auto [qi,qj]=board.coordinates[board.ray[m.p()][m.d()][m.l()-1]];
        const auto [qr,qc]=neural_transform_cell(qi,qj,board_info.N,sym,true);
        const int direction=qr<r?0:qr>r?1:qc<c?2:3;
        const Move converted{int16_t(board_info.cell_id[r][c]),uint8_t(m.k()),uint8_t(direction),uint8_t(m.l())};
        board_info.apply(checked,converted);moves.push_back(converted);
    }
    if(board_info.count(checked)!=result.E)throw logic_error("symmetry conversion mismatch");
    return moves;
}
static void neural_extra_starts(const nn::Input& input,InitialSolutions& pool,vector<Move>& best) {
#ifndef V311_SINGLE_SEED
    const double deadline=0.30*PROGRAM_TIME_LIMIT_SEC;
    double estimated=neural_portfolio.first_seconds;
    for(int sym:{4,1,5}) {
        const double now=time_keeper.exact_elapsed_sec();
        if(now+1.35*estimated>=deadline)break;
        ++neural_portfolio.attempted;
        const auto transformed=neural_transform_input(input,sym);
        const nn::Board board(transformed);const nn::BoardState initial(transformed,board);
        NNSharedDeadline timer{deadline};
        const auto result=nn::search(transformed,board,initial,timer);
        estimated=time_keeper.exact_elapsed_sec()-now;
        neural_portfolio.extra_seconds+=estimated;
        auto moves=neural_restore_path(board,result,sym);
        // This is an anytime portfolio: incomplete proposals are recorded and
        // not confused with completed seeds. The completed incumbent is valid.
        if(result.E){++neural_portfolio.incomplete;continue;}
        ++neural_portfolio.completed;
        pool.offer(moves,-3110-sym);
        if(moves.size()<best.size())best=move(moves);
    }
#else
    (void)input;(void)pool;(void)best;
#endif
}

int main() {
#ifdef LOCAL
    time_keeper.start_=chrono::steady_clock::now();
    for(const string key:{"finish_singles_calls","baseline_recovery","final_recovery",
        "construction_errors","lns_errors","construction_deadlines","lns_deadlines",
        "lns_initial_shortcut_saved","lns_initial_reorder_saved","lns_best_saved",
        "lns_regular_saved","lns_packet_saved","lns_invalid_candidates"})trace.count_by(key,0);
#endif
    ios::sync_with_stdio(false);cin.tie(nullptr);
    board_info.read();state_pool.prepare(board_info.cell_count);
    for(int p=0;p<board_info.cell_count;p++)
        rng.x=(rng.x^(board_info.initial[p]+17*board_info.nest_code[p]+p))*0x9e3779b97f4a7c15ULL;
    nn::load_nn();nn::Input input;input.N=board_info.N;input.K=board_info.K;input.C.resize(input.N);
    for(int i=0;i<input.N;i++)input.C[i]=board_info.C[i];
    const nn::Board board(input);const nn::BoardState initial(input,board);
#ifdef LOCAL
    NNSharedDeadline timer{PROGRAM_TIME_LIMIT_SEC};
#else
    NNSharedDeadline timer{LOCAL_SECONDS(1.900)};
#endif
    const double first_nn_start=time_keeper.exact_elapsed_sec();
    const auto result=nn::search(input,board,initial,timer);
    neural_portfolio.first_seconds=time_keeper.exact_elapsed_sec()-first_nn_start;
    vector<Move> best;best.reserve(result.path.size());
    uint64_t hash=1469598103934665603ULL;
    {
        State checked=board_info.initial;
        for(nn::Move m:result.path){
            const auto [i,j]=board.coordinates[m.p()];
            Move converted{int16_t(board_info.cell_id[i][j]),uint8_t(m.k()),uint8_t(m.d()),uint8_t(m.l())};
            board_info.apply(checked,converted);best.push_back(converted);
            const uint64_t code=(((uint64_t(i*20+j)*8+m.k())*4+m.d())*8+m.l()-1);
            hash=(hash^code)*1099511628211ULL;
        }
        if(board_info.count(checked)!=result.E)throw logic_error("NN operation conversion mismatch");
    }
    LOCAL_ONLY(
        trace.count_by("initial_E",initial.E);trace.count_by("nn_initial_ops",best.size());
        trace.count_by("nn_initial_hash",hash&0x7fffffffffffffffULL);
        trace.count_by("nn_complete",result.E==0);trace.count_by("inferences",result.inferences);
        trace.count_by("depth",result.depth);trace.count_by("deadline",result.deadline);
        trace.count_by("duplicates",result.duplicates);trace.count_by("exhausted",result.exhausted);
        trace.add_time_ms("nn_initial",time_keeper.exact_elapsed_sec()*1000.0);
    );
    // NNの未完了はそのまま記録する。完成解を前提とするLNSには渡さない。
    if(result.E!=0){
        for(auto m:best)cout<<board_info.row[m.p]<<' '<<board_info.col[m.p]<<' '<<int(m.k)<<' '
            <<board_info.dirs[m.d]<<' '<<int(m.l)<<'\n';
        LOCAL_ONLY(trace.count_by("E",result.E);trace.count_by("T",best.size());trace.count_by("cnn_calls",nn::incremental_stats.calls);
        trace.count_by("cnn_full",nn::incremental_stats.full);
        trace.count_by("cnn_home",nn::incremental_stats.home);
        trace.count_by("cnn_incremental",nn::incremental_stats.incremental);
        trace.count_by("cnn_full_cells_per_layer",nn::incremental_stats.full_cells);
        for(int b=0;b<=nn::NN_DEPTH;++b)trace.count_by("cnn_cells_"+to_string(b),nn::incremental_stats.cells[b]);
        trace.summary(););
        return 0;
    }
    const size_t baseline=best.size();
    neural_portfolio.first_ops=int(best.size());neural_portfolio.first_hash=hash;
    InitialSolutions initial_solutions;initial_solutions.offer(best,-105);
    neural_extra_starts(input,initial_solutions,best);
    const int completed=neural_portfolio.completed,attempts=neural_portfolio.attempted;
    size_t before_lns=best.size();
#ifdef LOCAL
    trace.add_time_ms("construction", time_keeper.exact_elapsed_sec() * 1000.0);
    const auto local_lns_started = chrono::steady_clock::now();
#endif
    time_keeper.time_limit_sec=LOCAL_SECONDS(1.930);
    LOCAL_ONLY(trace.count_by("selector_nn_enabled",nn_selector_choice(nn_selector_features()));trace.count_by("selector_M",board_info.M));
    TemporalLNS lns;
    try {grow_initial_solutions(best,initial_solutions,lns);}
    catch(const Deadline&){LOCAL_NOTE(trace.count_by("lns_deadlines", 1);)}
    catch(const exception& e){LOCAL_NOTE(trace.count_by("lns_errors", 1);)cerr<<"LNS diagnostic: "<<e.what()<<'\n';}
#ifdef LOCAL
    trace.add_time_ms("temporal_lns", chrono::duration<double, milli>(chrono::steady_clock::now() - local_lns_started).count());
#endif
    // 線形走査の転送圧縮を行い、探索の短縮と分けて集計する。
    const size_t pre_pair_ops=best.size();
    best=LOCAL_TIME(trace,"pair_transfer_compression",[&]{return compress_pair_transfers(best);});
    // 残った終了処理の時間で共同短縮する。探索途中で期限に達した区間は置換しない。
    const size_t pre_joint_ops=best.size();
    JointWindowStats joint_stats;
    best=LOCAL_TIME(trace,"joint_window",[&]{return compress_joint_windows(best,time_keeper.time_limit_sec,joint_stats);});
    joint_stats.summary();
    LOCAL_NOTE(trace.count_by("pre_joint_ops",pre_joint_ops);)
    [[maybe_unused]] const size_t pre_final_reductions_ops=best.size();
    FinalReductionStats final_reduction_stats;
    LOCAL_TIME(trace,"final_reductions",[&]{polish_final_reductions(best,final_reduction_stats);});
    final_reduction_stats.summary();
    LOCAL_NOTE(trace.count_by("pre_final_reductions_ops",pre_final_reductions_ops);)
    {
        State check=board_info.initial;
        for(auto m:best)board_info.apply(check,m);
        if(board_info.count(check)||best.size()>100000)throw logic_error("final answer check");
    }

    cerr<<"v311_nn_first_ops="<<neural_portfolio.first_ops
        <<" v311_nn_first_hash="<<neural_portfolio.first_hash
        <<" v311_nn_first_seconds="<<neural_portfolio.first_seconds
        <<" v311_nn_extra_seconds="<<neural_portfolio.extra_seconds
        <<" v311_nn_attempted="<<neural_portfolio.attempted
        <<" v311_nn_completed="<<neural_portfolio.completed
        <<" v311_nn_incomplete="<<neural_portfolio.incomplete
        <<" v311_nn_retained="<<neural_portfolio.retained
        <<" v311_winner="<<neural_portfolio.winner;
    for(int i=0;i<neural_portfolio.retained;++i)
        cerr<<" v311_seed_"<<i<<"_origin="<<neural_portfolio.origin[i]
            <<" v311_seed_"<<i<<"_raw="<<neural_portfolio.raw[i]
            <<" v311_seed_"<<i<<"_pilot="<<neural_portfolio.pilot[i]
            <<" v311_seed_"<<i<<"_final="<<neural_portfolio.final[i];
    cerr<<'\n';
    cerr<<"baseline="<<baseline<<" best="<<best.size()<<" pre_lns="<<before_lns<<" pre_pair="<<pre_pair_ops<<" pre_joint="<<pre_joint_ops
        <<" completed="<<completed<<" attempts="<<attempts<<" dp_words="<<0
        <<" lns_attempts="<<lns.attempts<<" insertions="<<lns.insertions
        <<" accepted="<<lns.accepted<<" improvements="<<lns.improvements<<" shortcuts="<<lns.shortcuts
        <<" block_attempts="<<lns.block_attempts<<" block_accepted="<<lns.block_accepted
        <<" block_improvements="<<lns.block_improvements<<" uphill="<<lns.uphill<<" restarts="<<lns.restarts
        <<" flexible_attempts="<<lns.flexible_attempts<<" flexible_accepted="<<lns.flexible_accepted
        <<" flexible_improvements="<<lns.flexible_improvements<<" flexible_saved="<<lns.flexible_saved
        <<" reorder_attempts="<<lns.reorder_attempts<<" reorder_improvements="<<lns.reorder_improvements
        <<" reorder_saved="<<lns.reorder_saved<<" duplicates="<<lns.duplicates
        <<" build_seconds="<<lns.build_seconds<<" lns_start="<<lns.started_at
        <<" full_builds="<<lns.full_builds<<" history_only_builds="<<lns.history_only_builds<<" packet_only_builds="<<lns.packet_only_builds
        <<" score_refreshes="<<lns.score_refreshes<<" stale_bank_selections="<<lns.stale_bank_selections
        <<" full_build_seconds="<<lns.full_build_seconds<<" history_only_seconds="<<lns.history_only_seconds<<" packet_only_seconds="<<lns.packet_only_seconds
        <<" alias_closures="<<lns.alias_closures<<" alias_gap_relaxations="<<lns.alias_gap_relaxations
        <<" alias_top_relaxations="<<lns.alias_top_relaxations<<" alias_cost_relaxations="<<lns.alias_cost_relaxations
        <<" block_seconds="<<lns.block_seconds
        <<" paired_attempts="<<lns.paired_attempts<<" paired_accepted="<<lns.paired_accepted
        <<" paired_improvements="<<lns.paired_improvements<<" paired_saved="<<lns.paired_saved
        <<" paired_seconds="<<lns.paired_seconds
        <<" backward_attempts="<<lns.backward_attempts<<" backward_improvements="<<lns.backward_improvements
        <<" backward_saved="<<lns.backward_saved
        <<" elapsed="<<fixed<<setprecision(6)<<time_keeper.exact_elapsed_sec()<<'\n';
#ifdef LOCAL
    LOCAL_ONLY(
        LOCAL_TIME(trace, "validate", [&] { validate_output(best); });
        trace.count_by("floor_cells", board_info.cell_count);
        trace.count_by("state_payload_bytes", state_pool.bytes);
        trace.count_by("state_handle_bytes", sizeof(State));
        trace.count_by("state_slots", StatePool::slots);
        trace.count_by("state_pool_bytes", state_pool.bytes * StatePool::slots);
        trace.count_by("state_pool_free_at_end", state_pool.free_count);
        trace.count_by("baseline_ops", baseline);
        trace.count_by("pre_lns_ops", before_lns);
        trace.count_by("pre_pair_ops", pre_pair_ops);
        trace.count_by("final_ops", best.size());
        trace.count_by("construction_completed", completed);
        trace.count_by("construction_attempts", attempts);
        trace.count_by("dp_words", 0);
        trace.count_by("lns_attempts", lns.attempts);
        trace.count_by("lns_insertions", lns.insertions);
        trace.count_by("lns_accepted", lns.accepted);
        trace.count_by("lns_improvements", lns.improvements);
        trace.count_by("lns_candidate_shortcuts", lns.shortcuts);
        trace.count_by("lns_saved", int(before_lns) - int(pre_pair_ops));
        trace.add_time_ms("search_limit", LOCAL_SECONDS(1.930) * 1000.0);
        trace.add_time_ms("total", time_keeper.exact_elapsed_sec() * 1000.0);
        trace.count_by("lns_block_attempts", lns.block_attempts);
        trace.count_by("lns_block_accepted", lns.block_accepted);
        trace.count_by("lns_block_improvements", lns.block_improvements);
        trace.count_by("lns_flexible_attempts", lns.flexible_attempts);
        trace.count_by("lns_flexible_accepted", lns.flexible_accepted);
        trace.count_by("lns_flexible_improvements", lns.flexible_improvements);
        trace.count_by("lns_flexible_saved", lns.flexible_saved);
        trace.count_by("lns_reorder_attempts", lns.reorder_attempts);
        trace.count_by("lns_reorder_improvements", lns.reorder_improvements);
        trace.count_by("lns_reorder_saved", lns.reorder_saved);
        trace.count_by("lns_uphill", lns.uphill);
        trace.count_by("lns_restarts", lns.restarts);
        trace.count_by("lns_duplicates", lns.duplicates);
        trace.count_by("event_layers", local_event_layers);
        trace.count_by("event_reopens", local_event_reopens);
        trace.count_by("single_insert_calls", local_single_insert_calls);
        trace.count_by("packet_insert_calls", local_packet_insert_calls);
        trace.count_by("local_run_flexible_calls",local_run_flexible_calls);
        trace.count_by("local_run_paired_calls",local_run_paired_calls);
        trace.count_by("local_run_reinsert_calls",local_run_reinsert_calls);
        trace.count_by("local_run_reinserted_slimes",local_run_reinserted_slimes);
        trace.count_by("local_run_multi_calls",local_run_multi_calls);
        trace.count_by("local_run_multi_completed",local_run_multi_completed);
        trace.count_by("local_run_completed",local_run_completed);
        trace.count_by("local_run_completed_slimes",local_run_completed_slimes);
        trace.add_time_ms("lns_candidate_build", lns.build_seconds * 1000.0);
        trace.add_time_ms("lns_block_search", lns.block_seconds * 1000.0);
        trace.add_time_ms("lns_start", lns.started_at * 1000.0);
        trace.count_by("lns_paired_attempts", lns.paired_attempts);
        trace.count_by("lns_paired_accepted", lns.paired_accepted);
        trace.count_by("lns_paired_improvements", lns.paired_improvements);
        trace.count_by("lns_paired_saved", lns.paired_saved);
        trace.count_by("lns_backward_attempts", lns.backward_attempts);
        trace.count_by("lns_backward_improvements", lns.backward_improvements);
        trace.count_by("lns_backward_saved", lns.backward_saved);
        trace.count_by("lns_backward_accepted", local_backward_accepted);
        trace.count_by("shortcut_support_states", local_shortcut_support_states);
        trace.add_time_ms("lns_paired_search", lns.paired_seconds * 1000.0);
        local_dependency.summary();local_late_start.summary();local_two_order.summary();search_reductions.summary();
        local_nn.summary();trace.count_by("E",0);trace.count_by("T",best.size());trace.count_by("cnn_calls",nn::incremental_stats.calls);
        trace.count_by("cnn_full",nn::incremental_stats.full);
        trace.count_by("cnn_home",nn::incremental_stats.home);
        trace.count_by("cnn_incremental",nn::incremental_stats.incremental);
        trace.count_by("cnn_full_cells_per_layer",nn::incremental_stats.full_cells);
        for(int b=0;b<=nn::NN_DEPTH;++b)trace.count_by("cnn_cells_"+to_string(b),nn::incremental_stats.cells[b]);
        trace.summary();
    );
#endif
    for(auto m:best)cout<<board_info.row[m.p]<<' '<<board_info.col[m.p]<<' '<<int(m.k)<<' '
                         <<board_info.dirs[m.d]<<' '<<int(m.l)<<'\n';
}
