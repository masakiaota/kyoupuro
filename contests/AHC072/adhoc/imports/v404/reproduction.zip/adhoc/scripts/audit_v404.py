#!/usr/bin/env python3
"""Build/preprocess-only audit. Does not run the solver."""
from pathlib import Path
import subprocess,os,re,difflib,hashlib,json
r=Path(__file__).resolve().parents[2];o=r/'results/analysis/v404';source=r/'src/bin/v404_incremental_reactive_racing.cpp';parent=r/'adhoc/imports/v401/original.cpp.txt';s=source.read_text();p=parent.read_text()
# Exact source regions outside scheduler and emitted audit summary.
def strip(text,is_child):
 lines=text.splitlines(True);text=''.join(line for line in lines if not line.startswith('// v404') and not line.startswith('// v401_incremental_cnn.cpp') and 'cerr<<"v315_slices="' not in line)
 start=text.index('struct ReactiveRaceStats' if is_child else 'void grow_initial_solutions');end=text.index('// NNとLNSは同じ開始時刻',start)
 return text[:start]+text[end:]
assert strip(s,True)==strip(p,False),'outside scheduler source differs'
results={}
for mode,flags in [('local',['-DLOCAL']),('nonlocal',['-DATCODER','-DONLINE_JUDGE','-DNOMINMAX'])]:
 pp=[]
 for name,path in [('parent',parent),('candidate',source)]:
  dest=o/f'{name}_{mode}.ii'
  with dest.open('w') as out:subprocess.run([os.environ['CXX'],'-x','c++','-std=gnu++23','-E','-P',*flags,str(path)],stdout=out,check=True)
  text=dest.read_text();text=text.replace(str(path),'SOURCE');text=re.sub(r'"SOURCE",\s*\d+,','"SOURCE", LINE,',text)
  pp.append(text)
 diff=''.join(difflib.unified_diff(pp[0].splitlines(True),pp[1].splitlines(True),fromfile='cloud401_'+mode,tofile='v404_'+mode));(o/f'preprocessed_{mode}.patch').write_text(diff)
 # All actual preprocessed behavior outside schedule and one summary must match.
 def clean(text,child):
  a=text.index('struct ReactiveRaceStats' if child else 'void grow_initial_solutions');b=text.index('struct NNSharedDeadline',a)
  text=text[:a]+text[b:]
  return ''.join(line for line in text.splitlines(True) if 'cerr<<"v315_slices="' not in line)
 assert clean(pp[0],False)==clean(pp[1],True),(mode,'preprocessed outside scheduler mismatch')
 binary=o/f'v404_{mode}'
 cmd=[os.environ['CXX'],'-std=gnu++23','-O2','-Wall','-Wextra','-march=native','-pthread','-ftrivial-auto-var-init=zero','-fopenmp',*flags,str(source),'-o',str(binary)]
 with (o/f'build_{mode}.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
 results[mode]={'build_ok':True,'full_preprocessed_outside_scheduler_and_summary_equal':True,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest()}
result={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'parent_sha256':hashlib.sha256(parent.read_bytes()).hexdigest(),'source_outside_scheduler_and_audit_exact':True,'NN_cache_weights_LNS_validators_clocks_exact':True,'modes':results}
(o/'static_audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
