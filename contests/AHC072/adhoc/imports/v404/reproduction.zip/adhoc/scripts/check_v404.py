#!/usr/bin/env python3
"""Small allocator-only fixture: extracted real functions, mocked work, independent reference.
Never runs a contest solver or uses contest scores.
"""
from pathlib import Path
import os,subprocess,json,math
r=Path(__file__).resolve().parents[2];o=r/'results/analysis/v404';o.mkdir(exist_ok=True)
stub=r'''#include <bits/stdc++.h>
using namespace std;
#define LOCAL
#define LOCAL_ONLY(...) __VA_ARGS__
#define LOCAL_NOTE(...) __VA_ARGS__
struct Trace {template<class T>void count_by(string,T){} void add_time_ms(string,double){} } trace;
constexpr double PROGRAM_TIME_LIMIT_SEC=100;
struct Clock { double now=0; double exact_elapsed_sec(){return now;} } time_keeper;
struct RNG {uint64_t x=10; uint64_t next(){return ++x;}} rng;
struct Move {int x=0;};
struct Portfolio {int retained=0,winner=-1; int origin[5]{},raw[5]{},pilot[5]{},final[5]{};} neural_portfolio;
struct InitialSolutions {struct Entry {vector<Move> moves;int origin;};vector<Entry> entries;};
int next_id=0,scenario=0;
struct TemporalLNS {
 int id=next_id++,attempts=0,iteration=0;bool initialized=false;uint64_t random_state=1;double started_at=0;
 vector<Move> current;
 void accumulate(const TemporalLNS& s){attempts+=s.attempts;}
 void optimize(vector<Move>& best,double until,double start,double end){
  assert(start==0 || scenario==6);assert(end==100);
  // Saved object and RNG must survive all calls to this candidate.
  assert(iteration==attempts);assert(initialized==(attempts>0));
  const double began=time_keeper.now;
  ++attempts;++iteration; initialized=true;random_state+=7;
  if(scenario==4 && began>=30 && id==1 && best.size()>90)best.resize(90);
  current=best;time_keeper.now=max(time_keeper.now,until);
  cout<<"CALL "<<id<<" "<<setprecision(17)<<began<<" "<<until<<" "<<best.size()<<" "<<attempts<<" "<<random_state<<"\n";
 }
};
'''
main=r'''
int main(int argc,char**argv){scenario=stoi(argv[1]);vector<int> sizes;
 if(scenario==0)sizes={100,101,102,103,104};
 if(scenario==1)sizes={100,100,100,100};
 if(scenario==2)sizes={100,103,200,210};
 if(scenario==3)sizes={100,104,200,210};
 if(scenario==4)sizes={100,102,200,210};
 if(scenario==5)sizes={100};
 if(scenario==6){sizes={100,103,200,210};time_keeper.now=100;}
 if(scenario==7)sizes={200,204,300,310};
 InitialSolutions p; for(int n:sizes)p.entries.push_back({vector<Move>(n),-100-int(p.entries.size())});
 vector<Move> best(sizes[0]);TemporalLNS total;next_id=0;
 grow_initial_solutions(best,p,total);
 cout<<"END "<<reactive_race_stats.slices<<" "<<reactive_race_stats.challenges<<" "<<reactive_race_stats.blocked_challenges<<" "<<reactive_race_stats.swaps<<" "<<reactive_race_stats.pilot_winner<<" "<<reactive_race_stats.final_winner<<" "<<rng.x<<" "<<total.attempts<<"\n";
}
'''
paths={'v315':r/'src/bin/v315_reactive_racing.cpp','v404':r/'src/bin/v404_incremental_reactive_racing.cpp'}
outputs={}
for version,path in paths.items():
 s=path.read_text();a=s.index('struct ReactiveRaceStats');b=s.index('// NNとLNSは同じ開始時刻',a)
 cpp=r/'adhoc/bin'/f'v404_{version}_allocator_probe.cpp';cpp.write_text(stub+s[a:b]+main)
 binary=o/f'{version}_allocator_probe'
 subprocess.run([os.environ['CXX'],'-std=gnu++23','-O2',str(cpp),'-o',str(binary)],check=True)
 outputs[version]=[]
 for case in range(8):
  p=subprocess.run([str(binary),str(case)],text=True,capture_output=True,check=True)
  (o/f'fixture_{version}_{case}.log').write_text(p.stdout+p.stderr)
  outputs[version].append(p.stdout)
assert outputs['v315']==outputs['v404'],'frozen315 parity failed'
# Independent schedule oracle operates on numbers and timed events, no C++ copied.
def reference(case):
 sizes=[[100,101,102,103,104],[100]*4,[100,103,200,210],[100,104,200,210],[100,102,200,210],[100],[100,103,200,210],[200,204,300,310]][case][:]
 n=len(sizes);ids=list(range(n));now=100. if case==6 else 0.;start=now;budget=100-start;calls=[];attempts=[0]*n;rngs=[11+i for i in ids]
 def order():ids.sort(key=lambda i:(sizes[i],i))
 def work(i,deadline):
  nonlocal now
  attempts[i]+=1;rngs[i]+=7
  if case==4 and now>=30 and i==1 and sizes[i]>90:sizes[i]=90
  calls.append((i,now,deadline,sizes[i],attempts[i],rngs[i]));now=max(now,deadline)
 for stage in range(2):
  if len(ids)<2:break
  boundary=start+budget*.15*(stage+1)
  for pos,i in enumerate(ids):work(i,now+max(0,boundary-now)/(len(ids)-pos))
  order();ids=ids[:(len(ids)+1)//2 if stage==0 else min(2,len(ids))]
 order();pilot=last=ids[0];slices=challenges=blocked=swaps=0
 while len(ids)>1 and now<start+budget*.8:
  order();leader=ids[0]
  if leader!=last:swaps+=1;last=leader
  periodic=slices%4==3
  eligible=sizes[ids[1]]-sizes[leader]<=max(3,sizes[leader]//50)
  challenge=periodic and eligible;challenges+=challenge;blocked+=periodic and not eligible
  work(ids[int(challenge)],min(start+budget*.8,now+budget*.04));slices+=1
 order();winner=ids[0];work(winner,100)
 return calls,(slices,challenges,blocked,swaps,pilot,winner,rngs[winner],sum(attempts))
records=[]
for case,actual in enumerate(outputs['v404']):
 lines=actual.splitlines();calls=[tuple(map(float,s.split()[1:])) for s in lines if s.startswith('CALL ')];end=tuple(map(int,lines[-1].split()[1:]));expected,stats=reference(case)
 assert len(calls)==len(expected),(case,calls,expected)
 for a,b in zip(calls,expected):assert all(math.isclose(x,y,rel_tol=1e-12,abs_tol=1e-10) for x,y in zip(a,b)),(case,a,b)
 assert end==stats,(case,end,stats)
 if case==5:assert len(calls)==1 and end[0]==0
 if case==6:assert end[0]==0
 if case in (0,1,2,3,4,7):assert math.isclose(calls[-1][1],80) and calls[-1][2]==100
 if case==3:assert end[1]==0 and end[2]>0
 if case==4:assert end[3]>0 and end[4]!=end[5]
 records.append({'case':case,'name':['five_candidates','tie','gap_boundary3','blocked_gap4','challenger_swap','one_candidate','exhausted_budget','gap_boundary_percent'][case],'calls':len(calls),'slices':end[0],'challenges':end[1],'blocked':end[2],'swaps':end[3],'pass':True})
result={'allocator_only':True,'real_solver_diagnostic_runs':0,'v315_parity':True,'independent_reference':True,'fixtures':records,'gate_passed':True}
(o/'diagnostic_result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
