#!/usr/bin/env python3
"""Package existing v404 evidence only. Never runs solvers."""
from pathlib import Path
import hashlib,json,re,zipfile
r=Path(__file__).resolve().parents[2];o=r/'results/analysis/v404';dest=r/'adhoc/imports/v404';dest.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=r/'src/bin/v404_incremental_reactive_racing.cpp';frozen=json.loads((o/'frozen_manifest.json').read_text());assert sha(source)==frozen['source_sha256']
s=(r/'notes/experiments/v404.md').read_text().split('## 実験後')[0]+'## 実験後\n\n未評価。\n';p=o/'preregistration.md';p.write_text(s);assert sha(p)==frozen['preregistration_sha256']
parent={}
for p in sorted((r/'results/analysis/v401/outputs').glob('*.txt.err')):
 parent[p.name.removesuffix('.err')]={k:v for k,v in re.findall(r'\b(v311_[\w]+)=([^\s]+)',p.read_text())}
(o/'parent_portfolio.json').write_text(json.dumps(parent,indent=2)+'\n')
readme='''v404 frozen experiment evidence (cloud-only private).
The source and experiment note are committed beside this archive, not duplicated here.
Parent cloud401 SHA256 0c241cc3a862d12faf100050df4ea3bafa3c520261d81e5237a41e3c54f25658 is adhoc/imports/v401/original.cpp.txt.
Parent315 SHA256364cab41a22ccb8c5d84bb0b74086dbb4d1ffd635ad735fcdf8231efa21e3538 is src/bin/v315_reactive_racing.cpp.
Unpack into project root (preserve existing files). Inspect scripts before running.
source adhoc/scripts/cloud_toolchain_env.sh
python3 adhoc/scripts/materialize_v404.py      # exact source reconstruction, no solver run
python3 adhoc/scripts/check_v404.py            # allocator-only manufactured fixtures
python3 adhoc/scripts/audit_v404.py            # builds/full preprocessing, no solver run
python3 adhoc/scripts/summarize_v404.py        # saved records/replay only, no solver run
run_v404_eval.py is the archived one-shot standard eval.py wrapper; rerunning the solver requires new explicit user instruction. It intentionally refuses an existing eval.log.
Canonical evaluation: tools/in100, LOCAL1.90/1.930, GCC15.3, j8, one warmup then each scored input once. No real-input diagnostic solver runs.
No binary or multi-megabyte preprocessed duplicate is included; their checksums are in full_artifact_hashes.json, and static_audit.json plus exact patches record equality outside scheduler/audit.
Result and per-case scores: results/analysis/v404/result.json,paired.csv,records.json. All raw100 output/error files in results/out/v404_incremental_reactive_racing. Source frozen after static gate; no postscore edits.
'''
(o/'REPRODUCE.txt').write_text(readme)
artifacts=[source,r/'adhoc/imports/v401/original.cpp.txt',r/'src/bin/v315_reactive_racing.cpp',*o.glob('*.ii'),o/'v404_local',o/'v404_nonlocal']
(o/'full_artifact_hashes.json').write_text(json.dumps({str(p.relative_to(r)):sha(p) for p in artifacts},indent=2)+'\n')
# One copy of each necessary file. Omit binaries and full preprocessed duplicates.
files=[]
for p in sorted(o.iterdir()):
 if p.is_file() and p.suffix in ('.json','.csv','.log','.patch','.md','.txt'):files.append(p)
files += sorted((r/'results/out/v404_incremental_reactive_racing').glob('*'))
files += [r/'results/analysis/cloud_baseline/fixed_reference.json',r/'results/analysis/v401/records.json',r/'results/analysis/v401/result.json']
files += [r/'adhoc/scripts'/n for n in ['materialize_v404.py','check_v404.py','audit_v404.py','run_v404_eval.py','summarize_v404.py','package_v404.py','replay_slime_output.py','cloud_gcc15.py','cloud_toolchain_env.sh']]
files += sorted((r/'adhoc/bin').glob('v404_*_allocator_probe.cpp'))
files=list(dict.fromkeys(files));manifest={str(p.relative_to(r)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in files}
with zipfile.ZipFile(dest/'reproduction.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files:z.write(p,str(p.relative_to(r)))
 z.writestr('V404_CONTENT_MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(dest/'reproduction.zip') as z:
 assert z.testzip() is None
 for name,item in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==item['sha256']
external={'version':'v404','source_sha256':sha(source),'note_sha256':sha(r/'notes/experiments/v404.md'),'zip_sha256':sha(dest/'reproduction.zip'),'zip_bytes':(dest/'reproduction.zip').stat().st_size,'file_count':len(files),'files':manifest}
(dest/'manifest.json').write_text(json.dumps(external,indent=2)+'\n');print(json.dumps({k:v for k,v in external.items() if k!='files'},indent=2))
