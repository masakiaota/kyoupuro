#!/usr/bin/env python3
"""Exact cloud401 plus frozen315 scheduler. No solver execution."""
from pathlib import Path
import hashlib,difflib,json
r=Path(__file__).resolve().parents[2];o=r/'results/analysis/v404';o.mkdir(exist_ok=True)
p=r/'adhoc/imports/v401/original.cpp.txt';q=r/'src/bin/v315_reactive_racing.cpp'
assert hashlib.sha256(p.read_bytes()).hexdigest()=='0c241cc3a862d12faf100050df4ea3bafa3c520261d81e5237a41e3c54f25658'
assert hashlib.sha256(q.read_bytes()).hexdigest()=='364cab41a22ccb8c5d84bb0b74086dbb4d1ffd635ad735fcdf8231efa21e3538'
s=p.read_text();t=q.read_text();a=s.index('void grow_initial_solutions');b=s.index('// NNとLNSは同じ開始時刻',a)
c=t.index('struct ReactiveRaceStats');d=t.index('// NNとLNSは同じ開始時刻',c)
schedule=t[c:d]
# Read-only LOCAL audit at scheduler completion. No clock, RNG or model writes.
audit='''            LOCAL_ONLY(cerr<<"v404_seed_"<<id<<"_attempts="<<searches[id]->attempts
                <<" v404_seed_"<<id<<"_rng="<<searches[id]->random_state<<'\\n';);
'''
needle='            total.accumulate(*searches[id]);\n';assert schedule.count(needle)==1;schedule=schedule.replace(needle,needle+audit)
needle='        rng.x=searches[winner]->random_state;\n';assert schedule.count(needle)==1
schedule=schedule.replace(needle,needle+'        LOCAL_ONLY(cerr<<"v404_scheduler_rng="<<rng.x<<\'\\n\';);\n')
out=s[:a]+schedule+s[b:]
out=out.replace('// v401_incremental_cnn.cpp','// v404_incremental_reactive_racing.cpp\n// v404: exact cloud v401 cache + unchanged v315 two-finalist allocator.',1)
summary=next(line for line in t.splitlines(True) if 'cerr<<"v315_slices="' in line)
needle='    cerr<<"baseline="<<baseline';assert out.count(needle)==1;out=out.replace(needle,summary+needle,1)
path=r/'src/bin/v404_incremental_reactive_racing.cpp'
if path.exists():assert path.read_text()==out,'never overwrite a different candidate'
else:path.write_text(out)
(o/'source.patch').write_text(''.join(difflib.unified_diff(s.splitlines(True),out.splitlines(True),fromfile='cloud401.cpp',tofile='v404.cpp')))
print(hashlib.sha256(path.read_bytes()).hexdigest())
