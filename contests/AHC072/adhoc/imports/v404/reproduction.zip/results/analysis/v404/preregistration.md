---
id: v404
parents:
  - "[[v401]]"
  - "[[v315]]"
---
# v404: 厳密差分CNNと二候補継続育成の組み合わせ

## 実験前

- 仮説: B-165/v401の推論費用削減とB-166/v315の接戦候補継続は別の機構である。評価済みcloud v401にv315の固定配分をそのまま組み合わせれば、同じ時間内の最終手数を改善できる可能性がある。組み合わせ自体を単一仮説とする。v315の改善の大半にはin0005の初期候補数差が含まれ、確定した加算利得とは扱わない。
- 変更: ベースは `adhoc/imports/v401/original.cpp.txt` (SHA256 `0c241cc3a862d12faf100050df4ea3bafa3c520261d81e5237a41e3c54f25658`)。移植済みtop-levelのLOCAL0.80版ではない。`src/bin/v315_reactive_racing.cpp` (SHA256 `364cab41a22ccb8c5d84bb0b74086dbb4d1ffd635ad735fcdf8231efa21e3538`) の配分器を変更せず移す。最初15%で半数、次15%で最大2候補、80%まで総予算4%ずつ、4区間に1回だけ差<=max(3,best/50)なら次点。完成列長と候補IDで再順位付け、最後20%は最良候補、1候補なら中断なし。候補別探索状態・RNG・全体冷却を保持。NN・重み・キャッシュ・初期生成・TemporalLNS・検証・後処理と時間式はv401のまま。v402/v403の修復は加えない。機構はLOCAL/非LOCAL双方に有効、LOCALは1.90/1.930、非LOCALは親のまま。候補別attempts/最終RNGを読むLOCAL監査のみ追加可能。内部initializedは公開せず、既存race_resumesと同一LNS本文で状態継続を確認する。
- 機構確認: 実際の配分関数を切り出した小さな人工fixtureで、同点・閾値内外・挑戦禁止・勝者交代・1候補・予算枯渇・最後20%を検査する。独立期待列およびv315配分器の両方と照合する。実solver追加診断は原則不要。どうしても必要なら予め固定した0001/0019を各1回のみ、診断スコアから調整しない。LOCAL/nonLOCAL両buildと完全前処理差分で配分/監査以外の不変を確認、重みとLNS/検証の同一性を検査する。独立レビュー通過前に本評価しない。本評価ログでslice/challenge/blocked/swap、30%/80%選択、候補origin/raw/pilot/final、attempts/状態とRNGを記録し、初期候補のcloud401との差（特に0005）を別途集計する。
- 採否基準: `tools/in` 100件、LOCAL、GCC15.3、j8、最終内部1.900秒（主探索約1.870466秒）の標準evalをwarmup以外各入力1回だけ実行。全100件公式採点成功・独立再生合法E=0・既存エラー/回復0・state pool全返却・最大外部時間<2000msを必須とする。合計T<=19876かつ固定参照指数>100.30411519283527で採用候補。固定参照は `results/analysis/cloud_baseline/fixed_reference.json` SHA256 `71f2c83402b7f84663a10d735fb1768009e37f7e65ca333c954a6f300ed98d35`、100*mean(reference_score/candidate_score)、切り詰めなし。基準変更・ノイズ再評価・追加学習・v405は行わない。採用指定v214は自動変更しない。
- 履歴照合: 最新AGENTS・backlog・全実験Front Matterは事前調査担当が照合し、関連本文v315/v401/v402/v403とv110の再開条件を確認する。screen結果を `results/analysis/v404/history_screen.json` に保存。B-165のMac側評価とは別のcloud組み合わせ。既存成果と保護対象notations/important_propertiesを変更しない。main一本、private cloudのみ。実装前登録日時2026-10-04 06:35 UTC。
- 停止: 本評価前にソースを凍結し、結果後はソースを変更しない。結果記録と再現物を整えたら報告して停止する。外部公開・AtCoder提出・PC操作をしない。

## 実験後

未評価。
