from pathlib import Path
import hashlib,json,re,zipfile
r=Path(__file__).resolve().parents[2];o=r/'results/analysis/v405';dest=r/'adhoc/imports/v405';dest.mkdir(parents=True,exist_ok=True);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();source=r/'src/bin/v405_actor_projection_cache.cpp';frozen=json.loads((o/'frozen_manifest.json').read_text());assert sha(source)==frozen['source_sha256']
parent={}
for p in sorted((r/'results/analysis/v401/outputs').glob('*.txt.err')):parent[p.name.removesuffix('.err')]={k:v for k,v in re.findall(r'\b(v311_[\w]+)=([^\s]+)',p.read_text())}
(o/'parent_portfolio.json').write_text(json.dumps(parent,indent=2))
(o/'REPRODUCE.txt').write_text('''v405 exact actor source/destination projection cache. Private cloud evidence.
Source and note are committed separately and not duplicated in this ZIP.
Parent adhoc/imports/v401/original.cpp.txt SHA0c241cc3a862d12faf100050df4ea3bafa3c520261d81e5237a41e3c54f25658.
Unpack in repository root preserving existing files; inspect scripts first.
source adhoc/scripts/cloud_toolchain_env.sh
materialize_v405.py reconstructs source; audit_v405.py builds both modes and compares full preprocessing. build_v405_diagnostic.py generates diagnostic C++.
Diagnostic: target/release/v405_diagnostic tools/in/*.txt (requires new explicit authorization to execute again). check_v405_gate.py reads saved diagnostic JSONL and asserts exactness/coverage/strict cost reduction.
run_v405_eval.py performs one standard tools/in100 LOCAL1.90/1.930 j8 evaluation. Existing eval.log is a guard against accidental reexecution. A rerun requires new explicit user instruction.
summarize_v405.py reads saved records, verifies official scores and independent legality. No solver execution.
No duplicate source, input files, binaries, or full preprocessing outputs. Full original artifacts retained privately outside this package; full_artifact_hashes.json records hashes. Exact preprocessed patches included.
''')
artifacts=[source,r/'adhoc/imports/v401/original.cpp.txt',*o.glob('*.ii'),o/'v405_local',o/'v405_nonlocal',r/'target/release/v405_diagnostic',r/'adhoc/bin/v405_diagnostic.cpp']
(o/'full_artifact_hashes.json').write_text(json.dumps({str(p.relative_to(r)):sha(p) for p in artifacts},indent=2))
files=[p for p in sorted(o.iterdir()) if p.is_file() and p.suffix in ('.json','.jsonl','.csv','.log','.patch','.md','.txt','.stderr')]
files+=sorted((r/'results/out/v405_actor_projection_cache').glob('*'))
files+=[r/'results/analysis/cloud_baseline/fixed_reference.json',r/'results/analysis/v401/records.json',r/'results/analysis/v401/result.json']
files+=[r/'adhoc/scripts'/n for n in ['materialize_v405.py','build_v405_diagnostic.py','check_v405_gate.py','audit_v405.py','run_v405_eval.py','summarize_v405.py','package_v405.py','replay_slime_output.py','cloud_gcc15.py','cloud_toolchain_env.sh']]
files=list(dict.fromkeys(files));manifest={str(p.relative_to(r)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in files}
with zipfile.ZipFile(dest/'reproduction.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files:z.write(p,str(p.relative_to(r)))
 z.writestr('V405_CONTENT_MANIFEST.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(dest/'reproduction.zip') as z:
 assert z.testzip() is None
 for name,item in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==item['sha256']
assert (dest/'reproduction.zip').stat().st_size<1000000
external={'version':'v405','source_sha256':sha(source),'note_sha256':sha(r/'notes/experiments/v405.md'),'zip_sha256':sha(dest/'reproduction.zip'),'zip_bytes':(dest/'reproduction.zip').stat().st_size,'file_count':len(files),'files':manifest};(dest/'manifest.json').write_text(json.dumps(external,indent=2));print(json.dumps({k:v for k,v in external.items() if k!='files'},indent=2))
