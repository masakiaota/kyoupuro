from pathlib import Path
r=Path(__file__).resolve().parents[2];s=(r/'src/bin/v405_actor_projection_cache.cpp').read_text();p=(r/'adhoc/imports/v401/original.cpp.txt').read_text()
c=s[:s.index('} // namespace nn')]
a=p.index('struct EncodeCache');b=p.index('struct StateHash',a);ref=p[a:b]
for old,new in [('EncodeCache','ReferenceCache'),('IncrementalStats','ReferenceStats'),('incremental_stats','reference_stats'),('encode(','reference_encode('),('policy(','reference_policy(')]:ref=ref.replace(old,new)
a=p.index('template<class Timer>\nSearchResult search');b=p.index('\n#ifdef V090_DIAGNOSTIC',a);search=p[a:b].replace('SearchResult search(', 'SearchResult reference_search(',1).replace('EncodeCache','ReferenceCache').replace('encode(', 'reference_encode(').replace('policy(', 'reference_policy(')
trans=p[p.index('static pair<int,int> neural_transform_cell'):p.index('static vector<Move> neural_restore_path')]
main=r'''
struct FixedTimer {int calls=0,limit;bool step(){return ++calls<=limit;}};
void require(bool b,const char*m){if(!b)throw std::runtime_error(m);}
void logits_equal(const std::vector<float>&a,const std::vector<float>&b){require(a.size()==b.size()&&!memcmp(a.data(),b.data(),a.size()*sizeof(float)),"logits");}
int main(int argc,char**argv){
 nn::load_nn();
 for(int arg=1;arg<argc;++arg){
  std::ifstream in(argv[arg]);nn::Input input;input.read(in);nn::Board board(input);nn::BoardState initial(input,board);
  auto compare=[&](const auto&x,const auto&y){require(x.E==y.E&&x.path.size()==y.path.size()&&x.depth==y.depth&&x.duplicates==y.duplicates&&x.deadline==y.deadline&&x.exhausted==y.exhausted&&x.inferences==y.inferences,"search metadata");for(size_t j=0;j<x.path.size();++j)require(nn::action_code(board,x.path[j])==nn::action_code(board,y.path[j]),"path");};
  FixedTimer a{0,5000},b{0,5000},sa{0,37},sb{0,37};
  auto x=nn::search(input,board,initial,a),y=nn::reference_search(input,board,initial,b);compare(x,y);require(x.E==0,"original NN incomplete");compare(nn::search(input,board,initial,sa),nn::reference_search(input,board,initial,sb));
  double setup_parent=0,setup_child=0;auto ct=std::chrono::steady_clock::now();std::unique_ptr<nn::EncodeCache>cache;std::unique_ptr<nn::ReferenceCache>ref;auto alloc_child=[&]{ct=std::chrono::steady_clock::now();cache=std::make_unique<nn::EncodeCache>();setup_child=std::chrono::duration<double>(std::chrono::steady_clock::now()-ct).count();};auto alloc_parent=[&]{ct=std::chrono::steady_clock::now();ref=std::make_unique<nn::ReferenceCache>();setup_parent=std::chrono::duration<double>(std::chrono::steady_clock::now()-ct).count();};if(arg%2){alloc_parent();alloc_child();}else{alloc_child();alloc_parent();}nn::BoardState state=initial;
  uint64_t states=0,logits=0,forced=0,dirty_unused=0,later_used=0,role_switch=0,home=0;double parent_sec=setup_parent,child_sec=setup_child;std::array<bool,400>pending{};
  nn::actor_stats={};nn::incremental_stats={};
  for(size_t step=0;step<=x.path.size();++step){
   auto moves=nn::legal_moves(board,state);std::unique_ptr<nn::Encoded> ep,ec;std::vector<float>lp,lc;
   auto oldsv=cache->actor.source_valid,olddv=cache->actor.dest_valid;int oldE=cache->E;
   auto parent=[&]{auto t=std::chrono::steady_clock::now();ep=nn::reference_encode(input,board,state,ref.get());lp=nn::reference_policy(board,state,*ep,moves);parent_sec+=std::chrono::duration<double>(std::chrono::steady_clock::now()-t).count();};
   auto child=[&]{auto t=std::chrono::steady_clock::now();ec=nn::encode(input,board,state,cache.get());lc=nn::policy(board,state,*ec,moves,&cache->actor);child_sec+=std::chrono::duration<double>(std::chrono::steady_clock::now()-t).count();};
   if((arg+step)%2){parent();child();}else{child();parent();}
   require(!memcmp(ep.get(),ec.get(),sizeof(nn::Encoded)),"encoded");logits_equal(lp,lc);logits+=lp.size();++states;home+=oldE>=0&&oldE!=state.E;
   std::array<bool,400>used{};for(auto m:moves){used[m.p()]=true;used[board.ray[m.p()][m.d()][m.l()-1]]=true;}
   for(int p=0;p<board.cell_count;++p){if(pending[p]&&used[p]){++later_used;pending[p]=false;}if((oldsv[p]||olddv[p])&&!cache->actor.source_valid[p]&&!cache->actor.dest_valid[p]&&!used[p]){pending[p]=true;++dirty_unused;}}
   // Force invalidation while preserving the encoded state, including role changes.
   if(step%17==0){auto fc=std::make_unique<nn::EncodeCache>(*cache);fc->invalidate();auto e=nn::encode(input,board,state,fc.get());logits_equal(lp,nn::policy(board,state,*e,moves,&fc->actor));++forced;}
   if(!moves.empty()&&step%19==0){
    auto f=std::make_unique<nn::EncodeCache>();auto e=nn::encode(input,board,state,f.get());
    std::vector<nn::Move>one{moves.front()};nn::policy(board,state,*e,one,&f->actor);
    for(auto m:moves){int q=board.ray[m.p()][m.d()][m.l()-1];if(f->actor.source_valid[q]&&!f->actor.dest_valid[q]){std::vector<nn::Move>v{m};logits_equal(nn::reference_policy(board,state,*e,v),nn::policy(board,state,*e,v,&f->actor));++role_switch;break;}}
   }
   if(step<x.path.size())state.apply(board,x.path[step]);
  }
  ct=std::chrono::steady_clock::now();cache.reset();child_sec+=std::chrono::duration<double>(std::chrono::steady_clock::now()-ct).count();ct=std::chrono::steady_clock::now();ref.reset();parent_sec+=std::chrono::duration<double>(std::chrono::steady_clock::now()-ct).count();
  // A new cache for every supported D4 view, including empty-before-demand.
  for(int sym=0;sym<8;++sym){auto t=neural_transform_input(input,sym);nn::Board bd(t);nn::BoardState st(t,bd);FixedTimer ts{0,37},tr{0,37};auto xs=nn::search(t,bd,st,ts),xr=nn::reference_search(t,bd,st,tr);require(xs.E==xr.E&&xs.depth==xr.depth&&xs.path.size()==xr.path.size()&&xs.duplicates==xr.duplicates&&xs.deadline==xr.deadline,"symmetry metadata");for(size_t j=0;j<xs.path.size();++j)require(nn::action_code(bd,xs.path[j])==nn::action_code(bd,xr.path[j]),"symmetry path");auto cc=std::make_unique<nn::EncodeCache>();auto e=nn::encode(t,bd,st,cc.get());auto m=nn::legal_moves(bd,st);nn::policy(bd,st,*e,{},&cc->actor);logits_equal(nn::reference_policy(bd,st,*e,m),nn::policy(bd,st,*e,m,&cc->actor));}
  auto&s=nn::actor_stats;
  std::cout<<std::setprecision(12)<<"{\"case\":\""<<argv[arg]<<"\",\"states\":"<<states<<",\"logits\":"<<logits<<",\"forced\":"<<forced<<",\"home\":"<<home<<",\"dirty_unused\":"<<dirty_unused<<",\"later_used\":"<<later_used<<",\"role_switch\":"<<role_switch<<",\"symmetries\":8,\"parent_seconds\":"<<parent_sec<<",\"candidate_seconds\":"<<child_sec<<",\"source_hits\":"<<s.source_hits<<",\"dest_hits\":"<<s.dest_hits<<",\"source_projects\":"<<s.source_projects<<",\"dest_projects\":"<<s.dest_projects<<",\"source_invalidations\":"<<s.source_invalidations<<",\"dest_invalidations\":"<<s.dest_invalidations<<",\"bitwise_equal\":true,\"fixed_deadline_equal\":true}"<<std::endl;
 }
}
'''
(r/'adhoc/bin/v405_diagnostic.cpp').write_text(c+'\n'+ref+'\n'+search+'\n} // namespace nn\n'+trans+main)
