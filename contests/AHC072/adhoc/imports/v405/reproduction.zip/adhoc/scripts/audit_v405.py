from pathlib import Path
import subprocess,os,re,difflib,hashlib,json
r=Path(__file__).resolve().parents[2];o=r/'results/analysis/v405';source=r/'src/bin/v405_actor_projection_cache.cpp';parent=r/'adhoc/imports/v401/original.cpp.txt'
def clean(t,child):
 a=t.index('struct ActorStats' if child and 'struct ActorStats' in t else 'struct ActorCache' if child else 'struct EncodeCache');b=t.index('struct StateHash',a);t=t[:a]+t[b:]
 t=t.replace('policy(board,state,*encoded,moves,&encode_cache->actor)','policy(board,state,*encoded,moves)')
 return ''.join(l for l in t.splitlines(True) if 'trace.count_by("actor_' not in l)
results={}
for mode,flags in [('local',['-DLOCAL']),('nonlocal',['-DATCODER','-DONLINE_JUDGE','-DNOMINMAX'])]:
 pp=[]
 for name,path in [('parent',parent),('candidate',source)]:
  dest=o/f'{name}_{mode}.ii'
  with dest.open('w') as out:subprocess.run([os.environ['CXX'],'-x','c++','-std=gnu++23','-E','-P',*flags,str(path)],stdout=out,check=True)
  t=dest.read_text().replace(str(path),'SOURCE');t=re.sub(r'"SOURCE",\s*\d+,','"SOURCE", LINE,',t);pp.append(t)
 (o/f'preprocessed_{mode}.patch').write_text(''.join(difflib.unified_diff(pp[0].splitlines(True),pp[1].splitlines(True))))
 # LOCAL_ONLY expands the added count statements on the same logical line; remove each exact statement.
 def normalized(t,child):
  t=clean(t,child)
  for k in ['source_hits','dest_hits','source_projects','dest_projects','source_invalidations','dest_invalidations']:
   t=t.replace('trace.count_by("actor_'+k+'",nn::actor_stats.'+k+');','')
  return re.sub(r'\s+',' ',t).strip()
 # Do not discard an entire expanded LOCAL_ONLY line containing non-actor statements.
 def strip_region(t,child):
  a=t.index('struct ActorStats' if child and 'struct ActorStats' in t else 'struct ActorCache' if child else 'struct EncodeCache');b=t.index('struct StateHash',a);t=t[:a]+t[b:];t=t.replace('policy(board,state,*encoded,moves,&encode_cache->actor)','policy(board,state,*encoded,moves)')
  for k in ['source_hits','dest_hits','source_projects','dest_projects','source_invalidations','dest_invalidations']:t=t.replace('trace.count_by("actor_'+k+'",nn::actor_stats.'+k+');','')
  return re.sub(r'\s+',' ',t).strip()
 assert strip_region(pp[0],False)==strip_region(pp[1],True),mode+' outside cache differs'
 binary=o/f'v405_{mode}'
 with (o/f'build_{mode}.log').open('w') as log:subprocess.run([os.environ['CXX'],'-std=gnu++23','-O2','-Wall','-Wextra','-march=native','-pthread','-ftrivial-auto-var-init=zero','-fopenmp',*flags,str(source),'-o',str(binary)],stdout=log,stderr=subprocess.STDOUT,check=True)
 results[mode]={'build_ok':True,'preprocessed_outside_cache_plumbing_counters_equal':True}
(o/'static_audit.json').write_text(json.dumps({'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'parent_sha256':hashlib.sha256(parent.read_bytes()).hexdigest(),'modes':results},indent=2))
print(results)
