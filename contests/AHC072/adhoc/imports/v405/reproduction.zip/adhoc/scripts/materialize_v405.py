from pathlib import Path
import hashlib
r=Path(__file__).resolve().parents[2]
p=r/'adhoc/imports/v401/original.cpp.txt';s=p.read_text();assert hashlib.sha256(p.read_bytes()).hexdigest()=='0c241cc3a862d12faf100050df4ea3bafa3c520261d81e5237a41e3c54f25658'
s=s.replace(s.splitlines()[0],'// v405_actor_projection_cache.cpp',1)
a='''#ifdef LOCAL
struct ActorStats {
    uint64_t source_hits=0,dest_hits=0,source_projects=0,dest_projects=0;
    uint64_t source_invalidations=0,dest_invalidations=0;
} actor_stats;
#endif
struct ActorCache {
    array<array<float,NN_HIDDEN>,400> source{},dest{};
    array<bool,400> source_valid{},dest_valid{};
    void invalidate(int p) {
        source_valid[p]=dest_valid[p]=false;
#ifdef LOCAL
        ++actor_stats.source_invalidations;++actor_stats.dest_invalidations;
#endif
    }
    void invalidate() { for(int p=0;p<400;++p)invalidate(p); }
};
'''
s=s.replace('struct EncodeCache {',a+'struct EncodeCache {\n    ActorCache actor;')
s=s.replace('void invalidate() { valid=false; }','void invalidate() { valid=false;actor.invalidate(); }')
s=s.replace('    cache.bits=state.bits;cache.E=state.E;cache.valid=true;', '''    // Invalidate BOTH roles even when this floor is unused now. Otherwise a
    // dirty-unused floor could later expose a stale source/destination value.
    for(int p=0;p<board.cell_count;++p)if(changed[p])cache.actor.invalidate(p);
    cache.bits=state.bits;cache.E=state.E;cache.valid=true;''')
s=s.replace('const vector<Move>& moves) {\n    array<array<float,NN_HIDDEN>,400> source{},dest{};', '''const vector<Move>& moves,ActorCache* retained=nullptr) {
    unique_ptr<ActorCache> fresh;
    if(!retained){fresh=make_unique<ActorCache>();retained=fresh.get();}
    auto& cache=*retained;
    auto& source=cache.source;auto& dest=cache.dest;''')
s=s.replace('''        if(used_source[p])channel_matvec(fast_source,encoded.cells[p].data(),source[p].data());
        if(used_dest[p])channel_matvec(fast_destination,encoded.cells[p].data(),dest[p].data());''','''        if(used_source[p]) {
#ifdef LOCAL
            actor_stats.source_hits+=cache.source_valid[p];
            actor_stats.source_projects+=!cache.source_valid[p];
#endif
            if(!cache.source_valid[p]) {
                source[p]={}; // Preserve the parent's +0 accumulation and order.
                channel_matvec(fast_source,encoded.cells[p].data(),source[p].data());
                cache.source_valid[p]=true;
            }
        }
        if(used_dest[p]) {
#ifdef LOCAL
            actor_stats.dest_hits+=cache.dest_valid[p];
            actor_stats.dest_projects+=!cache.dest_valid[p];
#endif
            if(!cache.dest_valid[p]) {
                dest[p]={};
                channel_matvec(fast_destination,encoded.cells[p].data(),dest[p].data());
                cache.dest_valid[p]=true;
            }
        }''')
s=s.replace('const auto logits=policy(board,state,*encoded,moves);\n        if(!timer.step())','const auto logits=policy(board,state,*encoded,moves,&encode_cache->actor);\n        if(!timer.step())')
s=s.replace('for(int b=0;b<=nn::NN_DEPTH;++b)trace.count_by("cnn_cells_"+to_string(b),nn::incremental_stats.cells[b]);', 'for(int b=0;b<=nn::NN_DEPTH;++b)trace.count_by("cnn_cells_"+to_string(b),nn::incremental_stats.cells[b]);\n        trace.count_by("actor_source_hits",nn::actor_stats.source_hits);trace.count_by("actor_dest_hits",nn::actor_stats.dest_hits);\n        trace.count_by("actor_source_projects",nn::actor_stats.source_projects);trace.count_by("actor_dest_projects",nn::actor_stats.dest_projects);\n        trace.count_by("actor_source_invalidations",nn::actor_stats.source_invalidations);trace.count_by("actor_dest_invalidations",nn::actor_stats.dest_invalidations);')
(r/'src/bin/v405_actor_projection_cache.cpp').write_text(s)
