// v403_support_probe.cpp
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wreturn-type"
#define main unused_solver_main
#include "../../src/bin/v403_conditional_support.cpp"
#undef main
#pragma GCC diagnostic pop
struct ConditionalSupportProbe {
 static void demand(bool value,const string& name){if(!value)throw logic_error(name);}
 static void dump(const vector<Move>& moves,const string& path){ofstream f(path);for(auto m:moves)f<<board_info.row[m.p]<<' '<<board_info.col[m.p]<<' '<<int(m.k)<<' '<<board_info.dirs[m.d]<<' '<<int(m.l)<<'\n';}
 static vector<Move> read_moves(const char* path){ifstream f(path);vector<Move>a;int i,j,k,l;char d;while(f>>i>>j>>k>>d>>l){int direction=0;while(direction<4&&board_info.dirs[direction]!=d)++direction;a.push_back({int16_t(board_info.cell_id[i][j]),uint8_t(k),uint8_t(direction),uint8_t(l)});}return a;}
 static bool replay(const State& initial,const vector<Move>& moves){
  array<vector<int>,max_cells> a;
  for(int p=0;p<board_info.cell_count;++p){auto w=initial[p];while(w){a[p].push_back(w&15);w>>=4;}}
  for(auto m:moves){if(m.p<0||m.p>=board_info.cell_count||m.d>=4||m.k>=a[m.p].size()||m.l<1||m.l>m.k+1)return false;
   int q=-1;for(int step=1;step<=m.l;++step){int i=board_info.row[m.p]+board_info.di[m.d]*step,j=board_info.col[m.p]+board_info.dj[m.d]*step;if(i<0||i>=board_info.N||j<0||j>=board_info.N)return false;q=board_info.cell_id[i][j];if(q<0)return false;}
   if(a[q].size()+a[m.p].size()-m.k>8)return false;
   while(a[m.p].size()>m.k){a[q].push_back(a[m.p].back());a[m.p].pop_back();}
   for(int p:{int(m.p),q})while(!a[p].empty()&&a[p].back()==board_info.nest_code[p])a[p].pop_back();
  }
  for(auto&v:a)if(!v.empty())return false;
  return true;
 }
 static void geometry(){
  board_info.cell_count=board_info.M=0;board_info.initial.fill(0);memset(board_info.ray_count,0,sizeof(board_info.ray_count));
  string grid="12 4\n";for(int i=0;i<12;++i)grid+=string(12,'.')+"\n";
  istringstream f(grid);auto old=cin.rdbuf(f.rdbuf());board_info.read();cin.rdbuf(old);cin.clear();state_pool.prepare(board_info.cell_count);
 }
 static void fixtures(){
  geometry();time_keeper.start_=chrono::steady_clock::now();time_keeper.time_limit_sec=1e9;
  auto pos=[](int i,int j){return board_info.cell_id[i][j];};const int p=pos(5,5),q=pos(5,7),a=pos(5,4),home=pos(5,3);
  { // The support homes at departure while passengers home at destination.
   board_info.nest_code[p]=1;board_info.nest_code[q]=2;
   State bg;bg[p]=2;State real=bg;real[p]=0x21;vector<Move>out;
   TemporalLNS lns;bool ok=lns.insert_conditional_at(bg,{{int16_t(p),0,3,2}},p,1,0,0,out,0,1e9);
   demand(ok&&out.size()==1&&out[0].k==1&&replay(real,out),"endpoint_homing");cout<<"fixture endpoint_homing PASS\n";
  }
  board_info.nest_code[p]=0;board_info.nest_code[q]=2;board_info.nest_code[home]=1;
  { // An attractive early home costs one; a valid obligation path costs two.
   State bg;bg[p]=2;State real=bg;real[a]=1;vector<Move>out;
   TemporalLNS lns;
   demand(!lns.insert_conditional_at(bg,{{int16_t(p),0,3,2}},a,1,0,1,out,0,1e9),"off_source_early_goal_must_fail");
   cout<<"fixture off_source_early_goal_must_fail PASS\n";
   // Same-color aliases permit early departure. Before the event the extra
   // tag can jump two cells in one move; after supporting it needs two moves.
   board_info.nest_code[q]=1;bg[p]=1;real=bg;real[p]=0x11;
   auto before=conditional_support_stats.early_goal_discarded;
   bool ok=lns.insert_conditional_at(bg,{{int16_t(p),0,3,2}},p,1,0,2,out,0,1e9);
   demand(ok&&out.size()==3&&replay(real,out)&&conditional_support_stats.early_goal_discarded>before,"early_goal");
   bool marked=false;for(auto m:out)marked|=m.p==p&&m.l==2&&m.k==1;demand(marked,"mandatory support");cout<<"fixture early_goal PASS\n";
   board_info.nest_code[q]=2;
  }
  {State bg;bg[p]=0x22222222u;vector<Move>out;TemporalLNS lns;
   demand(!lns.insert_conditional_at(bg,{{int16_t(p),0,3,2}},a,1,0,4,out,0,1e9),"capacity8");cout<<"fixture capacity8 PASS\n";
  }
  {State bg;bg[p]=0x22;bg[q]=0x2222222;vector<Move>out;TemporalLNS lns;
   demand(!lns.insert_conditional_at(bg,{{int16_t(p),0,3,2}},a,1,0,4,out,0,1e9),"pre_homing_destination_overflow");cout<<"fixture pre_homing_destination_overflow PASS\n";
  }
  { // Equal-color gap closure remains valid through the mandatory layer.
   int dest=pos(5,8);board_info.nest_code[dest]=2;board_info.nest_code[p]=1;
   State bg;bg[p]=0x21;State real=bg;real[p]=0x211;vector<Move>out;TemporalLNS lns;
   demand(lns.insert_conditional_at(bg,{{int16_t(p),1,3,3}},p,1,0,0,out,0,1e9)&&replay(real,out),"same_color_gap");cout<<"fixture same_color_gap PASS\n";
  }
  {State bg;bg[p]=2;vector<Move>out;TemporalLNS lns;bool hit=false;
   try{lns.insert_conditional_at(bg,{{int16_t(p),0,3,2}},a,1,0,4,out,0,-1);}catch(const SupportDeadline&){hit=true;}
   demand(hit&&time_keeper.time_limit_sec==1e9&&out.empty(),"deadline");cout<<"fixture deadline PASS\n";
  }
  { // Two separate unsupported jumps must reject rather than silently route.
   fill(board_info.nest_code,board_info.nest_code+board_info.cell_count,0);board_info.initial.fill(0);
   int token=pos(5,4),cargo=pos(5,5);board_info.initial[token]=1;board_info.initial[cargo]=2;
   board_info.nest_code[pos(5,3)]=1;board_info.nest_code[pos(5,7)]=2;
   vector<Move> original={{int16_t(cargo),0,2,1},{int16_t(token),1,3,2},{int16_t(pos(5,6)),0,2,1},{int16_t(cargo),0,2,1},{int16_t(token),1,3,2},{int16_t(pos(5,6)),0,3,1},{int16_t(token),0,2,1}};
   TemporalLNS lns;lns.refresh_history(original);State bg;vector<Move>base;int required;auto before=conditional_support_stats.second_deficit_rejected;
   demand(!lns.extract_conditional(original,token,base,bg,required,1e9)&&conditional_support_stats.second_deficit_rejected>before,"second_deficit");cout<<"fixture second_deficit PASS\n";
  }
  demand(state_pool.free_count==4,"fixture pool");
 }
 static void natural(const char*path,const string&prefix){
  board_info.read();state_pool.prepare(board_info.cell_count);time_keeper.start_=chrono::steady_clock::now();time_keeper.time_limit_sec=1e9;rng.x=403;
  auto moves=read_moves(path);demand(support_strict_replay(moves,1e9),"input replay");
  {TemporalLNS lns;lns.initialize_spatial_cuts();lns.rebuild_all(moves);set<int>tokens;for(auto&c:lns.candidates)if(c.ids.size()==1)tokens.insert(c.ids[0]);
   for(int token:tokens){
    if(conditional_support_stats.attempted>=32||conditional_support_stats.seconds>=0.01*PROGRAM_TIME_LIMIT_SEC)break;
    if(!lns.one_support_history(token))continue;
    State initial;vector<Move>base,ordinary;bool ordinary_ok=lns.extract(moves,{token},base,initial);
    if(ordinary_ok)ordinary_ok=lns.insert(initial,base,token,int(moves.size())+4-int(base.size()),ordinary);
    if(ordinary_ok){demand(support_strict_replay(ordinary,1e9),"ordinary replay");dump(ordinary,prefix+"_"+to_string(token)+"_ordinary.txt");}
    int ordinary_size=ordinary_ok?int(ordinary.size()):-1;auto out=ordinary;
    bool chosen=lns.conditional_alternative(moves,token,int(moves.size())+4,ordinary_ok,out,1e9);
    if(chosen){demand(support_strict_replay(out,1e9),"conditional replay");dump(out,prefix+"_"+to_string(token)+"_conditional.txt");}
    cout<<"trial "<<token<<' '<<ordinary_size<<' '<<(chosen?int(out.size()):-1)<<'\n';
   }
  }
  demand(state_pool.free_count==4,"natural pool");conditional_support_stats.summary();trace.summary();
 }
};
int main(int argc,char**argv){try{if(argc==2&&string(argv[1])=="fixtures")ConditionalSupportProbe::fixtures();else if(argc==3)ConditionalSupportProbe::natural(argv[1],argv[2]);else return 2;}catch(const exception&e){cerr<<e.what()<<'\n';return 1;}}
