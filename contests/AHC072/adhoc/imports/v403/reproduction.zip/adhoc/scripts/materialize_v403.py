#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[2]
s=(r/'src/bin/v401_incremental_cnn.cpp').read_text().replace('// v401_incremental_cnn.cpp','// v403_conditional_support.cpp',1).replace('constexpr double LOCAL_TIME_RATIO = 0.80;','constexpr double LOCAL_TIME_RATIO = 1.90/1.930;',1)
global_code=r'''
// Shared across all race instances: only additional conditional work is charged.
struct SupportDeadline {};
struct ConditionalSupportStats {
    int eligible=0,attempted=0,completed=0,conditional_wins=0,ordinary_fail_rescued=0,direct_saved=0;
    int mandatory_support_passed=0,early_goal_discarded=0,second_deficit_rejected=0,deadline_hits=0;
    int accepted=0,best_updates=0;
    double seconds=0,max_attempt_seconds=0,max_overrun_seconds=0;
    void summary() const {
#ifdef LOCAL
#define SUPPORT_COUNT(x) trace.count_by("conditional_support_" #x,x)
            SUPPORT_COUNT(eligible);SUPPORT_COUNT(attempted);SUPPORT_COUNT(completed);
            SUPPORT_COUNT(conditional_wins);SUPPORT_COUNT(ordinary_fail_rescued);SUPPORT_COUNT(direct_saved);
            SUPPORT_COUNT(mandatory_support_passed);SUPPORT_COUNT(early_goal_discarded);
            SUPPORT_COUNT(second_deficit_rejected);SUPPORT_COUNT(deadline_hits);SUPPORT_COUNT(accepted);SUPPORT_COUNT(best_updates);
#undef SUPPORT_COUNT
            trace.add_time_ms("conditional_support_total",seconds*1000);
            trace.add_time_ms("conditional_support_max_attempt",max_attempt_seconds*1000);
            trace.add_time_ms("conditional_support_max_overrun",max_overrun_seconds*1000);
#endif
    }
} conditional_support_stats;
static void check_support_deadline(double deadline) {
    if(time_keeper.exact_elapsed_sec()>=deadline)throw SupportDeadline();
}
// Independent color-vector replay, including capacity BEFORE either endpoint homes.
static bool support_strict_replay(const vector<Move>& moves,double deadline) {
    array<vector<int>,max_cells> tower;
    for(int p=0;p<board_info.cell_count;++p)if(board_info.initial[p])tower[p].push_back(int(board_info.initial[p]));
    for(auto m:moves) {
        check_support_deadline(deadline);
        if(m.p<0||m.p>=board_info.cell_count||m.d>=4||m.k>=tower[m.p].size()||m.l<1||m.l>m.k+1)return false;
        int q=-1;
        for(int step=1;step<=m.l;++step) {
            const int row=board_info.row[m.p]+board_info.di[m.d]*step,col=board_info.col[m.p]+board_info.dj[m.d]*step;
            if(row<0||row>=board_info.N||col<0||col>=board_info.N)return false;
            q=board_info.cell_id[row][col];if(q<0)return false;
        }
        if(tower[q].size()+tower[m.p].size()-m.k>8)return false;
        while(tower[m.p].size()>m.k){tower[q].push_back(tower[m.p].back());tower[m.p].pop_back();}
        for(int p:{int(m.p),q})while(!tower[p].empty()&&tower[p].back()==board_info.nest_code[p])tower[p].pop_back();
    }
    for(const auto& t:tower)if(!t.empty())return false;
    return moves.size()<=100000;
}
'''
s=s.replace('class TemporalLNS {',global_code+'\nclass TemporalLNS {\n    friend struct ConditionalSupportProbe;',1)
start=s.index('    bool insert_at(');end=s.index('\n    bool insert(',start)
fn=s[start:end].replace('bool insert_at(','bool insert_conditional_at(',1).replace('int initial_gap,int cap,vector<Move>& result)', 'int initial_gap,int cap,vector<Move>& result,int required,double deadline)',1)
fn=fn.replace('        LOCAL_NOTE(++local_single_insert_calls;)','        check_support_deadline(deadline);',1)
fn=fn.replace('        auto ceiling=[&](){return min(cap,label[GOAL].cost);};','        bool obligation_pending=true;\n        auto ceiling=[&](){return obligation_pending?cap:min(cap,label[GOAL].cost);};',1)
fn=fn.replace('if((t&31)==0)time_keeper.check();','check_support_deadline(deadline);')
fn=fn.replace('            while(queue.pop(ceiling(),queued_position,queued_cost)) {','            while(queue.pop(ceiling(),queued_position,queued_cost)) {\n                check_support_deadline(deadline);',1)
fn=fn.replace('                    int q=board_info.ray[p][d][l];','                    check_support_deadline(deadline);\n                    int q=board_info.ray[p][d][l];',1)
fn=fn.replace('                if((++pops&1023)==0)time_keeper.check();','                ++pops;')
fn=fn.replace('            board_info.apply(b,m);h[p]=height(b[p]);h[q]=height(b[q]);',r'''            const bool mandatory=t==required;
            if(mandatory) {
                // The background is conditional only here. The tag MUST stay below
                // the passengers; no GOAL or untouched-cell label can bypass this event.
                if(m.l!=m.k+2||m.k>=hp||hq+hp-m.k>8||hp>=8)return false;
                conditional_support_stats.early_goal_discarded+=label[GOAL].cost<=cap;
                fill(label.begin(),label.end(),Label());
                for(int g=0;g<8;++g)if(g>m.k)from_p[g]=Label();
                from_q.fill(Label());obligation_pending=false;
                TowerBits moving=reverse_tower(b[p]>>(4*m.k));
                b[p]=board_info.normalize(prefix(b[p],m.k),p);
                b[q]=board_info.normalize(append_tower(b[q],moving),q);
                ++conditional_support_stats.mandatory_support_passed;
            }else board_info.apply(b,m);
            h[p]=height(b[p]);h[q]=height(b[q]);''',1)
fn=fn.replace('                if(at.cost>ceiling())return;','                check_support_deadline(deadline);\n                if(at.cost>ceiling())return;\n                if(mandatory&&(location!=p||!added_keep||gap>m.k))return;',1)
fn=fn.replace('                        const int dest=board_info.ray[tag_cell][d][l];','                        check_support_deadline(deadline);\n                        const int dest=board_info.ray[tag_cell][d][l];',1)
fn=fn.replace('        if(label[GOAL].cost>cap)return false;','        check_support_deadline(deadline);\n        if(obligation_pending||label[GOAL].cost>cap)return false;',1)
# First a separate conditional extraction. It never routes around any deficit.
methods=r'''
    bool one_support_history(int token,double deadline=numeric_limits<double>::infinity()) const {
        int deficits=0;
        for(const auto& use:support_uses) {
            check_support_deadline(deadline);
            bool lost=false;for(int j=0;j<use.lower.n;++j)lost|=use.lower.id[j]==token;
            if(!lost||use.slack!=0)continue;
            const auto& flight=flights[use.time];
            bool remains=false;for(int j=0;j<flight.n;++j)remains|=flight.id[j]!=token;
            if(remains&&++deficits>1)return false;
        }
        return deficits==1;
    }
    bool extract_conditional(const vector<Move>& original,int token,vector<Move>& base,
                             State& initial,int& required,double deadline) {
        IdentityState cur(vector<int>{token});initial=cur.words();base.clear();required=-1;
        for(int t=0;t<int(original.size());++t) {
            check_support_deadline(deadline);
            Move m=original[t];int p=m.p;
            if(p<0||p>=board_info.cell_count||m.d>=4||m.l<1||m.l>8)return false;
            int q=board_info.ray[p][m.d][m.l];if(q<0)return false;
            array<int,8> flight{};int take=0;
            for(int j=0;j<flights[t].n;++j)if(cur.alive[flights[t].id[j]])flight[take++]=flights[t].id[j];
            if(!take)continue;
            int keep=int(cur.h[p])-take;
            if(keep<0||cur.h[q]+take>8)return false;
            for(int j=0;j<take;++j)if(cur.a[p][keep+j]!=flight[j])return false;
            m.k=keep;
            if(m.l<=keep+1)cur.apply(m);
            else {
                if(m.l!=keep+2)return false;
                if(required>=0){++conditional_support_stats.second_deficit_rejected;return false;}
                required=int(base.size());
                // All ordinary apply checks were verified above except this one
                // explicit missing support. This skeleton is never an answer.
                for(int j=cur.h[p]-1;j>=keep;--j)cur.a[q][cur.h[q]++]=cur.a[p][j];
                cur.h[p]=keep;
                for(int v:{p,q})while(cur.h[v]&&board_info.initial[cur.a[v][cur.h[v]-1]]==TowerBits(board_info.nest_code[v])) {
                    cur.alive[cur.a[v][cur.h[v]-1]]=0;--cur.h[v];
                }
            }
            base.push_back(m);
        }
        for(int p=0;p<board_info.cell_count;++p)if(cur.h[p])return false;
        return required>=0;
    }
'''+fn+r'''
    bool conditional_alternative(const vector<Move>& original,int token,int allowance,
                                 bool ordinary_ok,vector<Move>& result,double end) {
        auto& stats=conditional_support_stats;
        if(stats.attempted>=32||stats.seconds>=0.01*PROGRAM_TIME_LIMIT_SEC)return false;
        const double begin=time_keeper.exact_elapsed_sec();
        const double deadline=min({end,time_keeper.time_limit_sec,
            begin+min(0.001*PROGRAM_TIME_LIMIT_SEC,0.01*PROGRAM_TIME_LIMIT_SEC-stats.seconds)});
        if(begin>=deadline)return false;
        // Charge history screening as additional work even when it rejects.
        struct Account {
            ConditionalSupportStats& s;double begin,deadline;
            ~Account(){double elapsed=time_keeper.exact_elapsed_sec()-begin;s.seconds+=elapsed;
                s.max_attempt_seconds=max(s.max_attempt_seconds,elapsed);
                s.max_overrun_seconds=max(s.max_overrun_seconds,begin+elapsed-deadline);}
        } account{stats,begin,deadline};
        try {
            if(!one_support_history(token,deadline))return false;
            ++stats.eligible;++stats.attempted;
            vector<Move> skeleton,conditional;State initial;int required=-1;
            if(!extract_conditional(original,token,skeleton,initial,required,deadline))return false;
            if(!insert_conditional_at(initial,skeleton,token,int(board_info.initial[token]),0,
                                      allowance-int(skeleton.size()),conditional,required,deadline))return false;
            if(!support_strict_replay(conditional,deadline))throw logic_error("conditional strict replay");
            check_support_deadline(deadline);++stats.completed;
            if(!ordinary_ok||conditional.size()<result.size()) {
                if(ordinary_ok){++stats.conditional_wins;stats.direct_saved+=int(result.size()-conditional.size());}
                else ++stats.ordinary_fail_rescued;
                result=move(conditional);return true;
            }
        }catch(const SupportDeadline&){++stats.deadline_hits;}
        return false;
    }
'''
s=s[:end]+methods+s[end:]
# Preserve ordinary singleton work, including its otherwise irrelevant RNG draw.
old='''                const bool extracted=extract(current,cand.ids,base,initial);'''
s=s.replace(old,'''                const bool extracted=extract(current,cand.ids,base,initial);''',1)
# Place a separate singleton branch around the unchanged existing regular reconstruction.
start=s.index('                vector<Move> base;State initial;',s.index('    void optimize('))
end=s.index('            }\n            if(!ok)continue;',start)
old=s[start:end]
single=r'''                if(!dependency&&cand.ids.size()==1) {
                    const int token=cand.ids[0];vector<Move> base;State initial;
                    ok=extract(current,cand.ids,base,initial);
                    if(ok) {
                        (void)rng.unit(); // Same one-token ordering draw as the parent.
                        ok=insert(initial,base,token,int(current.size())+4-int(base.size()),trial);
                        if(ok)++insertions;
                    }
                    used_conditional=conditional_alternative(current,token,int(current.size())+4,
                        ok,trial,min(slice_end,end));
                    ok=ok||used_conditional;
                }else {
'''+old+'                }\n'
s=s[:start]+single+s[end:]
s=s.replace('            vector<Move> trial;\n','            vector<Move> trial;bool used_conditional=false;\n',1)
s=s.replace('            if(accept) {\n','            if(accept) {\n                if(used_conditional)++conditional_support_stats.accepted;\n',1)
s=s.replace('                if(polished.size()<best.size()) {\n','                if(polished.size()<best.size()) {\n                    if(used_conditional)++conditional_support_stats.best_updates;\n',1)
s=s.replace('        local_nn.summary();','        conditional_support_stats.summary();local_nn.summary();',1)
(r/'src/bin/v403_conditional_support.cpp').write_text(s)
