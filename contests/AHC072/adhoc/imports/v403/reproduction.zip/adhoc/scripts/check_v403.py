#!/usr/bin/env python3
"""One frozen saved-output pass, then independent replay; no full solver evaluation."""
from pathlib import Path
import subprocess,json,re,sys,hashlib,time
r=Path(__file__).resolve().parents[2];o=r/'results/analysis/v403';sys.path.insert(0,str(r/'adhoc/scripts'))
from replay_slime_output import replay
assert (o/'fixtures.log').read_text().count(' PASS')==8
assert not (o/'natural_cases.json').exists(), 'saved-output pass already recorded'
(o/'diagnostic_outputs').mkdir(exist_ok=True);(o/'diagnostic_logs').mkdir(exist_ok=True)
records=[];begin=time.monotonic()
for inp in sorted((r/'tools/in').glob('*.txt')):
 source=r/'results/analysis/v401/outputs'/inp.name;prefix=o/'diagnostic_outputs'/inp.stem
 with inp.open() as f:
  p=subprocess.run([str(r/'target/release/v403_support_probe'),str(source),str(prefix)],stdin=f,capture_output=True,text=True)
 (o/'diagnostic_logs'/f'{inp.stem}.stdout').write_text(p.stdout);(o/'diagnostic_logs'/f'{inp.stem}.stderr').write_text(p.stderr)
 assert p.returncode==0,(inp.name,p.stderr)
 counts={k:int(v) for k,v in re.findall(r'\[summary.count\] ([^=]+)=(-?\d+)',p.stderr)}
 times={k:float(v) for k,v in re.findall(r'\[summary.time_ms\] ([^=]+)=(-?[\d.]+)',p.stderr)}
 records.append({'case':inp.name,'counts':counts,'times_ms':times,'trials':[[int(x) for x in m] for m in re.findall(r'^trial (\d+) (-?\d+) (-?\d+)$',p.stdout,re.M)]})
 assert counts['conditional_support_attempted']<=32
(o/'natural_cases.json').write_text(json.dumps(records,indent=2)+'\n')
replays=[]
for path in sorted((o/'diagnostic_outputs').glob('*.txt')):
 metrics=replay(r/'tools/in'/f'{path.name[:4]}.txt',path)['metrics'];assert metrics['E']==0
 replays.append({'file':str(path.relative_to(r)),**metrics,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
counts={k:sum(x['counts'].get(k,0) for x in records) for k in records[0]['counts']}
result={'cases':len(records),'counts':counts,'independent_replays':len(replays),'elapsed_sec':time.monotonic()-begin,
 'max_attempt_ms':max(x['times_ms']['conditional_support_max_attempt'] for x in records),
 'max_overrun_ms':max(x['times_ms']['conditional_support_max_overrun'] for x in records),
 'total_ms':sum(x['times_ms']['conditional_support_total'] for x in records),
 'gate_passed':counts['conditional_support_eligible']>0 and counts['conditional_support_conditional_wins']>0,
 'natural_strict_win_examples':[{'case':x['case'],'token':t,'ordinary':a,'conditional':b} for x in records for t,a,b in x['trials'] if a>=0 and b>=0 and b<a],
 'fixture_count':8,'deadline_fixture_limitation':'Manufactured fixture checks entry exit; natural hits cover in-work deadline exits when observed.'}
(o/'diagnostic_replay.json').write_text(json.dumps(replays,indent=2)+'\n');(o/'diagnostic_result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
