#!/usr/bin/env python3
"""Read-only final aggregation; never runs solver."""
from pathlib import Path
import json,hashlib,re,collections,statistics,sys,csv,shutil
r=Path(__file__).resolve().parents[2];o=r/'results/analysis/v403';sys.path.insert(0,str(r/'adhoc/scripts'))
from replay_slime_output import replay
label='cloud_v403_gcc15.3_LOCAL_search1.900_core1.870466_j8_20261004'
records=[json.loads(s) for s in (r/'results/eval_records.jsonl').read_text().splitlines()];records=[x for x in records if x['label']==label]
assert len(records)==100 and len({x['case_name'] for x in records})==100 and all(x['status']=='ok' for x in records)
ref=json.loads((r/'results/analysis/cloud_baseline/fixed_reference.json').read_text())['cases']
parent={x['case_name']:x['score'] for x in json.loads((r/'results/analysis/v401/records.json').read_text())}
traces=[];replays=[];pairs=[]
for x in records:
 case=x['case_name'];inp=r/'tools/in'/case;p=r/x['stdout_path'];t=Path(str(p)+'.err').read_text()
 assert hashlib.sha256(inp.read_bytes()).hexdigest()==ref[case]['input_sha256']
 counts={k:int(v) for k,v in re.findall(r'\[summary.count\] ([^=]+)=(-?\d+)',t)}
 times={k:float(v) for k,v in re.findall(r'\[summary.time_ms\] ([^=]+)=(-?[\d.]+)',t)}
 traces.append({'case':case,'counts':counts,'times_ms':times,'output_sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
 metrics=replay(inp,p)['metrics'];assert metrics['E']==0 and metrics['S']==x['score'];replays.append({'case':case,**metrics})
 assert counts['conditional_support_attempted']<=32
 pairs.append({'case':case,'v311':ref[case]['score'],'v401':parent[case],'v403':x['score'],'delta':x['score']-parent[case],'index':100*ref[case]['score']/x['score'],'elapsed_ms':x['elapsed']})
elapsed=[x['elapsed'] for x in records]
result={'label':label,'cases':100,'score_sum':sum(x['score'] for x in records),'score_mean':statistics.mean(x['score'] for x in records),'score_delta':sum(x['delta'] for x in pairs),'fixed_reference_index':statistics.mean(x['index'] for x in pairs),'wins':sum(x['delta']<0 for x in pairs),'ties':sum(x['delta']==0 for x in pairs),'losses':sum(x['delta']>0 for x in pairs),'elapsed_mean_ms':statistics.mean(elapsed),'elapsed_max_ms':max(elapsed),'elapsed_over_1900ms':sum(x>1900 for x in elapsed),'elapsed_ge_2000ms':sum(x>=2000 for x in elapsed),'independent_replay_ok':len(replays),'error_recovery_totals':{key:sum(t['counts'].get(key,0) for t in traces) for key in ['construction_errors','lns_errors','baseline_recovery','final_recovery','lns_invalid_candidates']},'free_slots_distribution':dict(collections.Counter(t['counts'].get('state_pool_free_at_end','missing') for t in traces)),'search_limit_distribution_ms':dict(collections.Counter(t['times_ms'].get('search_limit','missing') for t in traces)),'trace_total_max_ms':max(t['times_ms'].get('total',0) for t in traces),'counts':{key:sum(t['counts'].get(key,0) for t in traces) for key in traces[0]['counts'] if key.startswith('conditional_support_')},'extra_mean_ms':statistics.mean(t['times_ms'].get('conditional_support_total',0) for t in traces),'extra_max_ms':max(t['times_ms'].get('conditional_support_total',0) for t in traces),'max_attempt_ms':max(t['times_ms'].get('conditional_support_max_attempt',0) for t in traces),'max_overrun_ms':max(t['times_ms'].get('conditional_support_max_overrun',0) for t in traces),'memory':json.loads((o/'memory.json').read_text()),'source_sha256':hashlib.sha256((r/'src/bin/v403_conditional_support.cpp').read_bytes()).hexdigest()}
result['acceptance_passed']=result['score_sum']<=19876 and result['fixed_reference_index']>100.304115 and max(elapsed)<2000 and all(v==0 for v in result['error_recovery_totals'].values()) and result['free_slots_distribution']=={4:100}
for name,value in [('result',result),('records',records),('case_traces',traces),('replay',replays)]: (o/f'{name}.json').write_text(json.dumps(value,indent=2)+'\n')
with (o/'paired.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=list(pairs[0]));w.writeheader();w.writerows(pairs)
shutil.copytree(r/'results/out/v403_conditional_support',o/'outputs',dirs_exist_ok=True)
print(json.dumps({k:v for k,v in result.items() if k!='memory'},indent=2))
