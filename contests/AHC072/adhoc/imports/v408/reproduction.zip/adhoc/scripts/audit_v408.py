from pathlib import Path
import subprocess,os,re,difflib,hashlib,json
r=Path(__file__).resolve().parents[2];o=r/'results/analysis/v408';source=r/'src/bin/v408_learned_only_portfolio.cpp';parent=r/'adhoc/imports/v401/original.cpp.txt'
p=parent.read_text();c=source.read_text();results={};pattern=r'static constexpr char nn_packed\[\] =\s*.*?;'
addition=(o/'local_addition.txt').read_text()
stripbank=lambda s:re.sub(pattern,'BANK',s,count=1,flags=re.S)
assert stripbank('\n'.join(p.splitlines()[1:]))==stripbank('\n'.join(c.replace(addition,'',1).splitlines()[1:]))
(o/'source.patch').write_text(''.join(difflib.unified_diff(p.splitlines(True),c.splitlines(True),fromfile='cloud401',tofile='v408')))
for mode,flags in [('local',['-DLOCAL']),('nonlocal',['-DATCODER','-DONLINE_JUDGE','-DNOMINMAX'])]:
 pp=[]
 for name,path in [('parent',parent),('candidate',source)]:
  dest=o/f'{name}_{mode}.ii'
  with dest.open('w') as out:subprocess.run([os.environ['CXX'],'-x','c++','-std=gnu++23','-E','-P',*flags,str(path)],stdout=out,check=True)
  t=dest.read_text().replace(str(path),'SOURCE');t=re.sub(r'"SOURCE",\s*\d+,','"SOURCE", LINE,',t);pp.append(t)
 (o/f'preprocessed_{mode}.patch').write_text(''.join(difflib.unified_diff(pp[0].splitlines(True),pp[1].splitlines(True))))
 a,b=map(stripbank,pp)
 if mode=='local':
  # Remove only the fully preprocessed LOCAL diagnostic block, not any region.
  diag=re.sub(r'\s+',' ',addition[addition.index('            uint64_t'):]).strip()
  b=re.sub(r'\s+',' ',b).strip();assert b.count(diag)==1;b=b.replace(diag,'',1)
 assert re.sub(r'\s+',' ',a).strip()==re.sub(r'\s+',' ',b).strip(),mode+' differs outside bank and exact LOCAL diagnostics'
 binary=o/f'v408_{mode}'
 with (o/f'build_{mode}.log').open('w') as log:subprocess.run([os.environ['CXX'],'-std=gnu++23','-O2','-Wall','-Wextra','-march=native','-pthread','-ftrivial-auto-var-init=zero','-fopenmp',*flags,str(source),'-o',str(binary)],stdout=log,stderr=subprocess.STDOUT,check=True)
 results[mode]={'build_ok':True,'outside_bank_and_exact_LOCAL_diagnostics_preprocessed_equal':True,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest()}
(o/'static_audit.json').write_text(json.dumps({'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'modes':results},indent=2)+'\n');print(results)
