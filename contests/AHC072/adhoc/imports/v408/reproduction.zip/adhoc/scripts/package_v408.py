from pathlib import Path
import hashlib,json,zipfile
r=Path(__file__).resolve().parents[2];o=r/'results/analysis/v408';dest=r/'adhoc/imports/v408';dest.mkdir(parents=True,exist_ok=True);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();source=r/'src/bin/v408_learned_only_portfolio.cpp';frozen=json.loads((o/'frozen_manifest.json').read_text());assert sha(source)==frozen['source_sha256']
(o/'REPRODUCE.txt').write_text('''v408 frozen learned-only policy deployment, private cloud evidence.
Source, experiment note and backlog are authoritative separate files, not duplicated in this archive.
Exact parent: adhoc/imports/v401/original.cpp.txt SHA0c241cc3a862d12faf100050df4ea3bafa3c520261d81e5237a41e3c54f25658.
Exact donor: adhoc/bin/v109_assisted_learned.cpp SHAc3a8402fbeef98385ff209c3bf07d7350f82b2646409ca9dfcc700eb3f12b9db.
Use source adhoc/scripts/cloud_toolchain_env.sh for GCC15.3 / Rust1.89.
materialize_v408.py reconstructs candidate; audit_v408.py verifies exact source and full preprocessing outside bank/filename/LOCAL hash diagnostics and builds both modes.
build_v408_diagnostic.py generates the existing v406 correctness fixture with one learned bank and independent v109 full encoder; fixed inputs0000-0007 and sym0/4/1/5, full5000call and prefix37call limits. run_v408_diagnostic.py is one-execution guarded; check_v408_diagnostic.py audits saved rows/tensors.
run_v408_eval.py checks frozen source, diagnostic and independent-review gates; one standard tools/in100 LOCAL1.90/1.930 j8 eval, including standard warmup. Further solver runs need new explicit user instructions, never noise tests.
summarize_v408.py aggregates saved official records and independent legal/E0 replay; restore archived outputs to recorded stdout_path if needed. It never executes solver.
Exact historical v800 reference remains missing; no substitute relative index computed. Absolute improvement alone cannot finalize adoption.
Archive-only review can inspect saved scalar rows, hash evidence and preprocessing diffs. check_v408_diagnostic.py additionally requires tensor binaries retained in the original private cloud workspace; reconstructing them executes the bounded fixture and requires new explicit instructions once this experiment is complete. audit_v408.py can rebuild/preprocess without solver execution.
All32 diagnostic scalar rows, tensor hashes, build/preprocessing diffs,100 official output/trace pairs and independent replay evidence included. Raw tensor binaries, compiled executables, full preprocessed bodies and duplicate parsed traces stay private with recorded hashes. Inputs are existing tools/in and hashes are captured.
''')
artifacts=[o/'case_traces.json',source,r/'adhoc/imports/v401/original.cpp.txt',r/'adhoc/bin/v109_assisted_learned.cpp',*o.glob('*.ii'),*o.glob('*.bin'),o/'v408_local',o/'v408_nonlocal',r/'adhoc/bin/v408_diagnostic.cpp',r/'target/release/v408_diagnostic',r/'target/release/v408_learned_only_portfolio']
(o/'full_artifact_hashes.json').write_text(json.dumps({str(p.relative_to(r)):sha(p) for p in artifacts if p.is_file()},indent=2)+'\n')
files=[p for p in sorted(o.rglob('*')) if p.is_file() and p.suffix in ('.json','.jsonl','.csv','.log','.patch','.md','.txt','.stderr','.err','.sha256') and p.name!='case_traces.json']
files+=[r/'results/analysis/v401/records.json']
files+=list((r/'adhoc/scripts').glob('*v408*.py'))
files+=[r/'adhoc/scripts'/n for n in ['replay_slime_output.py','cloud_gcc15.py','cloud_toolchain_env.sh']]
files=list(dict.fromkeys(files));manifest={str(p.relative_to(r)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in files}
with zipfile.ZipFile(dest/'reproduction.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files:z.write(p,str(p.relative_to(r)))
 z.writestr('V408_CONTENT_MANIFEST.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(dest/'reproduction.zip') as z:
 assert z.testzip() is None
 for name,item in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==item['sha256']
external={'version':'v408','source_sha256':sha(source),'note_sha256':sha(r/'notes/experiments/v408.md'),'backlog_sha256':sha(r/'notes/backlog.md'),'zip_sha256':sha(dest/'reproduction.zip'),'zip_bytes':(dest/'reproduction.zip').stat().st_size,'file_count':len(files),'publication_files':['src/bin/v408_learned_only_portfolio.cpp','notes/experiments/v408.md','notes/backlog.md','adhoc/imports/v408/reproduction.zip','adhoc/imports/v408/manifest.json'],'files':manifest};(dest/'manifest.json').write_text(json.dumps(external,indent=2)+'\n');print(json.dumps({k:v for k,v in external.items() if k!='files'},indent=2))
