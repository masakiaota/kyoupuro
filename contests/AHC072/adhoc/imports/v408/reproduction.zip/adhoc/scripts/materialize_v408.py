from pathlib import Path
import re,hashlib,json,base64
r=Path(__file__).resolve().parents[2];o=r/'results/analysis/v408';o.mkdir(parents=True,exist_ok=True)
p=r/'adhoc/imports/v401/original.cpp.txt';d=r/'adhoc/bin/v109_assisted_learned.cpp'
sha=lambda x:hashlib.sha256(x).hexdigest()
assert sha(p.read_bytes())=='0c241cc3a862d12faf100050df4ea3bafa3c520261d81e5237a41e3c54f25658'
assert sha(d.read_bytes())=='c3a8402fbeef98385ff209c3bf07d7350f82b2646409ca9dfcc700eb3f12b9db'
assert (r/'notes/experiments/v408.md').exists() and '[v408]' in (r/'notes/backlog.md').read_text()
s=p.read_text();pattern=r'static constexpr char nn_packed\[\] =\n.*?\n;';bank=re.search(pattern,d.read_text(),re.S).group()
s=re.sub(pattern,lambda _:bank,s,count=1,flags=re.S)
s=s.replace(s.splitlines()[0],'// v408_learned_only_portfolio.cpp',1)
old='            trace.count_by("race_seed_"+to_string(id)+"_origin",pool.entries[id].origin);'
addition='''
            // LOCAL-only identity of each learned-policy candidate before LNS.
            uint64_t seed_hash=1469598103934665603ULL;
            for(const auto m:pool.entries[id].moves) {
                const uint64_t code=(((uint64_t(board_info.row[m.p]*20+board_info.col[m.p])*8+m.k)*4+m.d)*8+m.l-1);
                seed_hash=(seed_hash^code)*1099511628211ULL;
            }
            trace.count_by("v408_seed_"+to_string(id)+"_hash",seed_hash&0x7fffffffffffffffULL);'''
assert s.count(old)==1;s=s.replace(old,old+addition)
path=r/'src/bin/v408_learned_only_portfolio.cpp';path.write_text(s)
packed=base64.b64decode(''.join(re.findall(r'"([A-Za-z0-9+/=]+)"',bank)))
assert len(packed)==30800 and sha(packed)=='1951ee50655a490ff93fb9410f9c3105a32f89fb5f072815d88a8b18b44a6f81'
manifest={'source_sha256':sha(path.read_bytes()),'parent_sha256':sha(p.read_bytes()),'donor_sha256':sha(d.read_bytes()),'packed_sha256':sha(packed),'slots':[[1,0],[1,4],[1,1],[1,5]],'local_ratio':'1.90/1.930','jobs':8,'total_strict_lt':19876,'external_max_lte_ms':2000,'relative_condition':'relative_v800(v408)>relative_v800(cloud401), exact original reference pending','M_strata':['M<=50','51<=M<=100','M>=101'],'diagnostic_cases':[f'{i:04}.txt' for i in range(8)],'scored_evaluations':1}
(o/'frozen_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(o/'local_addition.txt').write_text(addition)
print(json.dumps(manifest,indent=2))
