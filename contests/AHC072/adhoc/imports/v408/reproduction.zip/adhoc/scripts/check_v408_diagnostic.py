"""Summarize fixed correctness artifacts; no solver invocation or score use."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "results/analysis/v408"
sha = lambda content: hashlib.sha256(content).hexdigest()
manifest = json.loads((OUT / "diagnostic_manifest.json").read_text())
rows = [json.loads(line) for line in (OUT / "diagnostic.jsonl").read_text().splitlines()]
assert len(rows) == 32
expected = [(case, model, symmetry) for case in manifest["inputs"] for model, symmetry in manifest["model_symmetry_pairs"]]
assert [(row["case"], row["model"], row["symmetry"]) for row in rows] == expected
keys = ["bitwise_equal", "all_actions_equal", "full_path_equal", "fixed_deadline_equal", "independent_legal_E0", "restoration_equal", "fresh_cache"]
checks = {key: all(row[key] for row in rows) for key in keys}
checks["exact_8_by_4_matrix"] = True
checks["all_fixed_deadline_calls_38"] = all(row["prefix_timer_calls"] == 38 for row in rows)
checks["source_frozen"] = sha((ROOT / "src/bin/v408_learned_only_portfolio.cpp").read_bytes()) == manifest["candidate_source_sha256"]
checks["harness_frozen"] = sha((ROOT / "adhoc/bin/v408_diagnostic.cpp").read_bytes()) == manifest["diagnostic_source_sha256"]
checks["parent_frozen"] = sha((ROOT / "adhoc/imports/v401/original.cpp.txt").read_bytes()) == manifest["parent_source_sha256"]
checks["donor_frozen"] = sha((ROOT / "adhoc/bin/v109_assisted_learned.cpp").read_bytes()) == manifest["donor_source_sha256"]
checks["inputs_frozen"] = all(sha((ROOT / case).read_bytes()) == value for case, value in manifest["input_sha256"].items())
hashes = {}
for model in [1]:
    hashes[str(model)] = {}
    for tensor in ["decoded", "transpose"]:
        candidate = (OUT / f"candidate{model}_{tensor}.bin").read_bytes()
        reference = (OUT / f"reference{model}_{tensor}.bin").read_bytes()
        checks[f"model{model}_{tensor}_exact"] = candidate == reference
        hashes[str(model)][tensor] = {"bytes": len(candidate), "candidate_sha256": sha(candidate), "reference_sha256": sha(reference)}
totals = {key: sum(row[key] for row in rows) for key in ["states", "logits", "forced", "full", "incremental", "home", "steps", "full_timer_calls", "prefix_timer_calls"]}
checks["full_incremental_home_and_forced_exercised"] = all(totals[key] > 0 for key in ["full", "incremental", "home", "forced"])
result = {
    "gate_passed": all(checks.values()),
    "checks": checks,
    "rows": len(rows),
    "totals": totals,
    "source_sha256": manifest["candidate_source_sha256"],
    "decoded_tensor_hashes": hashes,
    "packed_sha256": manifest["packed_sha256"],
    "reference1": manifest["reference1"],
    "scope": manifest["scope"],
    "not_established": "Real-time score, speed effect, live deadline scheduling, and full portfolio/LNS outcome are outside this correctness fixture.",
}
(OUT / "diagnostic_result.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
assert result["gate_passed"]
