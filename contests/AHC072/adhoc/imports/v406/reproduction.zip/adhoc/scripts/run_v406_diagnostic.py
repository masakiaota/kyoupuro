"""Run the authorized fixed correctness fixture once; never official scoring."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "results/analysis/v406"
manifest = json.loads((OUT / "diagnostic_manifest.json").read_text())
sha = lambda content: hashlib.sha256(content).hexdigest()
assert sha((ROOT / "src/bin/v406_two_policy_portfolio.cpp").read_bytes()) == manifest["candidate_source_sha256"]
assert sha((ROOT / "adhoc/bin/v406_diagnostic.cpp").read_bytes()) == manifest["diagnostic_source_sha256"]
command = ["target/release/v406_diagnostic", *manifest["inputs"]]
record = {
    "started_at": datetime.now(timezone.utc).isoformat(),
    "command": command,
    "cwd": str(ROOT),
    "binary_sha256": sha((ROOT / command[0]).read_bytes()),
    "source_sha256": manifest["candidate_source_sha256"],
    "harness_sha256": manifest["diagnostic_source_sha256"],
    "maximum_seconds": 600,
    "purpose": "One fixed 8x4 correctness pass; solver submission main and official scorer are never called.",
}
with (OUT / "diagnostic_execution.json").open("x") as stream:
    json.dump(record, stream, indent=2)
try:
    with (OUT / "diagnostic.jsonl").open("x") as stdout, (OUT / "diagnostic.stderr").open("x") as stderr:
        process = subprocess.run(command, cwd=ROOT, stdout=stdout, stderr=stderr, timeout=600, check=False)
        record["exit_code"] = process.returncode
except subprocess.TimeoutExpired:
    record["timeout"] = True
    raise
finally:
    record["finished_at"] = datetime.now(timezone.utc).isoformat()
    (OUT / "diagnostic_execution.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(record, indent=2))
assert record["exit_code"] == 0
