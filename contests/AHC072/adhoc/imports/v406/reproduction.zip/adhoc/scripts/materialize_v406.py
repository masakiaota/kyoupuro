from pathlib import Path
import hashlib,re,json,base64
r=Path(__file__).resolve().parents[2];o=r/'results/analysis/v406';o.mkdir(parents=True,exist_ok=True)
p=r/'adhoc/imports/v401/original.cpp.txt';d=r/'adhoc/bin/v109_assisted_learned.cpp'
assert hashlib.sha256(p.read_bytes()).hexdigest()=='0c241cc3a862d12faf100050df4ea3bafa3c520261d81e5237a41e3c54f25658'
assert hashlib.sha256(d.read_bytes()).hexdigest()=='c3a8402fbeef98385ff209c3bf07d7350f82b2646409ca9dfcc700eb3f12b9db'
s=p.read_text();donor=d.read_text();pattern=r'static constexpr char nn_packed\[\] =\n.*?\n;'
bank=re.search(pattern,donor,re.S).group();original=re.search(pattern,s,re.S).group()
assert (r/'notes/experiments/v406.md').exists() and '[v406]' in (r/'notes/backlog.md').read_text()
s=s.replace(s.splitlines()[0],'// v406_two_policy_portfolio.cpp',1)
s=s.replace('// v401 / B-159: exact local CNN activation reuse; direct parent v311.','// v406: frozen original and v109 policies share the unchanged four-start LNS race.\n// Direct parents v401 (whole solver) and v109 (packed weights only).',1)
s=s.replace('// Reuse exactly the parent\'s 26,866 policy/value parameters, without training.','// Each frozen bank has the same 26,866 policy/value parameters; no new training.',1)
s=s.replace(original,original+'\n\n// Frozen v109 learned policy, only for the third and fourth scheduled starts.\n'+bank.replace('nn_packed[]','nn_packed_learned[]'),1)
s=s.replace('void load_nn() {','''void load_nn(int model=0) {
    // Selecting a bank also rebuilds every transposed tensor below. Search owns
    // a fresh EncodeCache, so activations can never survive a policy switch.
    const string_view packed=model==0?string_view(nn_packed,sizeof(nn_packed)):
        string_view(nn_packed_learned,sizeof(nn_packed_learned));''',1)
s=s.replace('bytes.reserve(sizeof(nn_packed)*3/4)','bytes.reserve(packed.size()*3/4)',1).replace('for(char ch:nn_packed)','for(char ch:packed)',1)
s=s.replace('''        ++neural_portfolio.attempted;
        const auto transformed=neural_transform_input(input,sym);''','''        ++neural_portfolio.attempted;
        // Keep the parent's admission estimate, and charge the only switch
        // inside this start's measured time and the shared absolute deadline.
        if(sym==1) {
            LOCAL_NOTE(const double switch_started=time_keeper.exact_elapsed_sec();)
            nn::load_nn(1);
            LOCAL_ONLY(trace.count_by("v406_model_switches",1);
                trace.add_time_ms("v406_model_switch",(time_keeper.exact_elapsed_sec()-switch_started)*1000.0));
        }
        LOCAL_ONLY(trace.count_by("v406_model_"+to_string(sym==4?0:1)+"_attempted",1));
        const auto transformed=neural_transform_input(input,sym);''',1)
s=s.replace('''        const auto result=nn::search(transformed,board,initial,timer);
        estimated''','''        LOCAL_NOTE(const double inference_started=time_keeper.exact_elapsed_sec();)
        const auto result=nn::search(transformed,board,initial,timer);
        LOCAL_ONLY(trace.add_time_ms("v406_model_"+to_string(sym==4?0:1)+"_inference",(time_keeper.exact_elapsed_sec()-inference_started)*1000.0));
        estimated''',1)
s=s.replace('''        pool.offer(moves,-3110-sym);''','''        LOCAL_ONLY(trace.count_by("v406_model_"+to_string(sym==4?0:1)+"_completed",1));
        pool.offer(moves,sym==4?-3110-sym:-4060-sym);''',1)
s=s.replace('''            trace.count_by("race_seed_"+to_string(id)+"_origin",pool.entries[id].origin);''','''            trace.count_by("race_seed_"+to_string(id)+"_origin",pool.entries[id].origin);
            uint64_t seed_hash=1469598103934665603ULL;
            for(const auto m:pool.entries[id].moves) {
                const uint64_t code=(((uint64_t(board_info.row[m.p]*20+board_info.col[m.p])*8+m.k)*4+m.d)*8+m.l-1);
                seed_hash=(seed_hash^code)*1099511628211ULL;
            }
            trace.count_by("v406_seed_"+to_string(id)+"_hash",seed_hash&0x7fffffffffffffffULL);''',1)
s=s.replace('''            trace.count_by("race_winner_initial_rank",winner);''','''            trace.count_by("race_winner_initial_rank",winner);
            trace.count_by("v406_winner_origin",pool.entries[winner].origin);''',1)
path=r/'src/bin/v406_two_policy_portfolio.cpp';path.write_text(s)
def packed_record(t):
 text=''.join(re.findall(r'"([A-Za-z0-9+/=]+)"',t));decoded=base64.b64decode(text)
 return {'encoded_sha256':hashlib.sha256(text.encode()).hexdigest(),'decoded_sha256':hashlib.sha256(decoded).hexdigest(),'decoded_bytes':len(decoded)}
manifest={'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'parent_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'donor_sha256':hashlib.sha256(d.read_bytes()).hexdigest(),'banks':[packed_record(original),packed_record(bank)],'width':48,'depth':4,'hidden':64,'slots':[[0,0],[0,4],[1,1],[1,5]],'diagnostic_cases':[f'{i:04}.txt' for i in range(8)],'scored_evaluations':1,'local_ratio':'1.90/1.930','jobs':8,'total_strict_lt':19876,'index_strict_gt':100.30411519283527,'external_max_lte_ms':2000}
manifest.update({'fixed_reference_sha256':'71f2c83402b7f84663a10d735fb1768009e37f7e65ca333c954a6f300ed98d35','fixed_reference_path':'results/analysis/cloud_baseline/fixed_reference.json','scored_eval_set':'tools/in','toolchain':'GCC 15.3','preregistered_at_utc':'2026-10-04T07:19:35Z'})
(o/'frozen_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
