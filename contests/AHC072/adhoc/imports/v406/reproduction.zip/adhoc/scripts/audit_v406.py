from pathlib import Path
import subprocess,os,re,difflib,hashlib,json
r=Path(__file__).resolve().parents[2];o=r/'results/analysis/v406';source=r/'src/bin/v406_two_policy_portfolio.cpp';parent=r/'adhoc/imports/v401/original.cpp.txt';donor=r/'adhoc/bin/v109_assisted_learned.cpp'
results={}
def normalized(t):
 # Allowed algorithmic scope: packed learned bank, bank selection decoder,
 # neural-extra-start switch and origin. Full diffs retained for human review.
 t=re.sub(r'static constexpr char nn_packed_learned\[\] =.*?;', '',t,flags=re.S)
 a=t.index('void load_nn(');b=t.index('struct Encoded',a);t=t[:a]+t[b:]
 a=t.index('static void neural_extra_starts(');b=t.index('int main()',a);t=t[:a]+t[b:]
 t=re.sub(r'uint64_t seed_hash=1469598103934665603ULL;.*?trace.count_by\("v406_seed_"\+to_string\(id\)\+"_hash",seed_hash&0x7fffffffffffffffULL\);','',t,flags=re.S)
 t=t.replace('trace.count_by("v406_winner_origin",pool.entries[winner].origin);','')
 return re.sub(r'\s+',' ',t).strip()
p=parent.read_text();c=source.read_text()
# These complete regions include the search/cache, all LNS/RNG and final reductions.
assert p[p.index('struct Encoded'):p.index('struct NeuralPortfolioStats')]==c[c.index('struct Encoded'):c.index('struct NeuralPortfolioStats')]
assert p[p.index('int main()'):]==c[c.index('int main()'):]
(o/'source.patch').write_text(''.join(difflib.unified_diff(p.splitlines(True),c.splitlines(True),fromfile='cloud401',tofile='v406')))
for mode,flags in [('local',['-DLOCAL']),('nonlocal',['-DATCODER','-DONLINE_JUDGE','-DNOMINMAX'])]:
 pp=[]
 for name,path in [('parent',parent),('candidate',source)]:
  dest=o/f'{name}_{mode}.ii'
  with dest.open('w') as out:subprocess.run([os.environ['CXX'],'-x','c++','-std=gnu++23','-E','-P',*flags,str(path)],stdout=out,check=True)
  t=dest.read_text().replace(str(path),'SOURCE');t=re.sub(r'"SOURCE",\s*\d+,','"SOURCE", LINE,',t);pp.append(t)
 (o/f'preprocessed_{mode}.patch').write_text(''.join(difflib.unified_diff(pp[0].splitlines(True),pp[1].splitlines(True))))
 assert normalized(pp[0])==normalized(pp[1]),mode+' outside declared scope differs'
 binary=o/f'v406_{mode}'
 with (o/f'build_{mode}.log').open('w') as log:subprocess.run([os.environ['CXX'],'-std=gnu++23','-O2','-Wall','-Wextra','-march=native','-pthread','-ftrivial-auto-var-init=zero','-fopenmp',*flags,str(source),'-o',str(binary)],stdout=log,stderr=subprocess.STDOUT,check=True)
 results[mode]={'build_ok':True,'preprocessed_outside_declared_scope_equal':True,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'parent_preprocessed_sha256':hashlib.sha256((o/f'parent_{mode}.ii').read_bytes()).hexdigest(),'candidate_preprocessed_sha256':hashlib.sha256((o/f'candidate_{mode}.ii').read_bytes()).hexdigest()}
result={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'parent_sha256':hashlib.sha256(parent.read_bytes()).hexdigest(),'donor_sha256':hashlib.sha256(donor.read_bytes()).hexdigest(),'modes':results,'exact_source_regions_unchanged':['encode/policy/search/cache and all main LNS mechanics','entire main including first search, initial conversion, RNG, final reduction and output'],'scope_exclusions_for_pp':['learned packed bytes','load_nn bank-selection decoder, separately reviewed in full diff','neural_extra_starts switch/origin/plumbing, separately reviewed in full diff','LOCAL seed hash/winner counters']}
(o/'static_audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
