#!/usr/bin/env python3
"""Read-only aggregation and independent replay; never executes a solver."""
from pathlib import Path
import json,re,hashlib,csv,sys,collections,statistics
r=Path(__file__).resolve().parents[2];o=r/'results/analysis/v406';sys.path.insert(0,str(r/'adhoc/scripts'))
from replay_slime_output import replay
label='cloud_v406_gcc15.3_LOCAL_search1.900_core1.870466_j8_20261004'
records=[json.loads(s) for s in (r/'results/eval_records.jsonl').read_text().splitlines()];records=[x for x in records if x['label']==label]
assert len(records)==100 and len({x['case_name'] for x in records})==100 and all(x['status']=='ok' for x in records)
refpath=r/'results/analysis/cloud_baseline/fixed_reference.json';assert hashlib.sha256(refpath.read_bytes()).hexdigest()=='71f2c83402b7f84663a10d735fb1768009e37f7e65ca333c954a6f300ed98d35'
ref=json.loads(refpath.read_text())['cases'];parent={x['case_name']:x['score'] for x in json.loads((r/'results/analysis/v401/records.json').read_text())}
def audit(t):return {k:v for k,v in re.findall(r'\b((?:v311|v315|v406)_[\w]+)=([^\s]+)',t)}
pairs=[];traces=[];replays=[];seed_diffs=[]
for x in records:
 case=x['case_name'];inp=r/'tools/in'/case;output=r/x['stdout_path'];t=Path(str(output)+'.err').read_text();a=audit(t)
 assert hashlib.sha256(inp.read_bytes()).hexdigest()==ref[case]['input_sha256']
 counts={k:int(v) for k,v in re.findall(r'\[summary.count\] ([^=]+)=(-?\d+)',t)}
 times={k:float(v) for k,v in re.findall(r'\[summary.time_ms\] ([^=]+)=(-?[\d.]+)',t)}
 metrics=replay(inp,output)['metrics'];assert metrics['E']==0 and metrics['S']==x['score'];assert counts['final_ops']==metrics['T'] and counts['E']==0;replays.append({'case':case,**metrics})
 for i in range(int(a['v311_nn_retained'])):assert int(a[f'v311_seed_{i}_final'])<=int(a[f'v311_seed_{i}_pilot'])<=int(a[f'v311_seed_{i}_raw'])
 ppath=r/'results/analysis/v401/outputs'/f'{case}.err';pa=audit(ppath.read_text())
 keys=['v311_nn_first_hash','v311_nn_retained']+sorted(k for k in set(a)|set(pa) if re.match(r'v311_seed_\d+_(raw|origin)$',k))
 diff={k:{'v401':pa.get(k),'v406':a.get(k)} for k in keys if pa.get(k)!=a.get(k)}
 if diff:seed_diffs.append({'case':case,'differences':diff})
 traces.append({'case':case,'counts':counts,'times_ms':times,'audit':a,'output_sha256':hashlib.sha256(output.read_bytes()).hexdigest()})
 pairs.append({'case':case,'M':metrics['M'],'v311':ref[case]['score'],'v401':parent[case],'v406':x['score'],'delta':x['score']-parent[case],'index':100*ref[case]['score']/x['score'],'elapsed_ms':x['elapsed']})
elapsed=[x['elapsed'] for x in records];errors={k:sum(t['counts'].get(k,0) for t in traces) for k in ['construction_errors','lns_errors','baseline_recovery','final_recovery','lns_invalid_candidates']}
free=dict(collections.Counter(t['counts'].get('state_pool_free_at_end','missing') for t in traces))
changed={x['case'] for x in seed_diffs}
def subset(rows):return {'cases':len(rows),'delta_sum':sum(x['delta'] for x in rows),'index':statistics.mean(x['index'] for x in rows) if rows else None,'wins':sum(x['delta']<0 for x in rows),'ties':sum(x['delta']==0 for x in rows),'losses':sum(x['delta']>0 for x in rows)}
result={'label':label,'cases':100,'score_sum':sum(x['score'] for x in records),'score_mean':statistics.mean(x['score'] for x in records),'score_delta':sum(x['delta'] for x in pairs),'fixed_reference_index':statistics.mean(x['index'] for x in pairs),**{k:v for k,v in subset(pairs).items() if k in ('wins','ties','losses')},'elapsed_mean_ms':statistics.mean(elapsed),'elapsed_max_ms':max(elapsed),'elapsed_over_1900ms':sum(x>1900 for x in elapsed),'elapsed_ge_2000ms':sum(x>=2000 for x in elapsed),'independent_replay_ok':len(replays),'error_recovery_totals':errors,'free_slots_distribution':free,'search_limit_distribution_ms':dict(collections.Counter(t['times_ms'].get('search_limit','missing') for t in traces)),'trace_total_max_ms':max(t['times_ms'].get('total',0) for t in traces),'mechanism':{k:sum(t['counts'].get(k,0) for t in traces) for k in ('v406_model_switches','v406_model_0_attempted','v406_model_1_attempted','v406_model_0_completed','v406_model_1_completed','cnn_calls','cnn_incremental','lns_attempts')},'initial_candidate_changed_cases':len(changed),'unchanged_initial_candidates':subset([p for p in pairs if p['case'] not in changed]),'excluding0005':subset([p for p in pairs if p['case']!='0005.txt']),'case0005':next(p for p in pairs if p['case']=='0005.txt'),'M_groups':{f'{lo}-{hi}':subset([p for p in pairs if lo<=p['M']<=hi]) for lo,hi in [(0,50),(51,100),(101,200),(201,400)]},'source_sha256':hashlib.sha256((r/'src/bin/v406_two_policy_portfolio.cpp').read_bytes()).hexdigest(),'diagnostic_summary':json.loads((o/'diagnostic_result.json').read_text()),'memory':json.loads((o/'memory.json').read_text())}
manifest=json.loads((o/'frozen_manifest.json').read_text());assert result['source_sha256']==manifest['source_sha256']
result['initial_first_hash_mismatch_cases']=[x['case'] for x in seed_diffs if 'v311_nn_first_hash' in x['differences']]
result['fixed_reference_index_delta_vs_v401']=result['fixed_reference_index']-100.30411519283527
result['learned_policy_active_cases']=sum(t['counts'].get('v406_model_switches',0)>0 for t in traces)
result['learned_winner_cases']=sum(t['counts'].get('v406_winner_origin',0) in (-4061,-4065) for t in traces)
result['winner_origins']=dict(collections.Counter(t['counts'].get('v406_winner_origin','missing') for t in traces))
result['model_switch_time_ms']={'sum':sum(t['times_ms'].get('v406_model_switch',0) for t in traces),'max':max(t['times_ms'].get('v406_model_switch',0) for t in traces)}
result['model_inference_time_ms']={str(model):sum(t['times_ms'].get('v406_model_'+str(model)+'_inference',0) for t in traces) for model in (0,1)}
result['original_first_inference_time_seconds']=sum(float(t['audit']['v311_nn_first_seconds']) for t in traces)
result['original_attempted_including_first']=100+result['mechanism']['v406_model_0_attempted']
result['original_completed_including_first']=100+result['mechanism']['v406_model_0_completed']
result['source_bytes']=(r/'src/bin/v406_two_policy_portfolio.cpp').stat().st_size
result['acceptance_passed']=result['score_sum']<19876 and result['fixed_reference_index']>100.30411519283527 and max(elapsed)<=2000 and all(v==0 for v in errors.values()) and free=={4:100}
result['fixed_reference_metric_description']='Historical auxiliary mean(100 * saved v311 score / v406 score), not official or requested v800-relative score.'
result['requested_v800_relative_score']=None
result['requested_v800_status']='not_computed_missing_exact_historical_v800_100_case_scores'
result['user_decision']='rejected; absolute total 7 above saved cloud401; user confirmed rejection'
for name,value in [('result',result),('records',records),('case_traces',traces),('replay',replays),('initial_candidate_differences',seed_diffs)]: (o/f'{name}.json').write_text(json.dumps(value,indent=2)+'\n')
with (o/'paired.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=list(pairs[0]));w.writeheader();w.writerows(pairs)
print(json.dumps({k:v for k,v in result.items() if k!='memory'},indent=2))
