from pathlib import Path
import hashlib,json,re,zipfile
r=Path(__file__).resolve().parents[2];o=r/'results/analysis/v406';dest=r/'adhoc/imports/v406';dest.mkdir(parents=True,exist_ok=True);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();source=r/'src/bin/v406_two_policy_portfolio.cpp';frozen=json.loads((o/'frozen_manifest.json').read_text());assert sha(source)==frozen['source_sha256']
parent={}
for p in sorted((r/'results/analysis/v401/outputs').glob('*.txt.err')):parent[p.name.removesuffix('.err')]={k:v for k,v in re.findall(r'\b(v311_[\w]+)=([^\s]+)',p.read_text())}
(o/'parent_portfolio.json').write_text(json.dumps(parent,indent=2))
(o/'REPRODUCE.txt').write_text('''v406 frozen two-policy four-seed portfolio. Private cloud evidence.
Source and note are committed separately and not duplicated in this ZIP.
Metric correction: saved fixed_reference_index is only the old v311-based auxiliary index. The user-requested v800 relative score is NOT computed because exact historical v800100 scores are unavailable. Do not treat mixed historical best/oracle tables as v800. Rejected absolute total+7 remains unchanged.
Exact original and donor are already tracked in private main:
adhoc/imports/v401/original.cpp.txt SHA0c241cc3a862d12faf100050df4ea3bafa3c520261d81e5237a41e3c54f25658
adhoc/bin/v109_assisted_learned.cpp SHAc3a8402fbeef98385ff209c3bf07d7350f82b2646409ca9dfcc700eb3f12b9db
src/bin/v311_neural_multistart.cpp SHAc3f819c2715f397bee0ca95bca12be3196c6f5531dbfeb19358d0afd5f6868ea (independent full-encode reference)
Unpack in repository root preserving existing files; inspect scripts first.
source adhoc/scripts/cloud_toolchain_env.sh
materialize_v406.py reconstructs source; audit_v406.py builds both modes and compares actual full preprocessing. build_v406_diagnostic.py generates diagnostic C++.
Saved diagnostic reports cover fixed0000-0007 × (original0,original4,learned1,learned5). Any new solver execution requires a new explicit instruction; do not rerun for noise.
run_v406_eval.py performs one standard tools/in100 LOCAL1.90/1.930 j8 evaluation after both diagnostic/review gates. Existing eval.log guards accidental reexecution.
summarize_v406.py reads saved records, verifies scores and independent legality without executing a solver. It expects archived stdout_path files restored to their recorded paths.
Source/notes/backlog are separate authoritative files. No duplicate source or inputs, binaries, or full preprocessing bodies. Full original artifacts remain privately on cloud; full_artifact_hashes.json records hashes. Exact preprocessing/source patches and all scored outputs/trace logs included.
''')
artifacts=[source,r/'src/bin/v311_neural_multistart.cpp',r/'adhoc/imports/v401/original.cpp.txt',r/'adhoc/bin/v109_assisted_learned.cpp',*o.glob('*.ii'),o/'v406_local',o/'v406_nonlocal',*list((r/'adhoc/bin').glob('v406*')),*list((r/'target/release').glob('v406*'))]
(o/'full_artifact_hashes.json').write_text(json.dumps({str(p.relative_to(r)):sha(p) for p in artifacts if p.is_file()},indent=2))
files=[p for p in sorted(o.rglob('*')) if p.is_file() and p.suffix in ('.json','.jsonl','.csv','.log','.patch','.md','.txt','.stderr','.err')]
files+=sorted((r/'results/out/v406_two_policy_portfolio').glob('*'))
files+=[r/'results/analysis/cloud_baseline/fixed_reference.json',r/'results/analysis/v401/records.json',r/'results/analysis/v401/result.json']
files+=list((r/'adhoc/scripts').glob('*v406*.py'))
files+=[r/'adhoc/scripts'/n for n in ['replay_slime_output.py','cloud_gcc15.py','cloud_toolchain_env.sh']]
files=list(dict.fromkeys(files));manifest={str(p.relative_to(r)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in files}
with zipfile.ZipFile(dest/'reproduction.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files:z.write(p,str(p.relative_to(r)))
 z.writestr('V406_CONTENT_MANIFEST.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(dest/'reproduction.zip') as z:
 assert z.testzip() is None
 for name,item in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==item['sha256']
assert (dest/'reproduction.zip').stat().st_size<1000000
external={'version':'v406','source_sha256':sha(source),'note_sha256':sha(r/'notes/experiments/v406.md'),'backlog_sha256':sha(r/'notes/backlog.md'),'zip_sha256':sha(dest/'reproduction.zip'),'zip_bytes':(dest/'reproduction.zip').stat().st_size,'file_count':len(files),'publication_files':['src/bin/v406_two_policy_portfolio.cpp','notes/experiments/v406.md','notes/backlog.md','adhoc/imports/v406/reproduction.zip','adhoc/imports/v406/manifest.json'],'files':manifest};(dest/'manifest.json').write_text(json.dumps(external,indent=2));print(json.dumps({k:v for k,v in external.items() if k!='files'},indent=2))
