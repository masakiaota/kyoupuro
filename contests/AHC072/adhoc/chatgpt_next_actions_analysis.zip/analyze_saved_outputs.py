"""Read-only analysis of saved AHC072 solutions. Does not generate/repair solutions.
Replays original commands and reconstructs candidate descriptors, not routes.
"""
from pathlib import Path
from collections import deque, Counter, defaultdict
import json, csv, statistics, hashlib
ROOT = Path('/mnt/data/research_next/paired_event')
OUT = Path('/mnt/data/research_next')

def bm(ids):
    b=0
    for x in ids: b |= 1<<x
    return b

def prepare(path):
    data=path.read_text().split(); N,K=map(int,data[:2]); grid=data[2:]
    coords=[(r,c) for r in range(N) for c in range(N) if grid[r][c]!='#']
    cell={rc:i for i,rc in enumerate(coords)}
    origin=[]; colors=[]; home={}; nest={}
    for i,(r,c) in enumerate(coords):
        ch=grid[r][c]
        if ch.islower(): origin.append(i); colors.append(ord(ch)-97)
        elif ch.isupper(): home[ord(ch)-65]=i; nest[i]=ord(ch)-65
    adj=[[cell[rc] for rc in ((r-1,c),(r+1,c),(r,c-1),(r,c+1)) if rc in cell] for r,c in coords]
    ds=[]
    for src in range(len(coords)):
        d=[100000]*len(coords); d[src]=0; q=deque([src])
        while q:
            u=q.popleft()
            for v in adj[u]:
                if d[v]>10000: d[v]=d[u]+1; q.append(v)
        ds.append(d)
    spatial=[]
    for a,p in enumerate(origin):
        near=[]; same=[]; diff=[]
        for z,q in enumerate(origin):
            if z==a: continue
            merit=5*ds[p][q]+ds[home[colors[a]]][home[colors[z]]]
            entry=(merit,q,z); near.append(entry)
            (same if colors[z]==colors[a] else diff).append(entry)
        for arr,limit in ((near,2),(same,2),(diff,1)):
            arr.sort(); ids=[a]
            for _,_,z in arr[:limit]: ids.append(z); spatial.append(bm(ids))
    return N,coords,cell,origin,colors,home,nest,spatial

def analyze(inp, solution):
    N,coords,cell,origin,colors,home,nest,spatial=inp
    board=[[] for _ in coords]
    for i,p in enumerate(origin):board[p]=[i]
    candidates=set(spatial); color_sets=defaultdict(list)
    for i,c in enumerate(colors):candidates.add(1<<i);color_sets[c].append(i)
    for ids in color_sets.values():
        if len(ids)<=12:candidates.add(bm(ids))
    events=[]; cuts=defaultdict(list); moves=Counter(); pattern=Counter()
    for t,line in enumerate(solution.read_text().splitlines()):
        if not line.strip():continue
        r,c,k,d,l=line.split();r=int(r);c=int(c);k=int(k);l=int(l)
        dr,dc={'U':(-1,0),'D':(1,0),'L':(0,-1),'R':(0,1)}[d]
        assert (r,c) in cell
        assert all((r+dr*z,c+dc*z) in cell for z in range(1,l+1))
        p=cell[r,c];q=cell[r+dr*l,c+dc*l]
        h=len(board[p]); assert 0<=k<h and 1<=l<=k+1 and len(board[q])+h-k<=8
        flight=board[p][k:];lower=board[p][:k];resident=board[q][:]
        F,L,R=map(bm,(flight,lower,resident)); pattern[F]+=1
        candidates.add(F)
        run=[]
        for who in board[p]:
            if run and colors[run[-1]]!=colors[who]:candidates.add(bm(run));run=[]
            run.append(who)
        if run:candidates.add(bm(run))
        if lower:candidates.add(L)
        if resident and len(resident)+len(flight)<=8:candidates.add(F|R)
        for ck in set((0,k,h-2)):
            n=h-ck
            if ck<0 or n<2:continue
            if ck and p in nest and colors[board[p][ck-1]]==nest[p]:continue
            ids=board[p][ck:];S=bm(ids)
            # Data describing an existing cut; no alternative command searched.
            cuts[S].append({'t':t,'p':p,'k':ck,'word':tuple(colors[i] for i in ids),
                            'split':ck<k<h,'jump':l>1,'nest':p in nest})
        events.append((F,L,l,k))
        moves['commands']+=1;moves['jump']+=l>1;moves['split']+=k>0
        moves['mixed']+=len({colors[i] for i in flight})>1
        moves['single']+=len(flight)==1;moves['max_length']=max(moves['max_length'],l)
        board[p]=lower;board[q].extend(reversed(flight))
        for v in (p,q):
            while board[v] and nest.get(v,-1)==colors[board[v][-1]]:board[v].pop()
    assert not any(board)
    row=dict(moves);row['n_slimes']=len(colors);row['n_candidates']=len(candidates)
    scored=[]
    for S in candidates:
        gross=sum(n for F,n in pattern.items() if F&S==F)
        score=(gross+.25)/(S.bit_count()**.65)
        scored.append((score,S,gross))
    scored.sort(reverse=True)
    # Deletion damage on original trace only: not exact extraction feasibility.
    # If a surviving flight loses too many supporters, original jump cannot stand.
    risk=[]
    for _,S,gross in scored[:32]:
        breaks=sum(1 for F,L,l,k in events if F&~S and l>k-(L&S).bit_count()+1)
        risk.append((gross,breaks))
    row['top32_count']=len(risk)
    row['top32_support_sensitive']=sum(b>0 for g,b in risk)
    row['top32_broken_jumps']=sum(b for g,b in risk)
    row['top32_gross']=sum(g for g,b in risk)
    row['cut_identity_sets']=len(cuts)
    row['cut_occurrences']=sum(len(x) for x in cuts.values())
    row['cut_sets_multiple_sites']=sum(len({c['p'] for c in a})>1 for a in cuts.values())
    row['cut_sets_later_split_only']=sum(not a[0]['split'] and any(c['split'] for c in a[1:]) for a in cuts.values())
    row['cut_sets_later_new_context']=sum(any((c['p'],c['k'],c['word'])!=(a[0]['p'],a[0]['k'],a[0]['word']) for c in a[1:]) for a in cuts.values())
    return row

def main():
    rows=[]
    for case in range(100):
        inp=prepare(ROOT/'in'/f'{case:04}.txt')
        for rep in (1,2):
            r=analyze(inp, ROOT/'measurement'/f'new_{rep}'/'outputs'/f'{case:04}.txt')
            rows.append(dict(case=f'{case:04}',rep=rep,**r))
    summary={k:{'sum':sum(r[k] for r in rows),'mean':statistics.mean(r[k] for r in rows)} for k in rows[0] if k not in ('case','rep')}
    summary['case0000']=[r for r in rows if r['case']=='0000']
    summary['support_sensitive_fraction_top32']=sum(r['top32_support_sensitive'] for r in rows)/sum(r['top32_count'] for r in rows)
    summary['cases_with_support_sensitive_top32']=len({r['case'] for r in rows if r['top32_support_sensitive']})
    summary['cases_with_later_split_cut']=len({r['case'] for r in rows if r['cut_sets_later_split_only']})
    summary['protocol']='200 saved final outputs of adopted paired_event, original two repetitions. No solver run; no new solution generated. Top32 ranking omits 0.9-1.1 RNG jitter, exact identity-set dedup; removal damage ignores dynamic repairs and early home effects.'
    (OUT/'trace_analysis.json').write_text(json.dumps(summary,indent=2))
    with (OUT/'trace_analysis.csv').open('w') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
